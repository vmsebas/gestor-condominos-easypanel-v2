--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_communication_logs_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_communication_logs_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_communication_logs_updated_at() OWNER TO postgres;

--
-- Name: update_document_search_vector(); Type: FUNCTION; Schema: public; Owner: mini-server
--

CREATE FUNCTION public.update_document_search_vector() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector := 
        setweight(to_tsvector('spanish', COALESCE(NEW.name, '')), 'A') ||
        setweight(to_tsvector('spanish', COALESCE(NEW.description, '')), 'B') ||
        setweight(to_tsvector('spanish', COALESCE(array_to_string(NEW.tags, ' '), '')), 'C');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_document_search_vector() OWNER TO "mini-server";

--
-- Name: update_tasks_completed_at(); Type: FUNCTION; Schema: public; Owner: mini-server
--

CREATE FUNCTION public.update_tasks_completed_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        NEW.completed_at = CURRENT_TIMESTAMP;
    ELSIF NEW.status != 'completed' AND OLD.status = 'completed' THEN
        NEW.completed_at = NULL;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_tasks_completed_at() OWNER TO "mini-server";

--
-- Name: update_tasks_updated_at(); Type: FUNCTION; Schema: public; Owner: mini-server
--

CREATE FUNCTION public.update_tasks_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_tasks_updated_at() OWNER TO "mini-server";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: mini-server
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO "mini-server";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: arrears; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.arrears (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    member_id uuid NOT NULL,
    building_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    original_amount numeric(10,2) NOT NULL,
    due_date date NOT NULL,
    description text NOT NULL,
    status character varying(50) NOT NULL,
    last_reminder_sent timestamp without time zone,
    reminder_count integer DEFAULT 0,
    settled_date date,
    settlement_transaction_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.arrears OWNER TO "mini-server";

--
-- Name: attendance_sheets; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.attendance_sheets (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    convocatoria_id uuid,
    minute_id uuid,
    meeting_date date NOT NULL,
    total_members integer NOT NULL,
    present_members integer NOT NULL,
    represented_members integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.attendance_sheets OWNER TO "mini-server";

--
-- Name: attendees; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.attendees (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    attendance_sheet_id uuid,
    member_id uuid NOT NULL,
    member_name character varying(255) NOT NULL,
    attendance_type character varying(20) NOT NULL,
    representative_name character varying(255),
    signature text,
    arrival_time time without time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT attendees_attendance_type_check CHECK (((attendance_type)::text = ANY (ARRAY[('present'::character varying)::text, ('represented'::character varying)::text, ('absent'::character varying)::text])))
);


ALTER TABLE public.attendees OWNER TO "mini-server";

--
-- Name: buildings; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.buildings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    postal_code character varying(20),
    city character varying(100),
    number_of_units integer DEFAULT 0,
    administrator character varying(255),
    admin_contact character varying(50),
    admin_email character varying(255),
    iban character varying(34),
    bank character varying(255),
    account_number character varying(50),
    swift character varying(11),
    phone character varying(50),
    email character varying(255),
    president_name character varying(255),
    president_email character varying(255),
    secretary_name character varying(255),
    secretary_email character varying(255),
    administrator_name character varying(255),
    administrator_email character varying(255),
    notes text,
    registration_number character varying(100),
    construction_year integer,
    total_units integer,
    legal_framework jsonb,
    statutes jsonb,
    internal_rules jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.buildings OWNER TO "mini-server";

--
-- Name: communication_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.communication_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    member_id uuid NOT NULL,
    building_id uuid NOT NULL,
    communication_type character varying(50) NOT NULL,
    communication_subtype character varying(50),
    channel character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'draft_created'::character varying NOT NULL,
    subject text,
    body_preview text,
    full_content text,
    pdf_url text,
    pdf_filename character varying(255),
    related_convocatoria_id uuid,
    related_minute_id uuid,
    related_transaction_id uuid,
    draft_created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    sent_at timestamp with time zone,
    opened_at timestamp with time zone,
    confirmed_at timestamp with time zone,
    failed_at timestamp with time zone,
    error_message text,
    retry_count integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.communication_logs OWNER TO postgres;

--
-- Name: TABLE communication_logs; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.communication_logs IS 'Registo de todas as comunicações enviadas aos condóminos (email, WhatsApp, etc.)';


--
-- Name: COLUMN communication_logs.communication_type; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.communication_logs.communication_type IS 'Tipo de comunicação: convocatoria, acta, quota, note, letter';


--
-- Name: COLUMN communication_logs.channel; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.communication_logs.channel IS 'Canal utilizado: email ou whatsapp';


--
-- Name: COLUMN communication_logs.status; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.communication_logs.status IS 'Estado: draft_created, sent, opened, confirmed, failed';


--
-- Name: COLUMN communication_logs.metadata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.communication_logs.metadata IS 'Dados adicionais em formato JSON (flexível para diferentes tipos de comunicação)';


--
-- Name: convocatorias; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.convocatorias (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    building_name text NOT NULL,
    building_address text NOT NULL,
    postal_code character varying(20),
    city character varying(100),
    assembly_number character varying(50),
    assembly_type character varying(50) NOT NULL,
    meeting_type character varying(50),
    title character varying(255),
    date date NOT NULL,
    meeting_date date,
    "time" character varying(10) NOT NULL,
    location text NOT NULL,
    meeting_location text,
    second_call_enabled boolean DEFAULT true,
    second_call_time character varying(10),
    second_call_date date,
    administrator character varying(255) NOT NULL,
    secretary character varying(255),
    legal_reference text,
    minutes_created boolean DEFAULT false,
    agenda_items jsonb,
    convocation_date date,
    legal_notice_period integer,
    delivery_method character varying(50),
    attached_documents jsonb,
    legal_validation jsonb,
    quorum_requirements jsonb,
    status character varying(50) DEFAULT 'draft'::character varying,
    meeting_subject text,
    president_name character varying(255),
    president_email character varying(255),
    secretary_name character varying(255),
    secretary_email character varying(255),
    administrator_name character varying(255),
    administrator_email character varying(255),
    notification_sent_at timestamp without time zone,
    published_at timestamp without time zone,
    published_by_user_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.convocatorias OWNER TO "mini-server";

--
-- Name: document_categories; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.document_categories (
    id integer NOT NULL,
    building_id uuid,
    name character varying(100) NOT NULL,
    description text,
    color character varying(7) DEFAULT '#6366f1'::character varying,
    icon character varying(50) DEFAULT 'folder'::character varying,
    parent_category_id integer,
    sort_order integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.document_categories OWNER TO "mini-server";

--
-- Name: document_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: mini-server
--

CREATE SEQUENCE public.document_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_categories_id_seq OWNER TO "mini-server";

--
-- Name: document_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mini-server
--

ALTER SEQUENCE public.document_categories_id_seq OWNED BY public.document_categories.id;


--
-- Name: document_shares; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.document_shares (
    id integer NOT NULL,
    document_id integer,
    member_id uuid,
    permission character varying(20) DEFAULT 'read'::character varying,
    shared_by character varying(100),
    shared_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone
);


ALTER TABLE public.document_shares OWNER TO "mini-server";

--
-- Name: document_shares_id_seq; Type: SEQUENCE; Schema: public; Owner: mini-server
--

CREATE SEQUENCE public.document_shares_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_shares_id_seq OWNER TO "mini-server";

--
-- Name: document_shares_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mini-server
--

ALTER SEQUENCE public.document_shares_id_seq OWNED BY public.document_shares.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    building_id uuid,
    member_id uuid,
    name character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    file_extension character varying(10) NOT NULL,
    category character varying(50) DEFAULT 'general'::character varying NOT NULL,
    subcategory character varying(50),
    tags text[],
    description text,
    version integer DEFAULT 1,
    parent_document_id integer,
    is_current_version boolean DEFAULT true,
    visibility character varying(20) DEFAULT 'building'::character varying,
    is_confidential boolean DEFAULT false,
    access_level character varying(20) DEFAULT 'read'::character varying,
    uploaded_by character varying(100),
    uploaded_at timestamp without time zone DEFAULT now(),
    last_accessed_at timestamp without time zone,
    download_count integer DEFAULT 0,
    search_vector tsvector,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.documents OWNER TO "mini-server";

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: mini-server
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO "mini-server";

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mini-server
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: financial_periods; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.financial_periods (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    year integer NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    approved_budget jsonb,
    budget_approval_date date,
    budget_approval_minute_id uuid,
    reserve_fund_minimum numeric(12,2),
    reserve_fund_actual numeric(12,2),
    legal_compliance_check jsonb,
    is_closed boolean DEFAULT false,
    closed_at timestamp without time zone,
    total_income numeric(12,2),
    total_expenses numeric(12,2),
    balance numeric(12,2),
    notes text,
    closed_by_user_id uuid,
    initial_balance numeric(12,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.financial_periods OWNER TO "mini-server";

--
-- Name: fractions; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.fractions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    member_id uuid,
    unit_number character varying(50) NOT NULL,
    ownership_percentage numeric(5,2),
    surface_area numeric(10,2),
    fraction_type character varying(50),
    is_active boolean DEFAULT true,
    deed_reference character varying(255),
    acquisition_date date,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.fractions OWNER TO "mini-server";

--
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.knex_migrations OWNER TO "mini-server";

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: mini-server
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knex_migrations_id_seq OWNER TO "mini-server";

--
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mini-server
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.knex_migrations_lock OWNER TO "mini-server";

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: mini-server
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNER TO "mini-server";

--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mini-server
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- Name: letter_templates; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.letter_templates (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL,
    subject character varying(255),
    content text NOT NULL,
    variables text[],
    is_active boolean DEFAULT true,
    legal_basis text,
    required_fields text[],
    validation_rules jsonb,
    title character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.letter_templates OWNER TO "mini-server";

--
-- Name: meeting_members; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.meeting_members (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    minutes_id uuid NOT NULL,
    member_id uuid NOT NULL,
    member_name character varying(255) NOT NULL,
    apartment character varying(50) NOT NULL,
    votes integer DEFAULT 1,
    attendance_type character varying(50) NOT NULL,
    is_president boolean DEFAULT false,
    is_secretary boolean DEFAULT false,
    representative_name character varying(255),
    signature text,
    arrival_time time without time zone,
    departure_time time without time zone,
    voting_power numeric(5,2),
    percentage_represented numeric(5,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.meeting_members OWNER TO "mini-server";

--
-- Name: member_annual_fees; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.member_annual_fees (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    member_id uuid NOT NULL,
    building_id uuid NOT NULL,
    financial_period_id uuid,
    year integer NOT NULL,
    fee_amount numeric(10,2) NOT NULL,
    paid_amount numeric(10,2) DEFAULT 0,
    is_paid boolean DEFAULT false,
    due_date date,
    paid_date date,
    payment_method character varying(50),
    transaction_id uuid,
    notes text,
    late_fee numeric(10,2),
    installments integer,
    installment_amount numeric(10,2),
    fraction_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.member_annual_fees OWNER TO "mini-server";

--
-- Name: member_votes; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.member_votes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    minute_agenda_item_id uuid NOT NULL,
    member_id uuid NOT NULL,
    building_id uuid,
    member_name character varying(255) NOT NULL,
    apartment character varying(50) NOT NULL,
    vote character varying(20) NOT NULL,
    voting_power numeric(5,2) DEFAULT 1,
    representative_name character varying(255),
    comments text,
    vote_timestamp timestamp without time zone,
    is_proxy_vote boolean DEFAULT false,
    proxy_document_url text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT member_votes_vote_check CHECK (((vote)::text = ANY (ARRAY[('favor'::character varying)::text, ('against'::character varying)::text, ('abstention'::character varying)::text])))
);


ALTER TABLE public.member_votes OWNER TO "mini-server";

--
-- Name: members; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.members (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    name text NOT NULL,
    apartment character varying(50),
    fraction character varying(50),
    votes integer DEFAULT 0,
    email character varying(255),
    phone character varying(50),
    profile_image text,
    notes text,
    old_annual_fee numeric(10,2) DEFAULT 0,
    old_monthly_fee numeric(10,2) DEFAULT 0,
    new_annual_fee numeric(10,2) DEFAULT 0,
    new_monthly_fee numeric(10,2) DEFAULT 0,
    permilage numeric(10,4) DEFAULT 0,
    is_active boolean DEFAULT true,
    nif character varying(20),
    nif_nie character varying(20),
    address text,
    ownership_percentage numeric(5,2),
    deed_date date,
    legal_representative_id uuid,
    role character varying(50) DEFAULT 'owner'::character varying,
    monthly_fee numeric(10,2),
    annual_fee numeric(10,2),
    avatar_url text,
    secondary_address text,
    secondary_postal_code character varying(10),
    secondary_city character varying(100),
    secondary_country character varying(100) DEFAULT 'Portugal'::character varying,
    user_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email_consent boolean DEFAULT false,
    email_consent_date timestamp with time zone,
    whatsapp_number character varying(20),
    whatsapp_consent boolean DEFAULT false,
    whatsapp_consent_date timestamp with time zone,
    preferred_communication character varying(20) DEFAULT 'email'::character varying
);


ALTER TABLE public.members OWNER TO "mini-server";

--
-- Name: COLUMN members.email_consent; Type: COMMENT; Schema: public; Owner: mini-server
--

COMMENT ON COLUMN public.members.email_consent IS 'Consentimento para comunicações por email (Lei n.º 8/2022)';


--
-- Name: COLUMN members.email_consent_date; Type: COMMENT; Schema: public; Owner: mini-server
--

COMMENT ON COLUMN public.members.email_consent_date IS 'Data do consentimento para email';


--
-- Name: COLUMN members.whatsapp_number; Type: COMMENT; Schema: public; Owner: mini-server
--

COMMENT ON COLUMN public.members.whatsapp_number IS 'Número WhatsApp com código país (+351...)';


--
-- Name: COLUMN members.whatsapp_consent; Type: COMMENT; Schema: public; Owner: mini-server
--

COMMENT ON COLUMN public.members.whatsapp_consent IS 'Consentimento para comunicações informais por WhatsApp';


--
-- Name: COLUMN members.whatsapp_consent_date; Type: COMMENT; Schema: public; Owner: mini-server
--

COMMENT ON COLUMN public.members.whatsapp_consent_date IS 'Data do consentimento para WhatsApp';


--
-- Name: minute_agenda_items; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.minute_agenda_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    minutes_id uuid,
    building_id uuid,
    item_number integer NOT NULL,
    title text NOT NULL,
    description text,
    discussion text,
    decision text,
    vote_type character varying(50),
    votes_in_favor integer,
    votes_against integer,
    abstentions integer,
    is_approved boolean DEFAULT false,
    legal_requirement character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    convocatoria_id uuid
);


ALTER TABLE public.minute_agenda_items OWNER TO "mini-server";

--
-- Name: minute_signatures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.minute_signatures (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    minute_id uuid NOT NULL,
    member_id uuid,
    signer_type character varying(50) NOT NULL,
    signer_name character varying(255) NOT NULL,
    signature text,
    rubric text,
    cmd_signature text,
    cmd_timestamp timestamp without time zone,
    cmd_certificate text,
    signed_at timestamp without time zone DEFAULT now(),
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT minute_signatures_signer_type_check CHECK (((signer_type)::text = ANY ((ARRAY['president'::character varying, 'secretary'::character varying, 'member'::character varying])::text[])))
);


ALTER TABLE public.minute_signatures OWNER TO postgres;

--
-- Name: minutes; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.minutes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    convocatoria_id uuid,
    minute_number character varying(50) NOT NULL,
    meeting_date date NOT NULL,
    meeting_time character varying(10) NOT NULL,
    end_time character varying(10),
    start_time character varying(10),
    location text NOT NULL,
    meeting_location text,
    assembly_type character varying(50) NOT NULL,
    building_address text NOT NULL,
    building_name character varying(255),
    postal_code character varying(20),
    president_name character varying(255),
    administrator_custom character varying(255),
    secretary_name character varying(255),
    secretary_custom character varying(255),
    conclusions text,
    attendees jsonb,
    total_units_represented integer,
    total_percentage_represented numeric(5,2),
    quorum_achieved boolean,
    agenda_development jsonb,
    votes_record jsonb,
    agreements_reached jsonb,
    legal_validity boolean,
    signed_date date,
    president_signature text,
    secretary_signature text,
    final_document_url text,
    attendees_count integer,
    quorum_percentage numeric(5,2),
    quorum_met boolean,
    agenda_items jsonb,
    decisions jsonb,
    voting_results jsonb,
    next_meeting_date date,
    attachments jsonb,
    is_approved boolean DEFAULT false,
    approved_at timestamp without time zone,
    approved_by_user_id uuid,
    notes text,
    status character varying(50) DEFAULT 'draft'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.minutes OWNER TO "mini-server";

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying(500) NOT NULL,
    user_id uuid NOT NULL,
    device_id character varying(255),
    device_name character varying(255),
    ip_address character varying(45),
    user_agent text,
    expires_at timestamp with time zone NOT NULL,
    is_revoked boolean DEFAULT false,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO "mini-server";

--
-- Name: sent_letters; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.sent_letters (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    template_id uuid,
    member_id uuid,
    recipient_name character varying(255) NOT NULL,
    recipient_email character varying(255),
    subject character varying(255) NOT NULL,
    content text NOT NULL,
    send_method character varying(50) NOT NULL,
    sent_date timestamp without time zone,
    delivery_confirmation boolean DEFAULT false,
    tracking_number character varying(100),
    legal_validity boolean,
    created_by_user_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sent_letters OWNER TO "mini-server";

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    building_id uuid NOT NULL,
    minute_id uuid,
    title character varying(255) NOT NULL,
    description text,
    assignee_id uuid,
    assignee_name character varying(255),
    due_date date,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    priority character varying(20) DEFAULT 'medium'::character varying NOT NULL,
    category character varying(100),
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp with time zone,
    completed_by uuid,
    notes text,
    CONSTRAINT tasks_priority_check CHECK (((priority)::text = ANY (ARRAY[('high'::character varying)::text, ('medium'::character varying)::text, ('low'::character varying)::text]))),
    CONSTRAINT tasks_status_check CHECK (((status)::text = ANY (ARRAY[('pending'::character varying)::text, ('in_progress'::character varying)::text, ('completed'::character varying)::text, ('cancelled'::character varying)::text])))
);


ALTER TABLE public.tasks OWNER TO "mini-server";

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: mini-server
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO "mini-server";

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mini-server
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: transaction_categories; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.transaction_categories (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    type character varying(20) NOT NULL,
    transaction_type character varying(20),
    is_active boolean DEFAULT true,
    color character varying(7),
    budget_amount numeric(12,2),
    parent_category_id uuid,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT transaction_categories_type_check CHECK (((type)::text = ANY (ARRAY[('income'::character varying)::text, ('expense'::character varying)::text])))
);


ALTER TABLE public.transaction_categories OWNER TO "mini-server";

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    building_id uuid NOT NULL,
    financial_period_id uuid,
    period_id uuid,
    category_id uuid,
    transaction_date date NOT NULL,
    date date,
    transaction_type character varying(20) NOT NULL,
    type character varying(20),
    description text NOT NULL,
    amount numeric(12,2) NOT NULL,
    fraction_id uuid,
    member_id uuid,
    payment_method character varying(50),
    reference_number character varying(100),
    notes text,
    admin_notes text,
    receipt_url text,
    is_recurring boolean DEFAULT false,
    recurring_frequency character varying(50),
    recurring_months integer[],
    year integer NOT NULL,
    is_fee_payment boolean DEFAULT false,
    is_confirmed boolean DEFAULT true,
    last_modified_by character varying(255),
    tags text[],
    created_by_user_id uuid,
    approved_by_user_id uuid,
    approved_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT transactions_transaction_type_check CHECK (((transaction_type)::text = ANY (ARRAY[('income'::character varying)::text, ('expense'::character varying)::text])))
);


ALTER TABLE public.transactions OWNER TO "mini-server";

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    session_token character varying(500) NOT NULL,
    activity_log jsonb DEFAULT '[]'::jsonb,
    last_activity_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    user_agent text,
    device_type character varying(50),
    browser character varying(50),
    os character varying(50),
    country character varying(2),
    city character varying(100),
    is_active boolean DEFAULT true,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_sessions OWNER TO "mini-server";

--
-- Name: users; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(50),
    role text DEFAULT 'member'::text,
    permissions jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    email_verified boolean DEFAULT false,
    email_verified_at timestamp with time zone,
    reset_password_token character varying(255),
    reset_password_expires timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    building_id uuid,
    member_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_login_at timestamp with time zone,
    deleted_at timestamp with time zone,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['super_admin'::text, 'admin'::text, 'manager'::text, 'member'::text])))
);


ALTER TABLE public.users OWNER TO "mini-server";

--
-- Name: voting_results; Type: TABLE; Schema: public; Owner: mini-server
--

CREATE TABLE public.voting_results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    minute_agenda_item_id uuid NOT NULL,
    total_votes integer NOT NULL,
    votes_in_favor integer NOT NULL,
    votes_against integer NOT NULL,
    abstentions integer NOT NULL,
    quorum_percentage numeric(5,2) NOT NULL,
    is_approved boolean NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.voting_results OWNER TO "mini-server";

--
-- Name: document_categories id; Type: DEFAULT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_categories ALTER COLUMN id SET DEFAULT nextval('public.document_categories_id_seq'::regclass);


--
-- Name: document_shares id; Type: DEFAULT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_shares ALTER COLUMN id SET DEFAULT nextval('public.document_shares_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Data for Name: arrears; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.arrears (id, member_id, building_id, amount, original_amount, due_date, description, status, last_reminder_sent, reminder_count, settled_date, settlement_transaction_id, created_at, updated_at) FROM stdin;
ee60b8b1-eef6-4bac-aed0-e8827391b17f	1dfa75cd-fafd-43cd-a0f7-038c2ad76812	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	150.00	150.00	2025-01-31	Cuota enero 2025	pending	\N	0	\N	\N	2025-07-21 22:43:21.735595+00	2025-07-21 22:43:21.735595+00
3be52b03-5c1b-4fb7-8084-b0171850343b	6a62625e-1264-4588-b6bf-a7a8ca0771bd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	300.00	300.00	2024-12-31	Cuotas nov-dic 2024	overdue	\N	0	\N	\N	2025-07-21 22:43:21.735595+00	2025-07-21 22:43:21.735595+00
6acf5715-9bf5-4ee2-9e54-77f3338b34c4	b6c37c55-303d-4e66-8f5d-bedff8f735ee	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	75.00	75.00	2025-02-28	Cuota febrero 2025	pending	\N	0	\N	\N	2025-07-21 22:43:21.735595+00	2025-07-21 22:43:21.735595+00
\.


--
-- Data for Name: attendance_sheets; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.attendance_sheets (id, building_id, convocatoria_id, minute_id, meeting_date, total_members, present_members, represented_members, created_at, updated_at) FROM stdin;
c4015d48-f46c-49ba-b7a4-6f5949973777	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	2025-11-15	7	3	1	2025-10-26 02:24:08.925+00	2025-10-26 02:34:01.613+00
bc107c45-36b5-4af5-ae9a-02ffc46c8699	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	2025-11-15	7	3	1	2025-10-26 03:14:42.665+00	2025-10-26 16:36:12.997+00
\.


--
-- Data for Name: attendees; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.attendees (id, attendance_sheet_id, member_id, member_name, attendance_type, representative_name, signature, arrival_time, created_at, updated_at) FROM stdin;
cbb3f0bd-18cc-442a-943d-e57503a18433	c4015d48-f46c-49ba-b7a4-6f5949973777	1dfa75cd-fafd-43cd-a0f7-038c2ad76812	Cristina Maria Bertolo Gouveia	present	\N	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAAnA0lEQVR4Ae3dS8xcZf0H8INCa1toaaJtFWOkqE28YBobFXShMS5UggvdSIMXdGUgNMSlcctGbULiLU1MMNWVCQmJcSNxwcaNIN4vLLrwBhItIOkV+fMb/s85z0znnXcu58yceeYzyct5ZuZcnufzO+X9zjNn5r3qpZdvlRsBAgQIECBAgACBQgVeVei4DIsAAQIECBAgQIDAQEDgdSIQIECAAAECBAgULSDwFl1egyNAgAABAgQIEBB4nQMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARe5wABAgQIECBAgEDRAgJv0eU1OAIECBAgQIAAAYHXOUCAAAECBAgQIFC0gMBbdHkNjgABAgQIECBAQOB1DhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHidAwQIECBAgAABAkULCLxFl9fgCBAgQIAAAQIEBF7nAAECBAgQIECAQNECAm/R5TU4AgQIECBAgAABgdc5QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4HUOECBAgAABAgQIFC0g8BZdXoMjQIAAAQIECBAQeJ0DBAgQIECAAAECRQsIvEWX1+AIECBAgAABAgQEXucAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1zlAgAABAgQIECBQtIDAW3R5DY4AAQIECBAgQEDgdQ4QIECAAAECBAgULSDwFl1egyNAgAABAgQIEBB4nQMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARe5wABAgQIECBAgEDRAgJv0eU1OAIECBAgQIAAAYHXOUCAAAECBAgQIFC0gMBbdHkNjgABAgQIECBAQOB1DhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHidAwQIECBAgAABAkULCLxFl9fgCBAgQIAAAQIEBF7nAAECBAgQIECAQNECAm/R5TU4AgQIECBAgAABgdc5QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4HUOECBAgAABAgQIFC0g8BZdXoMjQIAAAQIECBAQeJ0DBAgQIECAAAECRQsIvEWX1+AIECBAgAABAgQEXucAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1zlAgAABAgQIECBQtIDAW3R5DY4AAQIECBAgQEDgdQ4QIECAAAECBAgULSDwFl1egyNAgAABAgQIEBB4nQMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARe5wABAgQIECBAgEDRAgJv0eU1OAIECBAgQIAAAYHXOUCAAAECBAgQIFC0gMBbdHkNjgABAgQIECBAQOB1DhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHidAwQIECBAgAABAkULCLxFl9fgCBAgQIAAAQIEBF7nAAECBAgQIECAQNECAm/R5TU4AgQIECBAgAABgdc5QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4HUOECBAgAABAgQIFC0g8BZdXoMjQIAAAQIECBAQeJ0DBAgQIECAAAECRQsIvEWX1+AIECBAgAABAgQEXucAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1zlAgAABAgQIECBQtIDAW3R5DY4AAQIECBAgQEDgdQ4QIECAAAECBAgULSDwFl1egyNAgAABAgQIEBB4nQMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARe5wABAgQIECBAgEDRAgJv0eU1OAIECBAgQIAAgasRECBAgED/Ba666qqhTsb9//3vf0OPuUOAAAEC4wUE3vEuHiVAgMDSBa6++uo6xL700kuD40ewTe28Q+Mey5/XJkCAAIFGwCUNjYUWAQIEOhfYsWNH9epXv7p61ateVUWYzX9efPHFQbjNw2zeHu1c7CN+Yn9ve9vbRp92nwABAgT+X+Cql/9n+so0AhICBAgQaEXg2LFj1eOPP17PzK7if7MRpOMWywjEFy9ebGVsdkKAAIF1FDDDu45V02cCBHolcM011wzN1P7yl78cXJoQQXdS2E2zuzFLe9NNN9Wzu6PbxPPx2G233TYIr2m7SQjp2HGd76VLl4b6F/vbt2/fpM09R4AAgaIEzPAWVU6DIUBgmQIRdC9fvrztIVNAnXamNdZPtwincanDNLfoT1p3NDRvtX0cy4ffttLxOAECpQgIvKVU0jgIEFiawFZBN8JjBNRpQvBWnZ037G61v/T4nj17qvPnz9ezyOnxtIzjXnfdddWzzz6bHrIkQIBAMQICbzGlNBACBLoW2CrozjILO6mPsZ80M9vWPrc6XnwjRJoNHl3HrO+oiPsECKy7gGt4172C+k+AQOcCEXQjBI7O3KaAulVwnKVjEUBT2I1jtbHPScePsaTrfON4+S0ej8difK71zWW0CRBYVwEzvOtaOf0mQKBzga5ndPMB5KEzBd/8+WW0zfouQ9kxCBBYhYAZ3lWoOyYBAr0WWMaMbg4QM6npFqFzVTezvquSd1wCBLoWaP4v2/WR7J8Agd4L3H333dXhw4er+IBTfKNA/EQYG/2J2cj8J56Pdd/4xjf2foyTOrjsoBt92bVr19ClDPEVYn24xTc3xExz1DW/xWPPPfdcfclD/pw2AQIE+irgkoa+Vka/CLQoEKFlFV89ld6mj+Vdd91VnTp1qsVRtbur1Nd8rxHku76WNj/uqi5lyMc8qR0e4/oYY1jF+TWpr54jQIBALiDw5hraBAoSePrpp6tDhw6NDSiLDjMPabGvcSFou2OkfezcubM6d+7cdqt3+nzqSzrIMoJuHCsPkMs6ZhrjIsutrvWNF1ajH+xb5Di2JUCAQFsCLmloS9J+CPREIEJHBLiDBw9eEUTj8fQTASvewt+/f391yy23VA8//PBg/Qiv2/3EbF7+k68fITv2PRoiR3nSNvHdsKlPsYxtl3nL+xnt6FfXs7ppfHGsuMVxl3XMdOxFlltd6xtjWHb9FhmHbQkQ2BwBM7ybU2sjLVhg0mxuhKlvfvOb1YkTJ1YuELO56RrVFPa26lT0u+u3yeMY6RZBbZmhMz/2dhapj31d7tixo65r6uOyPdNxLQkQIDBOQOAdp+IxAmsiMOna3HUKHJ/+9Kerhx56qJ5Zzvm7GkceOLs6Rj6OvJ3XbRnBPj92l+1wzMN7SWPr0s2+CRDoXmC57x12Px5HIFC8QMzmRrAYFybisZMnTy71bfk2wH/84x8PZldjRjcCU4wj3eKxuH/ttdemhxZe5vtfdtiNzucz13l74YGteAcxlre85S11L1ItI+C7ESBAYJUCAu8q9R2bwAwCk67NTTNrETj6cOnCDMMau2qM493vfvfQcy+88MIg+H73u98denzWO6sOu1GrdDty5EhqFrP8y1/+suWLlmIGaSAECKydgEsa1q5kOrxJAutybW6XNRn3jQARWueZGV112A2n1Id5x9CldRf7TuNN+96UcafxWhIg0A8BgbcfddALAlcIjAaFtMIq3oJPx17lMs1i532YJTzlnqsyzMeQX+uaj6nEdj7uNL7jx49Xp0+fTnctCRAg0KlA895ap4excwIEZhHIw1lsF/cfeOCBtbs2d5Yxb7duzOima0LTuun+dteI5p6rCrvR5xRy8/6ksZS8TLXLx/jDH/7QV5jlINoECHQqIPB2ymvnBGYT+OIXv1i/5R1bRjCKkBSB4Z577pltZ4WuncJTHhrjsbg/7oNt+XqrDLt5KI8/J7yJtziXowbpll6w7N27Nz1kSYAAgU4Emv/zdLJ7OyVAYFqBw4cPV9///vfr1eOPQkSQcxsvEDZbfbDt29/+9mCjvoTd6Exey/gA3qbe4ruOU9BNBs8///xQEE6PWxIgQKAtAdfwtiVpPwQWENi9e/fQn9fdt29fdfbs2QX2uFmbjvtgWy6wypnd6EfM7qbAG31Nf3wj7+MmtnOXNH4+ScKSAIE2BczwtqlpXwTmEIhf+ufOnau3vPnmm4XdWmO6RvpTt/mMbtpy1WE3+pHCbrSF3VB45TZutjdqmV/2kNa1JECAwCICAu8ierYlsKDA6AzX/fffXz3xxBML7nVzN8+DZVIY91h6bhnLmLFMt6i325UCUaPcZvRa3yu38AgBAgRmE3BJw2xe1ibQmkDMYsUv9nTL2+kxy9kERk3zrVflm886r6oPuUPf27lXtFf9gqXvXvpHgMB0AmZ4p3OyFoFWBUaDmSC0OG98yC85RlCK9mh4Wvwos+1h586d9Qbepq8pJjZSDWOlaHObyOVJAgSmFDDDOyWU1Qi0JSDstiU5vJ883OahaZXeW/VpuOfujRPI7aKGcb2vGwECBOYVMMM7r5ztCMwhsMrwNUd312aTcE23/FrQeCzeEs+fjyD1+c9/Pq3e2fLWW2+t952Ht/pBjYkC+YuW0Wt8J27oSQIECIwRMMM7BsVDBLoQyMNuBCDXJraj/NOf/rT6+Mc/PtjZJNfRDwgeOHCgeuqpp9rpxJi95PXOw9uYVT00QSB/seAryyZAeYoAgYkCAu9EHk8SaEcg/6U9KZS1c7TN2ktuu12wjGtqL168WAN1GaBSv9S75p6rcebMmerGG2+st40anj9/vr6vQYAAgWkEmvcBp1nbOgQIzCyQgk9sKPzMzDdxg/zyhfyyha02unDhQnXDDTfUT8d3vub7qJ9YsJH3xUz+YphvfvObq4MHD9Y7iRrefvvt9X0NAgQITCNghncaJesQmFNA2J0TbsrNct/tZnfzXd53333VyZMn64cioLb5oajULy9wauKFG/EtHPECJd1mqXfaxpIAgc0VEHg3t/ZG3rFAfg2n4NM+du775S9/ufrWt74180FSMI0N26pR3i+hbOaSTNwgLkHJX5jwncjlSQIEMgGBN8PQJNCWwI4dO+o/IdtWkGqrbyXsJ5/tW9S37dCb708ga/9sG/3wIeP2je2RQIkCAm+JVTWmlQsIPd2WoG3ffH/RXuS627Svti+T6FZ0vfYu9K5XvfSWQB8EfGitD1XQh6IEIuik25e+9KXUtGxJIPdt6wNn+SxhtE+fPj1Xb/O+5W+9z7UzG20pELbphUWslLe33MgTBAhstIAZ3o0uv8G3LeBShrZFh/f38MMPV5/85CcHDy46Ezu851fupeA0777T9rG3PESPO5bHFheIFxjJed6aLd4LeyBAYB0EBN51qJI+ro2AwNNtqbr2zQNUClKzjCj1L/ZjhncWufnXzWsm9M7vaEsCpQs0772WPlLjI9CxQPziTTeXMiSJ9pb55Qu5dXtHeOXPEKf9zXqMfH1hNyl2v4zrrdMLjXlepHTfQ0cgQKAPAmZ4+1AFfVh7AZcydF/CFGriSF0Gmwiuaf9pOc3oltW/afqyiesk/6ifFxybeAYYM4HJAs2U1OT1PEuAwASBS5cu1c8u8gn/eicaQwL57O7dd9899Fzbd66//vp6l/G9r7Pe8pneWbe1/uICs7xIWfxo9kCAwLoImOFdl0rpZ28F8hnBuJTh1KlTve3runYsN15GoEmzheE1zfGW3b91rWOX/VaDLnXtm8D6C5jhXf8aGsEKBeJShhSIIiQJu90UIzfu5gjDe43wlG4PPvhgam65TP3bcgVPdC6QvwvQ+cEcgACBtRMww7t2JdPhPgnMOhPYp76vU1+ScwTRZV2fmY4Zy+0uU0nrLrN/61S/ZfVVHZYl7TgE1k+gmcZYv77rMYGVCuSzgL6VobtSxJ8RTrdlhd04XgpP283e5ufBMvuXTCyvFNjuBcqVW3iEAIHSBczwll5h4+tEwLcydMI6dqcRKFPoTMuxK3bwYAq9sdwqRKV14vDL7l8HQ17rXa7yXFlrOJ0nsAECZng3oMiG2L6Ab2Vo33SrPaYQmQfLrdZt+/F0zNSHSfvPZ3onree57gQOHjxY7/zAgQN1W4MAAQICr3OAwIwCebBxKcOMeGu2+v79++sej/uKsvxccDlDTbWyxj/+8Y/62M8880zd1iBAgIBLGpwDBGYUSLN+sdk0M38z7t7qmcCf//zn6siRI4NHXvva11b/+te/smeX05xU70nPLad3jjIqoCajIu4TIBACAq/zgMCMAukXaszumdWbEW/G1eOrptK1s6t6cRF1TsdOyzQM50KS6M+yD+dMfzT0hACBJOCShiRhSWAKgVV9Y8AUXStyldGAuYpB5pct5MfPv/fVC59cZrXtvBb5v9fV9srRCRBYtYDAu+oKOP5aCVy+fHmt+rvunU2BN82k9mk8qW996pO+DAvk4Xf4GfcIENg0AYF30ypuvK0I9DGAtTKwnu6kj94p8Paxbz0t49K6lWqSarS0AzsQAQK9FRB4e1saHeubwN69e+supetK6wc0WhfI347u80xdCletA9ghAQIECLQmIPC2RmlHpQv897//LX2IvRpfn0Pua17zmtqqz/2sO6lBgACBDRcQeDf8BDD86QXS26Nm9KY3W2TN5L3IPrra9uLFi13t2n5bEEjnjn+rLWDaBYFCBATeQgppGN0KHD16tD7AHXfcUbc1uhcQWro3dgQCBAiULuB7eEuvsPG1IjDpu1hbOYCdDAk89thj1Xve857BY6v6gxOpQ/EX1tJlC6MzhxHGXc+dpPqzTC+S4qvjfLNKf+qiJwRWKSDwrlLfsddGIP0CFXCWU7I+/fGASYFXoFrO+TDLUeIv88Vf6ItbeoEyy/bWJUCgTAGXNJRZV6NqUeD06dP13g4dOlS3NboT6HNQyb89wuxhd+fAvHt+8skn593UdgQIFCxghrfg4hpaOwIuZ2jHcZa99GlGfXSG1/kwSyWXv676LN/cEQmsg4AZ3nWokj6uVCDNNqYQttLObNjB+2iezocNK8XaDDfVp4/nztog6iiBAgUE3gKLakjdCOzYsaObHdvrkMBXv/rV+v6tt95at1fVSAFq9PgC1aiI+wQIEOivgEsa+lsbPeuBQITcS5cuDXqyVfDpQTeL6kKfPrAWsKNvkaegG5c6pHOjqAKs+WBSfXygcM0LqfsEWhYww9syqN2VJeBDScuvZ99eWOT9iRCVbsJukujPMr6hId38200SlgQIhIAZXucBgQkCo7N7E1b1VEsCaYYuln34jtu8PzHEFIDTsqVh200LAv69toBoFwQKFTDDW2hhDasdgRRqUuhpZ6/2Mo1A38yjP86HaSq3mnVi9l19VmPvqATWQUDgXYcq6SOBDRHo2wfWcvbDhw/nd7V7JpC/G5C3e9ZN3SFAYEUCAu+K4B12vQRe//rXr1eH17S3999/f93zRx99tG6vqrFz58760MePH6/bu3btqtsaqxeISxnS7YYbbkhNSwIECNQCruGtKTQIDAvceeedVfora+mt0uE13GtboG/XYOb9iXaaOXQ+tF35+feXf6tHXHaSajT/Hm1JgECJAgJviVU1plYEfCVZK4wz7SRdt9uX4CLwzlS+layczpk4uBciKymBgxJYC4HmfaC16K5OEliegK81Wp716JHyEDP63DLvpwAV/UntZR7fsSYLxAuSdHMpQ5KwJEBgnEDzf4txz3qMAAECSxL42te+Vh/plltuqdsaBMYJjH4rw1//+tdxq3mMAAECAwGXNDgRCGwhkGYZY+m6wC2QWnw4vxazL7Op6RxIfUv9SssWh29XMwqk2sRm6jEjntUJbKCAGd4NLLohE+ijQB5g+tC/j3zkI3U34vKWFKr61s+6kxvUcCnDBhXbUAm0JGCGtyVIuylPIAWbN7zhDdXf/va38gbYsxFdffXV1YsvvjjoVQqXq+xi/oG16E86H2Jpxn91lUmz7dEDtVhdHRyZwLoJmOFdt4rp71IE8u9cFXaXQt6rg8SLnBS6U9DtVQc3tDOHDh0aerHhhceGngiGTWAOATO8c6DZpHyB+MMC58+fHww0BZ82R51mD81QNap9muHNQ26qf3pMzZqaLbOV/s2kY8a3MvigWtKwJEBgOwEzvNsJeX4jBc6dO1eP+/3vf3/dbqNx++2317OH6a3y3bt3V7///e/b2H1n+/jVr35V3XvvvdWpU6c6O0Yfdhxvmadbfq1oeiwF33TfsluBeCEU5umFRxwt6iLsdutu7wRKEzDDW1pFjac1gRRsupjR27dvX/Xcc89d0df45X7XXXdV3/ve9654bhUPRMj4wQ9+UD344IPVz3/+80EX3vWud1W//vWvW+9OX2Z4U91jgHnISo9HIPYdza2Xf+wOR2d1u/i3OPbAHiRAoDgBgbe4khpQWwIp4HT5S3b0F3rqexzz7W9/e/Xb3/42PbTUZczmRsiNsPvvf/97cOxrr722+uxnP1t94QtfqI4dO9Z6f/oQePN6PProo9UHP/jBepzpfLjmmmuqixcv1o9rtC+Q1yHtnXuSsCRAYB4BgXceNdtshED+Szef6Wt78Plxxu07nj9w4EAVH6R6xzveUX3oQx8aBM8IiG3exs3mxv4/8IEPVJ/73OcGx9y5c2ebhxza16oDb1wT+ve//33Qp3EvclLgvfnmm6snnnhiqO/utCMQH0p76qmnhnY2rhZDK7hDgACBKQQE3imQrLKZAjGj+cILLwwG32XgjQPkoTd+wcc1venYk/Rj3dg2+nrTTTdVR44cqeKa40984hOD++O2feaZZ6rHHnus+s1vflP96U9/qs6cOVP98Y9/HMzkpmOm2dwIuu9973vH7ab1x1YdeFOgjYGN1vt1r3tdFW7jnhs86D8LC+T/BtLORuuQHrckQIDArAIC76xi1t8ogRSC3ve+91W/+MUvOh17OlYcJP2iv/HGGwfX+saH6OJt9PQ9tdN2JEJE/ESAvnTpUnXhwoWhr3Ua3U+azY2gu2PHjtGnO72/ysCbf7dreI06x9vp6brdVJtOMTZo53nd07DH1SA9Z0mAAIF5BATeedRsszECKYTGsuvv/HznO99Z/e53vxvYbheqzp49W50+fbqK60z/8Ic/DEJxfAguZmgj2G63fQS4PXv2VPv3768OHjxYvelNb6puu+226s4771xZbfPQefLkyerEiRNL60uqcxxwnF3et3HPL62jhR0ogm3uuYx/Z4URGg4BAlMKCLxTQlltMwVSEFrGL+JZAu801fjZz35WPfLII9Xjjz8+uP73wx/+cHX06NEqjtPX2zK9k0E6Ztwf/aBaWiefhcwDWnrecjaB0aAbW/tQ2myG1iZAYDYBgXc2L2tvmED+i7nroNN24F3HUi3TO3zysBvHHr2UIRkKvElisWW8m/D0008P7WQZLyaHDugOAQIbKeAPT2xk2Q16WoG49jXdPvOZz6RmJ8u4vnbTb/llIxFAu7xNG3a77MMm7TvqORp240VkXvNN8jBWAgSWK2CGd7nejraGAnkw6nKW961vfWv15JNPDoS6PE7fS7CMWd68ppNmdpOVGd4kMfsyt0tbT2Oe1rUkQIBAGwLdTqG00UP7ILBigfjlnG533HFHalp2JJB/12+EpbZvs4bdto+/SfsbDbZhHy/mtrp0ZJNsjJUAgeUKmOFdrrejralAHpK6mn01w9ucHF155/sdDWPN0a9s5bOUXdX/yqOu7yNhO+rkQ2nrW089J1CCQDN1VcJojIFARwL5LO/x48c7OordJoHcO2+n52ddxl+qmzfsznqsTV4/PpQWznnYTff9OeZNPjOMncDqBczwrr4GerAmAnlgyn+ht9X9rvffVj+XtZ98ljBs5v1wU76f6Hvcn/UtdTO821d91Dm26OLfyfY9sQYBAgSuFDDDe6WJRwiMFYhf6OnW9ixvvu9469etGgTc9CIgglNuNI1PrB/b56ErHps17E5zrE1eJ14MjHPO3TfZx9gJEOiHQPMbvB/90QsCvRXIg9KPfvSj6jvf+U4rfb3uuuvqUBbBwVu/DWvM6uahN9oRWuMn/vpZvDg4c+ZMs8HLrXh8NICl+3kNhzZyZy6B0RcQnOditBEBAksQcEnDEpAdohyB/E/MplFdf/311X/+8590d6blV77yleob3/hGvY1ZsZpiqBHBah6bCGDzXgqRd8AlDbnGK5eFjNbDh9KGjdwjQKBfAgJvv+qhN2sgsFX4mjVc7d+/vzp79mw94tEAUT+hMRAI97hN6xQfoPrnP/852GbR/wi8rwiOe8E363m/aC1sT4AAgXkEXNIwj5ptNlogZgwjdO3atWvIIR6LX/7xE+EsZryOHj06tM7zzz8/eC7WycPusWPHhtZz50qBcE/2YZ1+vv71rw8uYwjzZB/PtRV2r+zJ5j2SbEdny8N59LHN0zFiAgTWQcAM7zpUSR97LfCpT32qeuihh6aeeRwdzN69e6tnn3129GH3eySwiTO88QdALl26NPa8jgDseugenaC6QoDAtgIC77ZEViAwvUAEgbjFzNekW8xE/uQnP6k+9rGPTVrNcz0R2KTAO+6yhShDnLM7duyozp8/35Oq6AYBAgSmF3BJw/RW1iSwrcC4t93vueeeas+ePYPAsHv37kEYjvWE3W05rbBEga0uW4igmy5dEHaXWBCHIkCgVQEzvK1y2hkBAiUKlDrDG9eZX758eWzJYqZ3q+fGbuBBAgQI9FjADG+Pi6NrBAj0TyBdttK/nk3fozSbOxpoYzb3vvvuG8zojj43/d6tSYAAgf4JmOHtX030iACBHgpESEzXZkcwXLdvJ/joRz9aPfLII/UYcuJ1HE/ef20CBAhsJyDwbifkeQIECPy/wLqF3rgsIUJ6CuqjhYxLNeKbGNwIECBQuoDAW3qFjY8AgVYF8tAbO+7Lta7bhduEYDY3SVgSILBJAgLvJlXbWAkQaEVgNPTGTiNIxuPLuPZ12nCbBht9ix/fnZtELAkQ2DQBgXfTKm68BAi0IjAu9KYdtxl+5wm30Y/4BoYLFy6kLlkSIEBgowV8S8NGl9/gCRCYVyA+tBbXxt57772D2dN8P/F4zKammdVFluk4+f5TO+03/iBEulY31o8fYTcpWRIgQODld+Fe/p/k5D8JRYkAAQIEphI4ceJE9cADD2z5IbGpdrLFShFu42bmdgsgDxMgQGCCgMA7AcdTBAgQmFcghd95t4/thNtF9GxLgACBRkDgbSy0CBAgQIAAAQIEChRwDW+BRTUkAgQIECBAgACBRkDgbSy0CBAgQIAAAQIEChQQeAssqiERIECAAAECBAg0AgJvY6FFgAABAgQIECBQoIDAW2BRDYkAAQIECBAgQKAREHgbCy0CBAgQIECAAIECBQTeAotqSAQIECBAgAABAo2AwNtYaBEgQIAAAQIECBQoIPAWWFRDIkCAAAECBAgQaAQE3sZCiwABAgQIECBAoEABgbfAohoSAQIECBAgQIBAIyDwNhZaBAgQIECAAAECBQoIvAUW1ZAIECBAgAABAgQaAYG3sdAiQIAAAQIECBAoUEDgLbCohkSAAAECBAgQINAICLyNhRYBAgQIECBAgECBAgJvgUU1JAIECBAgQIAAgUZA4G0stAgQIECAAAECBAoUEHgLLKohESBAgAABAgQINAICb2OhRYAAAQIECBAgUKCAwFtgUQ2JAAECBAgQIECgERB4GwstAgQIECBAgACBAgUE3gKLakgECBAgQIAAAQKNgMDbWGgRIECAAAECBAgUKCDwFlhUQyJAgAABAgQIEGgEBN7GQosAAQIECBAgQKBAAYG3wKIaEgECBAgQIECAQCMg8DYWWgQIECBAgAABAgUKCLwFFtWQCBAgQIAAAQIEGgGBt7HQIkCAAAECBAgQKFBA4C2wqIZEgAABAgQIECDQCAi8jYUWAQIECBAgQIBAgQICb4FFNSQCBAgQIECAAIFGQOBtLLQIECBAgAABAgQKFBB4CyyqIREgQIAAAQIECDQCAm9joUWAAAECBAgQIFCggMBbYFENiQABAgQIECBAoBEQeBsLLQIECBAgQIAAgQIFBN4Ci2pIBAgQIECAAAECjYDA21hoESBAgAABAgQIFCgg8BZYVEMiQIAAAQIECBBoBATexkKLAAECBAgQIECgQAGBt8CiGhIBAgQIECBAgEAjIPA2FloECBAgQIAAAQIFCgi8BRbVkAgQIECAAAECBBoBgbex0CJAgAABAgQIEChQQOAtsKiGRIAAAQIECBAg0AgIvI2FFgECBAgQIECAQIECAm+BRTUkAgQIECBAgACBRkDgbSy0CBAgQIAAAQIEChQQeAssqiERIECAAAECBAg0AgJvY6FFgAABAgQIECBQoIDAW2BRDYkAAQIECBAgQKAREHgbCy0CBAgQIECAAIECBQTeAotqSAQIECBAgAABAo2AwNtYaBEgQIAAAQIECBQoIPAWWFRDIkCAAAECBAgQaAQE3sZCiwABAgQIECBAoEABgbfAohoSAQIECBAgQIBAIyDwNhZaBAgQIECAAAECBQoIvAUW1ZAIECBAgAABAgQaAYG3sdAiQIAAAQIECBAoUEDgLbCohkSAAAECBAgQINAICLyNhRYBAgQIECBAgECBAgJvgUU1JAIECBAgQIAAgUZA4G0stAgQIECAAAECBAoUEHgLLKohESBAgAABAgQINAICb2OhRYAAAQIECBAgUKCAwFtgUQ2JAAECBAgQIECgERB4GwstAgQIECBAgACBAgUE3gKLakgECBAgQIAAAQKNgMDbWGgRIECAAAECBAgUKCDwFlhUQyJAgAABAgQIEGgEBN7GQosAAQIECBAgQKBAAYG3wKIaEgECBAgQIECAQCMg8DYWWgQIECBAgAABAgUKCLwFFtWQCBAgQIAAAQIEGgGBt7HQIkCAAAECBAgQKFBA4C2wqIZEgAABAgQIECDQCAi8jYUWAQIECBAgQIBAgQICb4FFNSQCBAgQIECAAIFGQOBtLLQIECBAgAABAgQKFBB4CyyqIREgQIAAAQIECDQCAm9joUWAAAECBAgQIFCggMBbYFENiQABAgQIECBAoBEQeBsLLQIECBAgQIAAgQIFBN4Ci2pIBAgQIECAAAECjYDA21hoESBAgAABAgQIFCgg8BZYVEMiQIAAAQIECBBoBATexkKLAAECBAgQIECgQAGBt8CiGhIBAgQIECBAgEAjIPA2FloECBAgQIAAAQIFCgi8BRbVkAgQIECAAAECBBoBgbex0CJAgAABAgQIEChQQOAtsKiGRIAAAQIECBAg0AgIvI2FFgECBAgQIECAQIECAm+BRTUkAgQIECBAgACBRkDgbSy0CBAgQIAAAQIEChQQeAssqiERIECAAAECBAg0AgJvY6FFgAABAgQIECBQoIDAW2BRDYkAAQIECBAgQKAREHgbCy0CBAgQIECAAIECBQTeAotqSAQIECBAgAABAo2AwNtYaBEgQIAAAQIECBQoIPAWWFRDIkCAAAECBAgQaAT+D97h0l6XqISfAAAAAElFTkSuQmCC	\N	2025-10-26 02:34:01.62+00	2025-10-26 02:34:01.62+00
cff5e4cf-c16b-48d5-86e7-c291b36c4a84	c4015d48-f46c-49ba-b7a4-6f5949973777	6a62625e-1264-4588-b6bf-a7a8ca0771bd	José Manuel Costa Ricardo	represented	jose alves	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAAnh0lEQVR4Ae3da6wcZfkA8On1tPRCgXItSMKtYEUEU6oRlYABCRGDMYAhXkOMYgMqH/yiiaYavhiMFyAUE40aBDFR+VJMTJQIpqlyEcsdgxaVIBcppdB7/7zzZ5Y5ey67Z3Zmd+ad3yTlzO7OvO/z/N45nOe8593ZWftf3xIbAQIECBAgQIAAgUgFZkeal7QIECBAgAABAgQIpAIKXhcCAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQIECBAgQIBA1AIK3qiHV3IECBAgQIAAAQIKXtcAAQKVCsyaNSsJ/2bP9r+bSqE1ToAAAQJTCvgJNCWNFwgQGFQgX+Tu379/0OacT4AAAQIECgkoeAuxOYkAgV4Cc+bMSRS5vZS8ToAAAQLDEFDwDkNZHwRaKLBv374WZi1lAgQIEKijgIK3jqMiJgINF5g7d24ng/yyhs6TdggQIECAwBAFFLxDxNYVgTYKhDes2QgQIECAwCgFFLyj1Nc3AQIECBAgQIBA5QIK3sqJdUCgfQJmdds35jImQIBAnQUUvHUeHbERIECAAAECBAgMLKDgHZhQAwQIdAuMjY11P+UxAQIECBAYmYCCd2T0OiYQr4A7M8Q7tjIjQIBAEwUUvE0cNTETIECAAAECBAj0LaDg7ZvKgQQIECBAgAABAk0UUPA2cdTETIAAAQIECBAg0LeAgrdvKgcSINCvgDW8/Uo5jgABAgSGIaDgHYayPggQIECAAAECBEYmoOAdGb2OCRAgQIAAAQIEhiGg4B2Gsj4IECBAgAABAgRGJqDgHRm9jgkQIECAAAECBIYhoOAdhrI+CBAgQIAAAQIERiag4B0ZvY4JECBAgAABAgSGIaDgHYayPggQIECAAAECBEYmoOAdGb2OCRAgQIAAAQIEhiGg4B2Gsj4IECBAgAABAgRGJqDgHRm9jgm0T2DWrFmJT2Fr37jLmAABAqMWUPCOegT0T6BlAvv3729ZxtIlQIAAgVELKHhHPQL6JxChwKpVq6bMygzvlDReIECAAIGKBBS8FcFqlkCbBa666qpJ0w/F7t69eyd9zZMECBAgQKAqAQVvVbLaJdBigUsvvbST/de+9rUkW7ur2O2w2MkJPPPMM+k1MmfOnNyzdgkQIFCewKzX19NZUFeep5YIEHhDIBS5YQvLGzZv3vzGs74QmCiQXSvhFX8FmOjjGQIEBhcwwzu4oRYIEJhG4Omnn57mVS+1XSBf7AaLffv2JWZ6235VyJ9A+QIK3vJNtUiAQE7g1VdfzT2yS+D/Ba688sp0GUPmccwxx3Qeh6LXRoAAgTIF5pbZmLYIECDQLWDdbrdIux9/4QtfSG688cYkv5ouFLtbtmxJYcbGxpIjjzyy3UiyJ0CgdAFreEsn1SABAkEg+1N1+GrGzjUxWaEbVE455ZTk4YcfBkSAAIFKBSxpqJRX4wQIEGi3wNq1a9M3ot1www3jZnVXr16dPlbstvv6kD2BYQlY0jAsaf0QaJlAmNkNf7bO/+m6ZQStTzfccaF7/EOhu2nTptbbACBAYLgCCt7heuuNAAECrRDoLnYVuq0YdkkSqK2Agre2QyMwAgQINFNg7ty5nZndgw46KHnxxRebmYioCRCIRsAa3miGUiIECBAYvcD8+fM7Hx+9YsUKxe7oh0QEBAi8LqDgdRkQIFCJQJjls7VLYPHixcnu3bvTpA888MDkX//6V7sAZEuAQG0FFLy1HRqBEWi2wNKlS5udgOhnJLB8+fJk+/bt6TkLFixIXnrppRmd72ACBAhUKaDgrVJX2wRaLLBy5coWZ9+u1I877rjkhRdeSJMOM/uvvfZauwBkS4BA7QUUvLUfIgESaKbAVVdd1czART0jgTPPPDN56qmn0nPCnRmyJQ0zasTBBAgQqFhAwVsxsOYJtFXg0ksv7aT+jW98o7NvJx6BSy65JPnzn/+cJhTuu+xjpOMZW5kQiE1AwRvbiMqHQA0Fbr/99hpGJaRBBNatW5fkx9XHRw+i6VwCBKoWmPX6p+Dsr7oT7RMg0E6BMOsXtvAGtq1bt7YTIcKs77rrruTss8/uZLZz584k3I7MRoAAgboKmOGt68iIi0BEAq+++mpE2UglX+zeeuutil2XBAECtRdQ8NZ+iARIoPkC1nY2fwyzDLJZ+/D46quvTvJrtbNjfCVAgEDdBCxpqNuIiIdARAJZcRS+WuPZ/IENyxayuzCcf/75yZ133tn8pGRAgEArBBS8rRhmSRIYjYCCdzTuVfR66KGHJs8//3za9PHHH588+eSTVXSjTQIECFQiYElDJawaJUAgCGQFr/fGNvt6ePe7390pdg8++GDFbrOHU/QEWimg4G3lsEuaAAEC/Qlce+21ycaNG9ODw6eoZZ+o1t/ZjiJAgEA9BCxpqMc4iIJAlALhk7ey2d3sa5SJRpxUNktvHXbEgyw1Ai0QMMPbgkGWIgECBIoIzJkzp3Pahg0bOvt2CBAg0DQBBW/TRky8BBokEP4EbmumwOLFizt31rj44ouTcFcGGwECBJoqYElDU0dO3AQaILBs2bLOJ6xZ0tCAAXsjxOOOOy556qmn0kdvectbkn/+85/NCV6kBAgQmETADO8kKJ4iQKAcgYMOOqichrQyNIHLLrusU+wuXLhQsTs0eR0RIFClgIK3Sl1tE2i5wJIlS1ou0Kz077777uS2225Lgw5vOPSR0M0avzpHu3Tp0iRcU+HNj+GrjcCwBVx1wxbXH4EWCYQPK7A1R+B973tfJ1gfB92hsFNA4B//+Eda3IYCN/zbtm2bO7YUcHRKeQLeUVKepZYIEOgSOProo7ue8bCuAmGtbrbO+qtf/WpdwxRXAwTCm1Wn+4UpLJWxERi2gIJ32OL6I9AigZNOOqlF2TY31T179iRPP/10mkD4JWXdunXNTUbkIxXI33u7OxD3cu4W8XiYApY0DFNbXwRaJrB69eqWZdzMdA877LA08FCQZIVvMzMR9agEjj322HTpQvZXgu44whreffv2dT/tMYGhCZjhHRq1jgi0T+C8887rJP3yyy8n4YeerV4CP//5z5P//e9/aVAf+MAH6hWcaBohYFa3EcPU+iDdh7f1lwAAAtUKhFnDsN1xxx3Jhz70oWo70/qMBRYsWJDs3LkzCZ+qFpY22Aj0K/COd7wj+etf/zrl4fPnz0+vrSkP8AKBIQpY0jBEbF0RaLPAvffe2+b0a5n7lVde2SlIvvjFL9YyRkHVT+AnP/lJunxhumL3xBNP7Fxb9ctARG0UMMPbxlGXM4EhCmQzvB/72MeSW265ZYg966qXQPZu+vCueffc7aXl9SAw2fKF8D2eX7v72c9+NrnpppuAEaiVgDW8tRoOwRCIV+A///lPvMk1MLOzzz67c+uoX/7ylw3MQMjDFJiq0A3Fbv7NaPnCd5jx6YtALwEzvL2EvE6AwEAC2QzvqlWrks2bNw/UlpPLE8gKmOXLlyfPPfdceQ1rKSqB7DrJJ5UVud2vKXbzSvbrJmANb91GRDwEIhUId2mw1UMg/yETit16jEndogjLXbqXKmSPw4yuYrduIyaeXgIK3l5CXidAoBSBHTt2lNKORgYTWLt2bedeu25DNphljGeHWweGwjb/SWn5QjfknD3u3o/RQ07xCFjSEM9YyoRALQXCD8ewLVmyJDHLO9oh2rZtW3LggQembzA68sgjE+uqRzseder95JNPTh577LEJIV1yySXJbbfd1nk++34OT4T9/PrdzkF2CNRQQMFbw0EREoGYBLIfkO4EMPpRPeigg5KXXnrJPXdHPxS1ieDTn/508uMf/3hCPEcccUTyzDPPjHs++14OT4YlD7t37x73ugcE6ixgSUOdR0dsBCISyP+JNKK0GpPKOeeckxa7IeB169Y1Jm6BViOwZcuWdB1ud7E7b9689C8A3cVuWLObbaMsdr///e8n4QMv3vOe9yTr16/PQvKVQE8BM7w9iRxAgMAgAtms0Ch/SA4SfwznhvsfX3755Wkqp59+enLffffFkJYcCgp0v+EsNBOem+qX0vApfNnShWEuY7j77ruTW2+9Ndm4cWPy+OOPJ9u3b+/EEWI+9dRTkwcffDDs2gj0FFDw9iRyAAECgwhkBe90P1AHad+5vQXGxsaSXbt2JQcccEBaNPQ+wxExCkxW6PYqYMPa+1deeSXl6HXsoGZhxjZ84l+4VqcqvsMM9CmnnJKcd955SfgwmzPOOGPQbp3fEgEfPNGSgZYmgVELuEfnaEbg61//elpAhN7/8Ic/jCYIvY5UoEihGwJes2ZNp9gNj7NZ3rBf5nbzzTcnV199dfLaa69NaDbMLi9evDhZsWJFcvHFFyff/OY3JxzjCQL9CCh4+1FyDAECBBoq8Kc//SmN/IQTTkhWr17d0CyEXUSgaKEb+rrnnnuSTZs2dbqt4hfWyQrdsPQpzNp+5StfST7ykY90+rdDYFABBe+ggs4nQIBAjQXuv//+NLoLL7ywxlEKrUyB/JrbrN2ZLkc466yzslOT8EaxMrcf/vCHyVVXXTVuRjcUuldccUVy4403ltmVtgh0BKzh7VDYIUCgCoFsDe9Mf+BWEUsb28z8H3jggeS0005rI0Frcp4/f/6EW4WF8Q9j//a3v71vh+yaCSeE+/M+8sgjfZ871YF/+9vf0jW3Dz/8cHoXiOw4hW4m4WvVAm/eZ6TqnrRPgAABAkMV+M1vfpP2F960ptgdKv1QO1u2bFn6IRDd98W97LLL0nW3Myl2w7WSbeENYoMUuxdddFGyaNGiNLYQw0MPPdQpdkOh+7nPfS4t0M3qZuK+VilgSUOVutomQIDACAU+/OEPJ9dcc00SbkVmi08gLAuYbLlBWK/9xBNPzDjh8Klq4Q4JYQuzvNl+vw2F+zuHeJ5//vlOYdt9biioL7jgguRXv/pV90seE6hUwJKGSnk1ToBA9ufR8LWqd3lTJtA2gcnekLZ06dJk69athSmy79XQQL9vUvvkJz+Z/OxnP5vyezusJz722GOT733ve4l15IWHxoklCJjhLQFREwQIECBAYBgC4SN/n3322XFdheJ3qvvWjjtwmgfhfrvZ9olPfCLbnfLr2972tnSJQvcBoWgOSyw+/vGPJ9/97ne7X/aYwMgEzPCOjF7HBNohkM0ameFtx3jLsjqB7lndMr+nsu/TEP10s7uHHHJI8uKLL45LMpy7cuXKgdb7jmvQAwIVCHjTWgWomiRA4E2B7AfpdD9E3zzaHgEC3QLhzWPh+yj/PXT44YdPuYyg+/yZPD7++OMnHP7b3/42CWtvQwz5YjcsVwgfBBGWKg3y5rYJHXqCQAUCljRUgKpJAgQIECBQhkD2C2PWVnhc9lr4d73rXVnzyd///ve0sO08MclOuPNCKHzDbdBsBJoiYIa3KSMlTgIECBBojUBYvtBd7Ia7MpRd7AbQjRs3TuhrMuijjz46nWV+5ZVXFLuTAXmu1gJmeGs9PIIjQIAAgTYJfPnLX06+853vjEu5ilndcR28/iAU0mHmNrz5LRTb2Rb6XrVq1biPGc5e85VAkwS8aa1JoyVWAg0UyL/RJr8GsYGpCJlApQL575WsI98zmYSvBAYTePPXuMHacTYBAgQIECBQQCDcaizMpOaL2/BJZPnHBZp1CgECOQFLGnIYdgkQIECAwDAFumd1h7F8YZj56YtAXQTM8NZlJMRBgAABAq0RmOxWY4cddlglb0prDapECUwjYIZ3GhwvESBAYBQCYZbPTN8o5IfTZxjb/Gas8xr2CVQjYIa3GletEiDwhkD+Hd9QeguEm/mHzfrN3lZNOyJ8L3QXu2vXrjWr27SBFG8jBczwNnLYBE2gOQLdP+CbE/loIlXojsa9yl5POOGE9AMd8n2Y1c1r2CdQvYAZ3uqN9UCg1QJmeGc2/Lxm5lXno6+//vp0Rjd8ell+C7/UVPEBEvk+7BMgMF7ADO94D48IEChZINxeadeuXSW3qjkC9RYIv7h0z9aH5Sp79uypd+CiIxCpgII30oGVFoG6CIR3o9sItEVgskLX8oW2jL486yyg4K3z6IiNQAQCY2NjEWQhBQLTCyh0p/fxKoFRC1jDO+oR0D+ByAWWLl0aeYbNTS/8iT3MPub/WUM8s/HMDPPLF4Kndbozc3Q0gaoFFLxVC2ufQMsFFLz1uwCyAneyN07lC7f6RV6fiBYuXJj+opA3VOjWZ3xEQqBbQMHbLeIxAQKlCixfvrzU9jQ2mEAoyrq3rADOng9vNLRNLnDiiSemhe6OHTvGHfDBD37QnRfGiXhAoF4CCt56jYdoCEQnsGLFiuhyampC+WI3m43M/vSen6nM7zc117Ljvvnmm5Ow3OPJJ58c1/SyZcvS5QsbNmwY97wHBAjUS8Cv8fUaD9EQiE4g3HTfNnqBfLEbCre9e/dOCCpfBE94scVPTPaGNLcYa/EFIfVGCpjhbeSwCZpAcwROP/305gQbaaT9FLsh9fxxq1atilSj/7RCoZv9EpCdlT12P91MxFcCzRCY9fqfs/Y3I1RREiDQRIFt27Yl2RvX/O+m9wiG9bPZ7OugXvm2Qs9Tzezmo8oXvYP2n2+3SfuTzegGF0s9mjSKYiUwXsAM73gPjwgQKFlgyZIlnRbvueeezr6dagW6i9vux1P1ni94Tz311KkOi/J5txiLclglRSAVUPC6EAgQGJrAvffeO7S+2txR9wxlKFyzWeNeLvlZzM2bN/c6PIrX3WIsimGUBIFpBRS80/J4kQCBMgUeffTRMpvT1iQC2RrT7KWwLOHBBx/MHvb1NT/L29cJDT3okEMOmfQWY+eff77lCw0dU2ETmEpAwTuVjOcJEChdYMuWLaW3GVuDa9eu7aT0i1/8orPfz06Y2c227sI3e76fr/lZ3nyb/ZzbhGOyQvfFF18cF252i7E777xz3PMeECDQfAFvWmv+GMqAQO0FshnDNWvWJBs3bqx9vKMOMPOaya2vwrFZoRrOz/aL5pLFEM6P5c1rodDtLnJDfv2ubw7H2ggQaKbAm9MBzYxf1AQINEhg69atDYp29KHOpGjNH5vfL5pFTDO7U83ohhxDMd/v+uails4jQGD0Agre0Y+BCAi0RmD79u2tyXWYieaL0zPPPLOUrvNFYL79UhofUiMK3SFB64ZAAwQsaWjAIAmRQNMFsj+PH3roocl///vfpqdTefzZzGPoqNdygrKXMuSTy8atnzjy541639KFUY+A/gnUT8AMb/3GREQEohXYuXNntLmNKrH88oX8fhnx5Gd28/tltF1FG2Z0q1DVJoE4BBS8cYyjLAg0QmD37t2NiHPUQeZnVqeLJX9cWUsZ8v2FZQ1ZH2Gmua5Fr0I3P2r2CRCYTMCShslUPEeAQKkCWdE0f/78xCxvb9r8RwJPtaQhv+wh+JY9u5uPcph95fvttW/pQi8hrxMgkAmY4c0kfCVAoHKBKouyyoOvUQdh3W5WCFdd7Ia0w7hlv7SEfrP9UZGY0R2VvH4JNFdAwdvcsRM5gcYJZEVa4wIfYcBhtje/rVixYtxs7rB+icgXvSGeUPQOa4nDj370oyQU+aG/0G/3vXSzGej8nSXyZvYJECAw/v+kPAgQIFChwLCKswpTGHrT+XW03Z0P+xeIMH5ZcRliyWZ7QxFa1tiuXLkyeeKJJ9JUe+UXYlHkdl8VHhMgMJmAGd7JVDxHgACBEQrs2bOn57KBMOM5ii0Utlmhm/WfPc5mfUMhGv6FNdvvfe97s8MmfF24cGFn1jacG/49/vjjaftTFbtZH+F1xe4EUk8QIDCFgIJ3ChhPEyBAYJQCWWF5/fXXp4VgVhBmBV8oike5ZfGFePJbKESzf+GuHHffffeE+LNcduzYkR6bPz+/n+W6bt26TpuhX4VuXsk+AQL9CLhLQz9KjiFAYCCBrCgKX0PBYotPIMzohm2qmdleGYdrI8wIhyLYRoAAgbIFzPCWLao9AgQItFAg/CKTzfpmM7zZ1wsuuCAtZkNRm/079thjO7O24bhwrmK3hReOlAkMScAM75CgdUOgzQKhyAlb+GqGt81XgtwJECAwGgEzvKNx1ysBAgQIECBAgMCQBBS8Q4LWDQECBAgQIECAwGgEFLyjcdcrAQIECBAgQIDAkAQUvEOC1g2BNgtka3iLvoO/zXZyJ0CAAIHBBRS8gxtqgQABAgQIECBAoMYCCt4aD47QCBAgQIAAAQIEBhdQ8A5uqAUCBAgQIECAAIEaCyh4azw4QiNAgAABAgQIEBhcQME7uKEWCBAgQIAAAQIEaiyg4K3x4AiNAAECBAgQIEBgcAEF7+CGWiBAgAABAgQIEKixgIK3xoMjNAKxCMye7X81sYylPAgQINBEAT+FmjhqYibQMIHsgycaFrZwCRAgQCASAQVvJAMpDQJ1FlDw1nl0xEaAAIH4BRS88Y+xDAmMXGDOnDkjj0EABAgQINBeAQVve8de5gSGJjBv3ryh9aUjAgQIECDQLaDg7RbxmACB0gUUvKWTapAAAQIEZiCg4J0BlkMJECgmsGDBgmInOosAAQIECJQgoOAtAVETBAhML3DooYdOf4BXCRAgQIBAhQIK3gpxNU2AwP8LHH744SgIECBAgMDIBBS8I6PXMYH2CBx33HHtSVamBAgQIFA7AQVv7YZEQATiEzjjjDPiS0pGBAgQINAYAQVvY4ZKoASaK3DuuedWFvyXvvSlZP369ZW1r2ECBAgQaL7ArP2vb81PQwYECNRdIPu0tT/+8Y/JWWedVUq4mzZtStasWZO89a1vTR566KFS2tQIAQIECMQnYIY3vjGVEYFaC4SCt6zt3nvvTZtavXp1WU1qhwABAgQiFFDwRjioUiJQZ4HNmzeXFt59992XtmWNcGmkGiJAgECUAgreKIdVUgTqK7Bly5bSglPwlkapIQIECEQtYA1v1MMrOQL1EcjW8J588snJI488MnBgu3fvTubPn5+2s3379uSAAw4YuE0NECBAgECcAmZ44xxXWRGorcDLL79cSmw33XRT2s7Y2JhitxRRjRAgQCBeAQVvvGMrMwK1FHjttddKieuOO+5I2znppJNKaU8jBAgQIBCvgII33rGVGYFaCuzatauUuO6///60nXPOOaeU9jRCgAABAvEKWMMb79jKjECtBLI1vGEJwo4dOwaOLWvvgQceSE477bSB29MAAQIECMQrYIY33rGVGYFaCuzdu3fguG644Ya0jQULFih2B9bUAAECBOIXUPDGP8YyJFArgX379g0cz69//eu0jRNPPHHgtjRAgAABAvELKHjjH2MZEqiVQBmfZm79bq2GVDAECBCovYA1vLUfIgESiEMgW3Mbvg46y5u1Zf1uHNeGLAgQIFC1gBneqoW1T4BAqQLXXHNN2l4oer1ZrVRajREgQCBaAQVvtEMrMQJxCmT33z344IPjTFBWBAgQIFC6gIK3dFINEiBQpcCWLVvS5s8888wqu9E2AQIECEQkoOCNaDClQqDOAtm620HftJZ9cEW2tKHOOYuNAAECBOohoOCtxziIggCBPgSyIjcUz+eee24fZziEAAECBAgkiYLXVUCAQGMErN9tzFAJlAABArUSUPDWajgEQ4DAdALW706n4zUCBAgQmEpAwTuVjOcJEKidgPW7tRsSAREgQKARAgreRgyTIAk0XyB701rRTKzfLSrnPAIECBBQ8LoGCBBohID1u40YJkESIECglgIK3loOi6AIxCcwe/Zg/7uxfje+a0JGBAgQGJbAYD+BhhWlfggQaLzAnDlzBsrB+t2B+JxMgACBVgsoeFs9/JInMDyBefPmFe7sU5/6VOdc99/tUNghQIAAgT4FFLx9QjmMAIHBBMbGxgo38Lvf/S49d/78+YXbcCIBAgQItFdAwdvesZc5gaEKLF68uHB/zz77bHruUUcdVbgNJxIgQIBAewUUvO0de5kTGKrAypUrC/e3Z8+e9NwLL7ywcBtOJECAAIH2Cih42zv2MicwVIH3v//9hfrbsGFD57wf/OAHnX07BAgQIECgX4FZ+1/f+j3YcQQIECgqsH379iRb1jCT/+2cc845ye9///skfHDFvn37inbvPAIECBBosYAZ3hYPvtQJDFNg0aJFne6uu+66zn6vnfvuuy895IADDuh1qNcJECBAgMCkAgreSVk8SYBAlQJhxrbfbdu2bemhg6wB7rcvxxEgQIBAnAIK3jjHVVYEai3w5JNP9h1ftozhiiuu6PscBxIgQIAAgbyAgjevYZ8AgaEIPPfcc331861vfatz3Oc///nOvh0CBAgQIDATAQXvTLQcS4BAKQKvvvpqX+3ccsst6XGDfixxX505iAABAgSiFVDwRju0EiNQX4Fdu3b1FdxTTz2VHrds2bK+jncQAQIECBCYTEDBO5mK5wgQqFSg39uS7dixI41jzZo1lcajcQIECBCIW8B9eOMeX9kRqJVAuJdu2Pq5p+4rr7ySLFmyJD3+L3/5S/LOd74z3fcfAgQIECAwUwEzvDMVczwBAkMRuOCCCzr9KHY7FHYIECBAoICAGd4CaE4hQKCYwOzZs5NsOUP2daqWFi5cmIQlDXPnzk1279491WGeJ0CAAAECPQXM8PYkcgABAqMQyNbvHn/88aPoXp8ECBAgEJGAgjeiwZQKgboLZGt4e8W5adOmziHr16/v7NshQIAAAQJFBCxpKKLmHAIECgmE5Ql79+5Nz51uScOqVauShx9+uOdxhYJwEgECBAi0TkDB27ohlzCB0Qlk63JDBNMVvPPmzUv27NmTjI2Npet4RxexngkQIEAgBgFLGmIYRTkQaIjAokWL+oo0FLthc//dvrgcRIAAAQI9BBS8PYC8TIBAeQKHHHJIz8auu+66zjF33XVXZ98OAQIECBAoKqDgLSrnPAIEZixw9tln9zzn29/+dnpMv29w69mgAwgQIECg9QLW8Lb+EgBAYHgCjz32WHLyySenHU61hnfOnDnJvn37kqVLlyZbt24dXnB6IkCAAIFoBczwRju0EiNQP4GVK1d2grr22ms7+/mdUOyG7aKLLso/bZ8AAQIECBQWUPAWpnMiAQKDCGzYsGHC6Z/5zGc6z/30pz/t7NshQIAAAQKDCFjSMIiecwkQmLFAtjb3qKOOSv7973+PO3/ZsmXpMoZwTDbTO+4ADwgQIECAQAEBM7wF0JxCgMDgAi+99NKERl5++eX0ucMPP3zCa54gQIAAAQJFBRS8ReWcR4DAQAI7d+6ccH72Rrarr756wmueIECAAAECRQUsaSgq5zwCBAoJZEsaupctnHLKKcmjjz6atpkVvoU6cBIBAgQIEOgSUPB2gXhIgEC1AlMVvNntyGbPnp3s3bu32iC0ToAAAQKtErCkoVXDLVkCoxfICt7uWdzsTWqrVq0afZAiIECAAIGoBBS8UQ2nZAjUXyDM4HZvl19+eeepBx98sLNvhwABAgQIlCFgSUMZitogQKBvgQULFiTZG9ayWd7Jnuu7QQcSIECAAIEeAhOnWnqc4GUCBAgMIrBo0aIJp2cF8PLlyye85gkCBAgQIDCogIJ3UEHnEyAwI4Ejjjhi3PG333575/H69es7+3YIECBAgEBZApY0lCWpHQIE+hbI3rh24IEHJnPnzk1eeOGF9NxsiUPfDTmQAAECBAj0IaDg7QPJIQQIlCuQFbz5VsfGxpIdO3bkn7JPgAABAgRKEbCkoRRGjRAgMBOBE044YcLhH/3oRyc85wkCBAgQIFCGgBneMhS1QYDAjAW6Z3ktZ5gxoRMIECBAoE8BM7x9QjmMAIHqBMJyBhsBAgQIEKhKQMFblax2CRCYVuCkk07qvG7tbofCDgECBAhUIGBJQwWomiRAoD+B8IETxxxzTPLEE0/0d4KjCBAgQIBAAQEFbwE0pxAgQIAAAQIECDRHwJKG5oyVSAkQIECAAAECBAoIKHgLoDmFAAECBAgQIECgOQIK3uaMlUgJECBAgAABAgQKCCh4C6A5hQABAgQIECBAoDkCCt7mjJVICRAgQIAAAQIECggoeAugOYUAAQIECBAgQKA5Agre5oyVSAkQIECAAAECBAoIKHgLoDmFAAECBAgQIECgOQIK3uaMlUgJECBAgAABAgQKCCh4C6A5hQABAgQIECBAoDkCCt7mjJVICRAgQIAAAQIECggoeAugOYUAAQIECBAgQKA5Agre5oyVSAkQIECAAAECBAoIKHgLoDmFAAECBAgQIECgOQIK3uaMlUgJECBAgAABAgQKCCh4C6A5hQABAgQIECBAoDkCCt7mjJVICRAgQIAAAQIECggoeAugOYUAAQIECBAgQKA5Agre5oyVSAkQIECAAAECBAoIKHgLoDmFAAECBAgQIECgOQIK3uaMlUgJECBAgAABAgQKCCh4C6A5hQABAgQIECBAoDkCCt7mjJVICRAgQIAAAQIECggoeAugOYUAAQIECBAgQKA5Agre5oyVSAkQIECAAAECBAoIKHgLoDmFAAECBAgQIECgOQIK3uaMlUgJECBAgAABAgQKCCh4C6A5hQABAgQIECBAoDkCCt7mjJVICRAgQIAAAQIECgj8H71V7e9IcUkKAAAAAElFTkSuQmCC	\N	2025-10-26 02:34:01.62+00	2025-10-26 02:34:01.62+00
4d81fca5-7d38-49b9-a5be-932c8ebe442d	c4015d48-f46c-49ba-b7a4-6f5949973777	8b790d78-9d4b-4357-a0ba-9e09ee329415	João Manuel Fernandes Longo	present	\N	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAAc20lEQVR4Ae3d36tl4x8H8D3mF4NhTlPyo/EjI0URbsgUVzQ3UlJKzS1uJLlT/AHIBf/AuBK3GBcmLnAjF3OhaJL8KE0pZYbBOXyt3fdZHuvsc87ae6999lrP53VKe+2116/P67Pk7enZa+/4+5+/kT8CBAgQIECAAAEChQpcUGhdyiJAgAABAgQIECAwFhB43QgECBAgQIAAAQJFCwi8RbdXcQQIECBAgAABAgKve4AAAQIECBAgQKBoAYG36PYqjgABAgQIECBAQOB1DxAgQIAAAQIECBQtIPAW3V7FESBAgAABAgQICLzuAQIECBAgQIAAgaIFBN6i26s4AgQIECBAgAABgdc9QIAAAQIECBAgULSAwFt0exVHgAABAgQIECAg8LoHCBAgQIAAAQIEihYQeItur+IIECBAgAABAgQEXvcAAQIECBAgQIBA0QICb9HtVRwBAgQIECBAgIDA6x4gQIAAAQIECBAoWkDgLbq9iiNAgAABAgQIEBB43QMECBAgQIAAAQJFCwi8RbdXcQQIECBAgAABAgKve4AAAQIECBAgQKBoAYG36PYqjgABAgQIECBAQOB1DxAgQIAAAQIECBQtIPAW3V7FESBAgAABAgQICLzuAQIECBAgQIAAgaIFBN6i26s4AgQIECBAgAABgdc9QIAAAQIECBAgULSAwFt0exVHgAABAgQIECAg8LoHCBAgQIAAAQIEihYQeItur+IIECBAgAABAgQEXvcAAQIECBAgQIBA0QICb9HtVRwBAgQIECBAgIDA6x4gQIAAAQIECBAoWkDgLbq9iiNAgAABAgQIEBB43QMECBAgQIAAAQJFCwi8RbdXcQQIECBAgAABAgKve4AAAQIECBAgQKBoAYG36PYqjgABAgQIECBAQOB1DxAgQIAAAQIECBQtIPAW3V7FESBAgAABAgQICLzuAQIECBAgQIAAgaIFBN6i26s4AgQIECBAgAABgdc9QIAAAQIECBAgULSAwFt0exVHgAABAgQIECAg8LoHCBAgQIAAAQIEihYQeItur+IIECBAgAABAgQEXvcAAQIECBAgQIBA0QICb9HtVRwBAgQIECBAgIDA6x4gQIAAAQIECBAoWkDgLbq9iiNAgAABAgQIEBB43QMECBAgQIAAAQJFCwi8RbdXcQQIECBAgAABAgKve4AAAQIECBAgQKBoAYG36PYqjgABAgQIECBAQOB1DxAgQIAAAQIECBQtIPAW3V7FESBAgAABAgQICLzuAQIECBAgQIAAgaIFBN6i26s4AgQIECBAgAABgdc9QIAAAQIECBAgULSAwFt0exVHgAABAgQIECAg8LoHCBAgQIAAAQIEihYQeItur+IIECBAgAABAgQEXvcAAQIECBAgQIBA0QICb9HtVRwBAgQIECBAgIDA6x4gQIAAAQIECBAoWkDgLbq9iiNAgAABAgQIEBB43QMECBAgQIAAAQJFCwi8RbdXcQQIECBAgAABAgKve4AAAQIECBAgQKBoAYG36PYqjgABAgQIECBAQOB1DxAgQIAAAQIECBQtIPAW3V7FESBAgAABAgQICLzuAQIECBAgQIAAgaIFBN6i26s4AgQIECBAgAABgdc9QIAAAQLhBXbs2DG64AL/SQx/IwAoVsC/3cW2VmEECBAg0EZg586d483+/vtvobcNmG0IDFBA4B1g01wyAQIECHQn8Ndff9UHq0KvPwIEyhMQeMvrqYoIECBAgAABAgQyAYE3w7BIgAABArEEdu/eHatg1RIIKiDwBm28sgkQIEBgNFpbW8NAgEAAAYE3QJOVSIAAAQKTBczZnexiLYHSBATe0jqqHgIECBCYWqB6LJk/AgTKFRB4y+2tyggQIEBgE4H8ubv58ia7+IgAgYEKCLwDbZzLJkCAAIH5BNJ0BqO78znam8AQBATeIXTJNRIgQIBApwL5iO7Jkyc7PbaDESDQP4Ed//wfrqds968vrogAAQIEFiiQRnWr1+qHJ3bt2lU/scF/FhcI79AEliRghHdJ8E5LgAABAssRSD8lXJ19ZWVlORfhrAQIbKuAEd5t5XYyAgQIEFi2QBrdra4jjeYa4V12V5yfwGIFjPAu1tfRCRAgQKBHAlWwTX/5SG9a55UAgTIFBN4y+6oqAgQIEJggkP+y2urq6oQtrCJAoEQBgbfErqqJAAECBNYJ3HTTTfW6/CkN9UoLBAgUK2AOb7GtVRgBAgQI5AJVyE1zdtNr+twc3iThlUCZAkZ4y+yrqggQIECgIZBCbv6ltcYm3hIgUKiAwFtoY5VFgAABAv8K5FMYqufu+iNAIJaAwBur36olQIBASAGjuyHbrmgCtYDAW1NYIECAAIESBYzulthVNRGYTkDgnc7L1gQIECAwMAGjuwNrmMslsAABgXcBqA5JgAABAv0QyEd3T5482Y+LchUECGy7gMeSbTu5ExIgQIDAdgmkJzJUr5t9Wc1jybarI85DYDkCRniX4+6sBAgQILBggfyng1dWVhZ8NocnQKDPAkZ4+9wd10aAAAECMwuk0d3qAGke70YHM8K7kYz1BMoQMMJbRh9VQYAAAQKZQBVg018+0pvWeSVAIJaAwBur36olQIBACIG1tbW6ztXV1XrZAgECMQUE3ph9VzUBAgSKFbjxxhvr2vKnNNQrLRAgEE7AHN5wLVcwAQIEyhaoQm6as5tet6rYHN6thHxOYNgCRniH3T9XT4AAAQINgRRy8y+tNTbxlgCBYAICb7CGK5cAAQIlC+RTGDZ77m7JBmojQGC9gMC73sQaAgQIEBiogNHdgTbOZRNYsIDAu2BghydAgACB7REwurs9zs5CYIgCAu8Qu+aaCRAgQGCdgNHddSRWECDwfwGB161AgAABAoMXyH86OP/RicEXpgACBDoR8FiyThgdhAABAgSWKTDLo8jy6/VYslzDMoHyBIzwltdTFREgQCCcgOkM4VquYAJTCQi8U3HZmAABAgT6JrBz5876kjyKrKawQIBAJiDwZhgWCRAgQGB4AkLu8Hrmiglst4DAu93izkeAAAECnQmcOHGiPlb+WLJ6pQUCBAj8I+BLa24DAgQIEBiswLxfVkuF+9JakvBKoEwBI7xl9lVVBAgQCCHgy2oh2qxIAnMLCLxzEzoAAQIECCxDIH/e7pEjR5ZxCc5JgMBABExpGEijXCYBAgRKFNixY8eo+meWL55V+6W/NNKb3k/7akrDtGK2JzAsASO8w+qXqyVAgEAxAimwzhtW03GKgVEIAQKdCwi8nZM6IAECBAhsJfDaa69ttcmmn+dPZJhldHjTg/uQAIHiBExpKK6lCiJAgED/BZqjstOO8qb9q9cuAq8pDf2/Z1whgXkEjPDOo2dfAgQIEJha4NJLL516n3yHlZWV+m3+xbV6pQUCBAg0BIzwNkC8JUCAAIHFCqTR2fws04zwdvXs3fz8RnhzDcsEyhMwwlteT1VEgACB3grkc28nBd82F57C8az7tzmHbQgQKEtA4C2rn6ohQIBArwXmDas7d+6s6+ti7m59MAsECBQtIPAW3V7FESBAoD8C+ehuFVZnCb9Cbn/66UoIDElA4B1St1wrAQIEBiyQB9wDBw7UlVx99dX18mYLJ06cqD/Ow3O90gIBAgQ2EPCltQ1grCZAgACB7gQuueSS0blz58YHfPDBB0fvv/9+PcKbgvBWZ1vEl9XSOX1pLUl4JVCmgMBbZl9VRYAAgV4J5F8wqwJuel+9tp2mMMs+bREE3rZStiMwTAFTGobZN1dNgACBwQicPn26vtZqlDafjtA27ObP2z1y5Eh9PAsECBBoI2CEt42SbQgQIEBgZoHmVIRZRmrTPtVFtJ0CMc0FG+GdRsu2BIYnYIR3eD1zxQQIEFiowLFjx8ZTDvJHgM1zwhRQq9Caf1ntmmuumfqwefCdemc7ECAQVsAIb9jWK5wAAQLrBZqBsnrfdtrB+qONRlVoTvtXwbc52jtpn+a6WfZpHmOr90Z4txLyOYFhCxjhHXb/XD0BAgQ6E8jn1qaDptHZ9H7a1xR2037peM1gnT6f9DrLPpOOYx0BAnEFBN64vVc5AQIEaoE9e/bUc2MvvPDC0S233FJ/NuvCXXfdVe962WWXjUd704pmEE7rm68rKyv1qvyLa/VKCwQIEGghIPC2QLIJAQIESha44oorRn/++ee4xL17945+++23Tsr9/PPP6+P8/PPPdaCuV7ZYqPZLf3/88Uda9EqAAIGpBATeqbhsTIAAgbIEqh+BOHPmzLioaprB+fPnOyuwORWh+b7NiWbZp81xbUOAQCwBgTdWv1VLgACBWuDDDz8c/+JZWtF2mkHafrPXfD7wrMfNnxIx6zE2u0afESAQR0DgjdNrlRIgQOA/Avfff3/9/rvvvquX513Yt29fPX1h0pfTLrroolanEHJbMdmIAIEWAgJvCySbECBAoDSB6otp6e/RRx8dNZ+J+/vvv6ePp37N5wCn0Hro0KH6OOfOnauXN1o4ceJE/VE+WlyvtECAAIEpBATeKbBsSoAAgRIEnn/++VEKtPv37x+9+eabnZWVh9Nnn322Pu73339fL7dZOHr0aL3Z2tpavWyBAAECswj44YlZ1OxDgACBAQvk0wzSl8Ka5Rw+fHh0+vTp8eqNtmnuU01lSKO71TnS6G61XRWE03HSa3P//H26xuZx8m26XPbDE11qOhaB/gkY4e1fT1wRAQIEFiZw5ZVX1sd++umn6+UuFlLYrY6Vh93qfQq5KchW6zb6y5+3e+TIkY02s54AAQKtBQTe1lQ2JECAwLAFzp49O/rxxx/HRVTP23311Vc7K2ijqQzNE7QJvPkUho8++qh5CO8JECAwtYDAOzWZHQgQIDBMgcsvv7y+8C6ft9t8KsNLL71Un6e5MM0vuLUJx83je0+AAIFJAgLvJBXrCBAgUJjAPffcM0ojp3feeWen1W02laE6Uf5EiFOnTm167nykuDktYtMd5/iw+jW3ZDPHYexKgECPBQTeHjfHpREgQKArgU8//XR8qCpQfvbZZ1setu3P+OYBNX8qQ36Ctseq9plmrm9+jnmWDx48OM/u9iVAYAACuwZwjS6RAAECBOYQuO666+q9v/7663p53oXql9DygLrZVIY258p/We2+++5rs0sn26yuro6fIlEdzDSKTkgdhEDvBATe3rXEBREgQKBbgW+//XZ8wIsvvnh07bXXdnLw6meJ8ykH+XLzBHkobn6Wv8+PcfLkyfyjhS/n5174yZyAAIFtFzClYdvJnZAAAQLbJ/DYY4/Vo7DvvfdeZyfOf5Y4BdqtDr7Z6OnKykq9ez7SW6+0QIAAgTkEBN458OxKgACBvgu89dZb40usQmRXz7TN5+3mX0ibZPHcc8/Vq9999916ublQfXEs/VVTDPwRIECgSwGBt0tNxyJAgECPBD744IP66QPVSG8Xf1dddVU9YlyN2OZPaJh0/Jdffrle/cADD9TLzYU0SrzZKHBzH+8JECDQVsBPC7eVsh0BAgQGJrB///7RL7/8Mv4i1rRzVKu5vmnubwqjVfl5IM3Xb0TTZvtqxDgdK71udDzrCRAgMIuAEd5Z1OxDgACBAQhUYbf6O3z4cCdXm09lOHr06FTHzINvc8cUcjfbprmP9wQIEJhGQOCdRsu2BAgQGIhA9USG9Pfll1+mxdavk56dmwfTd955Z8tj3XbbbfU2TzzxRL2cL+RfUPvmm2/yjywTIECgMwFTGjqjdCACBAj0Q+Dmm28epZB79913jz755JOZLiyNuB46dGj8a2lfffXV+Dhtj9lmqkI6R3XgFKhnulg7ESBAYBMBgXcTHB8RIEBgaALHjh0bHT9+fHzZ1RfMfvjhh5lLSGE0vaZAml63OnDar3qdNId49+7do/REhmp50qjyVufwOQECBNoICLxtlGxDgACBAQh8/PHHo3vvvXd8pXv37h2dP39+rqvOR2jTgTYKr+nz/DUF3uo4a2tr+Ufj5fR59aZtiF53ECsIECDQQsAc3hZINiFAgMAQBNJzdqsgOW/Yreo9cODAurInjdSu2+ifFdWIbfqbFHa/+OKL9HH9s771CgsECBDoWMBPC3cM6nAECBBYhkD1JbU0Svr66693cgk//fTTf8LoVj8ykZ90UsjNP7/11lvrt1ttW29ogQABAjMKGOGdEc5uBAgQ6INA9SSEakT3119/HV/O448/PnryySc7u7RqRDf9k87R5uApfOfTFvL9tvo839YyAQIE5hUQeOcVtD8BAgSWJFA9GuzUqVP12Z955pnRG2+8Ub/vw8K+ffvWXUb+PN+2UyTWHcQKAgQITCEg8E6BZVMCBAj0SeD666+vL+fFF18cvfLKK/X7ZS7kz9Y9e/bsuksxuruOxAoCBBYsIPAuGNjhCRAgsGiB6rm7L7zwwqJP0/r4m43a7tr171dHJn0prvVJbEiAAIEpBDyWbAosmxIgQKBvAm+//fbohhtuGN1xxx29ubQ0b7d6bYbf9Fl1sWmktzcX7kIIEChW4N//1S62RIURIECgXIFHHnmkV8Xdfvvt9fU89dRT9XK1kB6bVi3n83ir9/4IECCwSAEjvIvUdWwCBAgEE8h/rKI5grvZZ8GYlEuAwDYLmMO7zeBOR4AAgZIFUsjNpy6kejf7LG3jlQABAosQEHgXoeqYBAgQCC7QDLz5FIbmvN7gVMonQGAbBATebUB2CgIECEQQ2LNnT11m89fTjO7WNBYIEFiCgMC7BHSnJECAQIkCq6urE8vKf0Y4f0bvxI2tJECAwAIEfGltAagOSYAAgYgCaRpD9ZpPW/BltYh3g5oJ9EvACG+/+uFqCBAgMHiB5s8Jm84w+JYqgMDgBQTewbdQAQQIEFi+QD5VIf854Xz98ePHl3+hroAAgZACpjSEbLuiCRAg0K3ARtMW0jSH6mxppLfbMzsaAQIEthYwwru1kS0IECBAYAuBrcJs/liyLQ7lYwIECHQuIPB2TuqABAgQiCuQj+jmIbf5mLK4QionQGAZAgLvMtSdkwABAoUK5IE3jfrm6wotW1kECPRcQODteYNcHgECBIYk8PDDD48v17N3h9Q110qgfAFfWiu/xyokQIDAQgV27949Sj86kUZ1N/oS20IvxMEJECCwgYAR3g1grCZAgACBdgKT5uem4Gs6QztDWxEgsFgBgXexvo5OgACBcAKevRuu5Qom0HsBUxp63yIXSIAAgX4LpFHc6rX6SeH0vrrqNNLb7wpcHQECpQsY4S29w+ojQIDAkgTyx5It6RKclgABAmMBgdeNQIAAAQKdCBw8eHCUh9xJc3s7OZGDECBAYEoBgXdKMJsTIECAwL8CVchNf2fOnDGFIWF4JUCgVwLm8PaqHS6GAAECwxJoPn4szd+t1hvhHVYvXS2BkgWM8JbcXbURIEBgGwVMZ9hGbKciQGAqAYF3Ki4bEyBAgEAukJ7CUI3spuX8c8sECBDog4DA24cuuAYCBAgUJJCP9BZUllIIEBiwgMA74Oa5dAIECPRRwNzdPnbFNRGILSDwxu6/6gkQIDCzwEMPPVTvazpDTWGBAIEeCnhKQw+b4pIIECAwBIHqJ4SrX1bL/zydIdewTIBAXwSM8PalE66DAAECAxNIjyDLL9t0hlzDMgECfREQePvSCddBgAABAgQIECCwEAGBdyGsDkqAAIF4Ap7OEK/nKiYwFAGBdyidcp0ECBDouYDpDD1vkMsjEFhA4A3cfKUTIECgK4FJ83m7OrbjECBAYF4BgXdeQfsTIECAwLqnNSAhQIBAnwQE3j51w7UQIEBgQAKrq6ujamTX3N0BNc2lEggq4Dm8QRuvbAIECBAgQIBAFAEjvFE6rU4CBAgQIECAQFABgTdo45VNgAABAgQIEIgiIPBG6bQ6CRAgQIAAAQJBBQTeoI1XNgECBAgQIEAgioDAG6XT6iRAgAABAgQIBBUQeIM2XtkECBAgQIAAgSgCAm+UTquTAAECBAgQIBBUQOAN2nhlEyBAgAABAgSiCAi8UTqtTgIECBAgQIBAUAGBN2jjlU2AAAECBAgQiCIg8EbptDoJECBAgAABAkEFBN6gjVc2AQIECBAgQCCKgMAbpdPqJECAAAECBAgEFRB4gzZe2QQIECBAgACBKAICb5ROq5MAAQIECBAgEFRA4A3aeGUTIECAAAECBKIICLxROq1OAgQIECBAgEBQAYE3aOOVTYAAAQIECBCIIiDwRum0OgkQIECAAAECQQUE3qCNVzYBAgQIECBAIIqAwBul0+okQIAAAQIECAQVEHiDNl7ZBAgQIECAAIEoAgJvlE6rkwABAgQIECAQVEDgDdp4ZRMgQIAAAQIEoggIvFE6rU4CBAgQIECAQFABgTdo45VNgAABAgQIEIgiIPBG6bQ6CRAgQIAAAQJBBQTeoI1XNgECBAgQIEAgioDAG6XT6iRAgAABAgQIBBUQeIM2XtkECBAgQIAAgSgCAm+UTquTAAECBAgQIBBUQOAN2nhlEyBAgAABAgSiCAi8UTqtTgIECBAgQIBAUAGBN2jjlU2AAAECBAgQiCIg8EbptDoJECBAgAABAkEFBN6gjVc2AQIECBAgQCCKgMAbpdPqJECAAAECBAgEFRB4gzZe2QQIECBAgACBKAICb5ROq5MAAQIECBAgEFRA4A3aeGUTIECAAAECBKIICLxROq1OAgQIECBAgEBQAYE3aOOVTYAAAQIECBCIIiDwRum0OgkQIECAAAECQQUE3qCNVzYBAgQIECBAIIqAwBul0+okQIAAAQIECAQVEHiDNl7ZBAgQIECAAIEoAgJvlE6rkwABAgQIECAQVEDgDdp4ZRMgQIAAAQIEoggIvFE6rU4CBAgQIECAQFABgTdo45VNgAABAgQIEIgiIPBG6bQ6CRAgQIAAAQJBBQTeoI1XNgECBAgQIEAgioDAG6XT6iRAgAABAgQIBBUQeIM2XtkECBAgQIAAgSgCAm+UTquTAAECBAgQIBBUQOAN2nhlEyBAgAABAgSiCAi8UTqtTgIECBAgQIBAUAGBN2jjlU2AAAECBAgQiCIg8EbptDoJECBAgAABAkEFBN6gjVc2AQIECBAgQCCKgMAbpdPqJECAAAECBAgEFRB4gzZe2QQIECBAgACBKAICb5ROq5MAAQIECBAgEFRA4A3aeGUTIECAAAECBKIICLxROq1OAgQIECBAgEBQAYE3aOOVTYAAAQIECBCIIiDwRum0OgkQIECAAAECQQUE3qCNVzYBAgQIECBAIIqAwBul0+okQIAAAQIECAQVEHiDNl7ZBAgQIECAAIEoAgJvlE6rkwABAgQIECAQVEDgDdp4ZRMgQIAAAQIEoggIvFE6rU4CBAgQIECAQFABgTdo45VNgAABAgQIEIgiIPBG6bQ6CRAgQIAAAQJBBQTeoI1XNgECBAgQIEAgioDAG6XT6iRAgAABAgQIBBUQeIM2XtkECBAgQIAAgSgCAm+UTquTAAECBAgQIBBUQOAN2nhlEyBAgAABAgSiCAi8UTqtTgIECBAgQIBAUAGBN2jjlU2AAAECBAgQiCIg8EbptDoJECBAgAABAkEFBN6gjVc2AQIECBAgQCCKgMAbpdPqJECAAAECBAgEFRB4gzZe2QQIECBAgACBKAICb5ROq5MAAQIECBAgEFRA4A3aeGUTIECAAAECBKIICLxROq1OAgQIECBAgEBQAYE3aOOVTYAAAQIECBCIIiDwRum0OgkQIECAAAECQQUE3qCNVzYBAgQIECBAIIqAwBul0+okQIAAAQIECAQVEHiDNl7ZBAgQIECAAIEoAgJvlE6rkwABAgQIECAQVEDgDdp4ZRMgQIAAAQIEoggIvFE6rU4CBAgQIECAQFCB/wHrLTN0MCZ6WAAAAABJRU5ErkJggg==	\N	2025-10-26 02:34:01.62+00	2025-10-26 02:34:01.62+00
aec33428-972f-46eb-81cd-23c763145245	c4015d48-f46c-49ba-b7a4-6f5949973777	d3ad84ae-c456-4ba7-9300-a78884804e9d	Vítor Manuel Sebastian Rodrigues	present	\N	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAAn20lEQVR4Ae3dX+ikVf0H8Mfa7+66mhX+Kf/gn9LWNJXE/klUINQvghAiqBDsxuhCCOo6CsGLbgIvvKmLSpOI/idJdRcECWWUoJllgZZR6aapu+vuaj8/U+fZ852d7/c7z8wzM8858xr4Ms/MPH/OeX2e3XnPmTMzJ/3npUvjQoAAAQIECBAgQKBSgZdV2i/dIkCAAAECBAgQIDASEHidCAQIECBAgAABAlULCLxVl1fnCBAgQIAAAQIEBF7nAAECBAgQIECAQNUCAm/V5dU5AgQIECBAgAABgdc5QIAAAQIECBAgULWAwFt1eXWOAAECBAgQIEBA4HUOECBAgAABAgQIVC0g8FZdXp0jQIAAAQIECBAQeJ0DBAgQIECAAAECVQsIvFWXV+cIECBAgAABAgQEXucAAQIECBAgQIBA1QICb9Xl1TkCBAgQIECAAAGB1zlAgAABAgQIECBQtYDAW3V5dY4AAQIECBAgQEDgdQ4QIECAAAECBAhULSDwVl1enSNAgAABAgQIEBB4nQMECBAgQIAAAQJVCwi8VZdX5wgQIECAAAECBARe5wABAgQIECBAgEDVAgJv1eXVOQIECBAgQIAAAYHXOUCAAAECBAgQIFC1gMBbdXl1jgABAgQIECBAQOB1DhAgQIAAAQIECFQtIPBWXV6dI0CAAAECBAgQEHidAwQIECBAgAABAlULCLxVl1fnCBAgQIAAAQIEBF7nAAECBAgQIECAQNUCAm/V5dU5AgQIECBAgAABgdc5QIAAAQIECBAgULWAwFt1eXWOAAECBAgQIEBA4HUOECBAgAABAgQIVC0g8FZdXp0jQIAAAQIECBAQeJ0DBAgQIECAAAECVQsIvFWXV+cIECBAgAABAgQEXucAAQIECBAgQIBA1QICb9Xl1TkCBAgQIECAAAGB1zlAgAABAgQIECBQtYDAW3V5dY4AAQIECBAgQEDgdQ4QIECAAAECBAhULSDwVl1enSNAgAABAgQIEBB4nQMECBAgQIAAAQJVCwi8VZdX5wgQIECAAAECBARe5wABAgQIECBAgEDVAgJv1eXVOQIECBAgQIAAAYHXOUCAAAECBAgQIFC1gMBbdXl1jgABAgQIECBAQOB1DhAgQIAAAQIECFQtIPBWXV6dI0CAAAECBAgQEHidAwQIECBAgAABAlULCLxVl1fnCBAgQIAAAQIEBF7nAAECBAgQIECAQNUCAm/V5dU5AgQIECBAgAABgdc5QIAAAQIECBAgULWAwFt1eXWOAAECBAgQIEBA4HUOECBAgAABAgQIVC0g8FZdXp0jQIAAAQIECBAQeJ0DBAgQIECAAAECVQsIvFWXV+cIECBAgAABAgQEXucAAQIECBAgQIBA1QICb9Xl1TkCBAgQIECAAAGB1zlAgAABAgQIECBQtYDAW3V5dY4AAQIECBAgQEDgdQ4QIECAAAECBAhULSDwVl1enSNAgAABAgQIEBB4nQMECBAgQIAAAQJVCwi8VZdX5wgQIECAAAECBARe5wABAgQIECBAgEDVAgJv1eXVOQIECBAgQIAAAYHXOUCAAAECBAgQIFC1gMBbdXl1jgABAgQIECBAQOB1DhAgQIAAAQIECFQtIPBWXV6dI0CAAAECBAgQEHidAwQIECBAgAABAlULCLxVl1fnCBAgQIAAAQIEBF7nAAECBAgQIECAQNUCAm/V5dU5AgQIECBAgAABgdc5QIAAAQIECBAgULWAwFt1eXWOAAECBAgQIEBA4HUOECBAgAABAgQIVC0g8FZdXp0jQIAAAQIECBAQeJ0DBAgQIECAAAECVQsIvFWXV+cIECBAgAABAgQEXucAAQIECBAgQIBA1QICb9Xl1TkCBAgQIECAAAGB1zlAgAABAgQIECBQtYDAW3V5dY4AAQIECBAgQEDgdQ4QIECAAAECBAhULSDwVl1enSNAgAABAgQIEBB4nQMECBAgQIAAAQJVCwi8VZdX5wgQIECAAAECBARe5wABAgQIECBAgEDVAgJv1eXVOQIECBAgQIAAAYHXOUCAAAECBAgQIFC1gMBbdXl1jgABAgQIECBAQOB1DhAgQIAAAQIECFQtIPBWXV6dI0CAAAECBAgQEHidAwQIECBAgAABAlULCLxVl1fnCBAgQIAAAQIEBF7nAAECBAgQIECAQNUCAm/V5dU5AgQIECBAgAABgdc5QIAAAQIECBAgULWAwFt1eXWOAAECBAgQIEBA4HUOECBQpcDtt9/ebGxsNC9/+cubl73sZe3fSSed1JT2l7d/q+XoZ/zt2rVr9Bd937NnT3P++ec3t9xyS5U11ikCBAhMK3DSf166TLuy9QgQILBqgauuuqp54IEHmvivK/33la5X3bYajx8vDuKSXiS8//3vb+6+++4au6pPBAhULCDwVlxcXSNQksCrXvWq5tlnn21efPHFttmLCLIpwLUHKWBhEQ59djs3jRHoffv2Nf/+97/7PIR9ESBAYC4BgXcuPhsTILCTwO7du5sXXnihHY2N9fsOcHngiuUIXb/61a+aGA12+a/AzTff3Hz3u99tnnzyydGLilSD8etxr/T4+P2z3E51iuuYfnHkyJFZdmMbAgQIdBYQeDuT2YAAgUkCETL7DEdxjBSQ0nLMT33++ecnHd59SxSI+cExEp/qna7nbUKqd4z2HzhwYN7d2Z4AAQKtgA+ttRQWCBDoIhChJ0JuhJT46xJ60jaxfYz0nXHGGaPtYx/x9853vrNtSgSr+ItRYmG3ZVnpwtGjR0f1SLVJdcuv9+7du+n8SGF2u4an7f/1r3+151WcI/FCx4UAAQLzCAi88+jZlsCaCUQ4TWH12LFjE0NuPJ6C7Lve9a5NQTYFmhSUIsTGfv75z3+2krHtz3/+89HtWD9uu5QncOjQoU2hOGqe6p+u4/yIcypqvFUgjnXjPEnnXTq3vvnNb5aHosUECKxMwJSGldE7MIHhC5x55pmjOZ8ROra6RBCJ0BKjfvNcYh8RiiZdTjnllNEH2iY95r76BD784Q+P5hunYLxTD+McjFFgc4J3kvI4gfUVEHjXt/Z6TmCiQATPnYJGBIw77rijueGGGybuo+udsb/8Ercj/Ob3bxe6820t1ykQgTaNEu/Uwzhv4i9Ghl0IECAQAt4rdB4QINC+pZyC5ni4jPvjreQUhCN49BV2x6cs3Hbbbe1I72WXXdZWJ9rgsr4CMfUlBd44D+NHNbY6J+Lx9IIpnbvxboULAQLrK2CEd31rr+drLBAfOIvRr/Fgm5NEUIipBM8880x+d+/LeWiZ1J58qkOsG0HGhcAkgWnenYgXWEZ+J+m5j0DdAkZ4666v3hFoBSIMRGCMv60+cDY+irvosJuP7v72t79t25ovpA8sxX0RiL/xjW/kD1sm0ArEuZKPAsc0iPwFVayYRn7zc6/dgQUCBKoVMMJbbWl1bN0FzjrrrOaJJ57YcRQ3gvC8Hzib1TqFkbjeaeS2y7qztsd29Qrk7xSM9zIeixeBLgQI1CtghLfe2urZGgrEiFaMXEU4jK/6mjRFIB678847R49FyFxV2I2QkS779+9Pi1tep8A7qU9bbuQBAv8TSFN4rr322hNGfdO7CEZ9nS4E6hUwwltvbfVsTQS2G7kKggiK8RdP6kO6pAAbbZo2xKZt4nqnEeEh9VVbhikQAXfSuRfn1/XXXz/6arRhtlyrCBDoKiDwdhWzPoGBCGz1ZB3NiyfsZXzgbFaKaNvBgwdHm8en7Q8fPjzVrvI+TwoqU+3ESgTGBLb7EGe8a7Kqd0HGmukmAQJzCAi8c+DZlMCyBeLJd6uR2pJGPaOt6dIluMZXS8W85LgIIknQdZ8C+YuqfL9x/1b/9vL1LBMgMEwBc3iHWRetIrBJIJ5sIySOP+HGfVdccUU7H3fTRgO98e53v7ttWfSryyX/CWIfMuoiZ91pBWKqTLwIGz834/749zZ+/7T7tR4BAqsVMMK7Wn9HJ7ClwHZvs8aT7nj43XJHA3sg2p5GddN1lybOu32XY1mXwFbvqkT4NY/c+UGgHIFuwyvl9EtLCRQrEIEunkzHvys37tu7d+8oLJYadqMoKeRGf2a5nHvuubNsZhsCMwmkf4fxTSL5ORvncdyOF6YuBAgMX0DgHX6NtHANBOKDWynopkCYuh1PqnFfjCYdOnQo3V3kdfQxXWYdHXvsscfSLpqvfOUr7bIFAosUeOihh0b/BlPQTceKQJyf1+l+1wQIDEvAlIZh1UNr1kwgnijHA24QRMiNrxur7dPhaYQsrmcNvMknrk877bTm6aefjkUXAksViJHd8XnkPki51BI4GIFOAseHWzptZmUCBGYVuOiii6Yaza0t7OY/NDFP2M3dn3322fymZQJLE4h/n0Z7l8btQATmFtg19x7sgACBqQS2+4GIeGx8tGiqnRa00qSR7Hmbv4h9ztsm26+XQLx4y0d7Uwh2bq7XeaC3wxcwwjv8GmlhwQJ33HFHO5o7PqqZ5ubGE2PtYbfgEmo6gR0FJo32pmlJO25sBQIEliJghHcpzA6ybgJnnHFG8+STT07sdszbLflbFiZ2aoo704hXmsc7xSZWIVCUQLyozd/Jidvx7338xW5RndJYApUIGOGtpJC6MRyBeIIbD7sR8u6///7RnL91DLt9VyeF5hSi+96//RGYVSD+fefnZSzH/wkuBAisVsAI72r9Hb0igXxkJ3VrXUdzU/8nXcdXsLkQqF0ggm7+wsxIb+0V17+hC3jZOfQKad/gBWL6Qjyx5W9bxu14wjOa+9/y3XPPPW0d8+X2TgsEKhSYFHor7KYuEShCwPfwFlEmjRyqQIzaxJNafrnhhhuaO++8M79r7ZfjF+Kef/75kcO41yw4+Wh6H/ubpQ22ITCtQP7/xPiL42n3YT0CBOYTMKVhPj9br6lAHrgSgekLSeLE6yNHjpx4p3sIrIlA+vBavDiLv3gBePjw4TXpvW4SGIaAKQ3DqINWFCJg+kIhhdJMAgMTyKc8xbsd8QLZhQCB5Qn4F7c8a0cqXCCeoMa/fSGmL+RPZIV3cWHNT9MO0od45j1Q2t+8+7E9gWUK5Oe/c3iZ8o5FoGlMaXAWENhBwPSFHYA8TIDAVALx4jgPvVNtZCUCBHoRMMLbC6Od1Chg+kL/VfVk37+pPZYlEC+g08W0hiThmsDiBQTexRs7QoECpi8spmjXXXfdYnZsrwQKEYifEU8v/ExrKKRomlmFgK8lq6KMOtGXgOkLfUke389rXvOa5h//+Mfojr6e4FNgiGtzqI9bWypHIF5Ux/nru7rLqZmWli0g8JZdP63vUSCFqLRLYSpJzHedv4gQeOeztDUBAgQIzCZgSsNsbraqSOCBBx5o32JM3fLtC0li/uu+Qu78LbEHAgQIEFhXAd/SsK6V1++RwOmnn94cOHCg1TCq21L0tiDw9kZpRwQIECAwo4DAOyOczcoX2NjYaOIDJOkSc+rMp0sa/V+PTxnp4wiL2Gcf7bIPAgQIEBiWgCkNw6qH1ixJIOaV5mF3165dwu6C7RcRThexzwUz2D0BAgQIrEBA4F0BukOuViD/EFW05LWvfW1z9OjR1TZqDY4e32vc9+Wss87qe5f2R4AAAQIVCpjSUGFRdWlrgZi2kM8pzZe33sojswq8973vbTf9+9//3i73tXDLLbf0tSv7IUCAAIGKBXwtWcXF1bXNAsLuZo9l3MqnivT14uLaa69tfvGLX4ya39c+l2HhGAQIECCwOgGBd3X2jrxEAWF3idjZoXL3vsLpvn37mkOHDo2O0tc+syZbJECAAIEKBczhrbCourRZIA9d8YiQtNmntFvPP/98aU3WXgIECBBYsYDAu+ICOPxiBeJT/Cng5suLPaq9EyBAgAABAkMSEHiHVA1t6VUg/8qqWH7xxRd73b+d7SyQv9jYee3p1kj7nG5taxEgQIAAgaYReJ0FVQoIu1WWVaeWIBD/duIvpgK5ECBAoBYB/6PVUkn9aAXyJ2ojuy2LBQI7Crz1rW9t14mR9FtvvbW9bYEAAQIlC/iWhpKrp+0TBdLorrA7kWepd6ZaxIuQvn62Of8QoukN/Zcz1SztmXGScE2AQMkCRnhLrp62nyCQj+6as3sCz8ruOPvss1d2bAfuJqBW3bysTYBAGQICbxl10sopBPbv37/pGxmm2MQqSxL4/ve/39uR0ojj+EhkbwdY8x09/vjjm+bvxk9xuxAgQKB0AVMaSq+g9rcCeQBKoah90MLSBS6++OLmkUceGR23z3qkOse1UfzFlTU5xxH27NnTHD58eHEHs2cCBAgsWEDgXTCw3S9HYGNjozl27NjoYH3OF11O6+s8Sl4Tgbe8GueBN1ov9JZXQy0mQOC4gCkNxy0sFSyQwm50oa8PRxXMMYimq8MgyjBzI/L58LGT+IW7vXv3zrw/GxIgQGCVAgLvKvUduxeBfI7h+JN0LwewEwJrKHDaaae1vU7/xiL07tq1q73fAgECBEoREHhLqZR2bimQz+M0qrglU3UPjL/lXl0HV9yhPPDGOygp9Ma/sbC/6667VtxChydAgMD0AgLv9FbWHKBAehKOphl5GlaB0rzdRQXTRe13WIrDaU2E3n379rUNuuGGG5pzzz23vW2BAAECQxYQeIdcHW3bUSAf3T169OiO61uhHoFTTz21ns4U0pPnnnuuuemmm9rWxleY5S862wcsECBAYGACAu/ACqI50wvk83UvvfTS6Te0ZhUC73nPe6roR2md+NKXvjT6vuvdu3ePmh4vOmO0/ZprrimtK9pLgMAaCQi8a1Ts2rqav2X+u9/9rrbuVdOfPqcefPnLX25d+vwxi3anFqYWiA+wve1tb2vXv++++5oUgts7LRAgQGAgAgLvQAqhGd0E8rdR82kN3fZi7WUInHPOOb0d5tZbb+1tX3Y0v8C99947Gu1N77bEtKJ4gXPjjTfOv3N7IECAQI8CAm+PmHa1PIE0uru8IzrSrAI/+clPZt30hO3+9re/nXCfO1YvEN/ccN5557UNueOOO0ajvebVtyQWCBBYsYDAu+ICOPxsAinw9vl2+WwtsdUkgfhZ4XS57LLL0uLc1wLU3IQL28Fjjz3WfOc732n3H7WKKQ7xzQ7f+9732vstECBAYBUCflp4FeqOObdACrrxVqrv3p2bs/cdRNBJ4TS9OOnjIFHvtL903cd+7eNEgXmszzzzzOaJJ57YtNP42sBPf/rTzRe+8IVN97tBgACBZQgIvMtQdoxeBU4++eTm8OHDo30KPb3S9rqz9KIk6nXw4MFe9p32GdfmbvdCuuVO+rB+y1ve0sSH2fJ/pxGkP/CBDzQ//OEPtzy2BwgQINC3gCkNfYva38IF4tPhLuUIpBcnfbY4hbE+92lfxwU2NjbaG3/5y1/a5a4Lv/zlL0cvTD70oQ81EXTjEi9U7r777tHtN7/5zV13aX0CBAjMJCDwzsRmo1UK5KNFq2yHY28vkEJpX/V6/etf3x7QNJaWYiEL8atqcYka9vEtG9/+9rdHU48+97nPtb+IGOfFb37zm9Exzj///IX0w04JECCQBATeJOG6OIEUqIpr+Jo0OB8l7KPLf/7zn/vYjX3sIPDKV76yXeMjH/lIu9zHwuc///nR3O745o78Z4rjA2/x7zl+Pe/rX/96H4eyDwIECGwSMId3E4cbJQikoBvfxZtGokpo9zq2MdWqj3m883yIah3tZ+1zqlls39fo/HZtOf3005sDBw5sWiVqHb+e+LOf/aw544wzNj3mBgECBGYRMMI7i5ptViYQn/ROF2E3SQz/uo95vCl85YFs+D0vq4VvetOb2gZfeOGF7fIiF5588slRsL7ooos2zfN98MEHm/i2h/jGj/e9732LbIJ9EyCwBgIC7xoUuaYu+mR+WdVM4TSF1T5anz781Me+7GOzwAMPPNDesewpJH/6059G83x/+tOfNjGnN5078fV2cV/cfsUrXtF86lOfattogQABAtMKmNIwrZT1BiGQngTjWvgdREm2bcSePXuaI0eOjNaZJ/Tu3bu3Sd/OMc9+tm3smj/4mc98pvniF784Uoj5tc8999zKReJDbrfddlvz9NNPn9CWOLcuueSS5oILLmiuuOKK5h3veMfo687ynx0/YSN3ECCwtgIC79qWvsyOC7zl1S3VbJ55vObvLr7uQzeOrzb70Y9+1L7w2U4kQm9Mf4oP4OUfwttqm5g6sX///okPv/3tb28+8YlPTHzMnQQIlCMg8JZTq7Vv6de+9rXm4x//+Mjh7LPPbh5//PG1NykBIAXeeUbl0z6iv0Z4F1P1ZFzCh0Gvvvrq5qmnnmqeffbZ5plnnhm9i7Cod3xi9Pj+++9fDLq9EiCwNAGBd2nUDjSvQDwRpyc1oWdezeVt38fIYQpj84Tm5fW4vCP1UaMh9DoC8D333NPce++9TcxHjncV4lsgtrvEOXXeeeeNpkaMrxePXXnllU0EbBcCBMoWEHjLrt9atT7eokw/OCDwllP6PubxpsA7lLml5ehP19LkG9fpReV0W1qLAAECZQj4loYy6qSVBIoVSB82iw7kPzYwbYfyDyEN4YNU07a7lPVidDddhN0k4ZoAgdoEjv9PV1vP9IcAgcEJzPJ9vEbzF1fGeNck+aZR3sUdzZ4JECCwOgGBd3X2jkxgbQRSmErhqkvH0zZpH122te7WAvHNA2mKUKxldHdrK48QIFC+gDm85ddwbXpgDm+5pZ5nHm8KunEtlPV3DiTX2GN6UdHf3u2JAAECwxIwwjusemgNgSoFZp3HG7+wlS7XXHNNWnQ9p0A+bzd+uMGFAAECtQsY4a29whX1zwhv2cVMI4pdRmpr+bqsIVUu/9W6LrUYUh+0hQABAl0FjPB2FbM+AQIzCaTA2+Xt87Ru2namA9uoFXj44Yc3/VKZKSItjQUCBCoXMMJbeYFr6p4R3rKrmc/j3b1796bgNalnRncnqcx3X/7CIb2YmG+PtiZAgEAZAkZ4y6iTVhIoXiCfx3vkyJEd+5MCWR7SdtzIClsK5PN2Tz311C3X8wABAgRqFBB4a6yqPhEYqMDNN9/ctiwPYO2d/1vIf2zCz7qO63S/HT+vm7+AeOaZZ7rvxBYECBAoWMCUhoKLt25NN6WhjornUxW2mtqQj+qmoFZH71fTC56rcXdUAgSGI2CEdzi10BICayGQf1Bq0tSGfHT35JNPXguTRXYyD7tf/epXF3ko+yZAgMBgBQTewZZGwwjUK7Dd1IY8EB88eLBehCX0LJ82srGx0dx4441LOKpDECBAYHgCpjQMryZatI1AGq2KUcBjx45ts6aHhi4waWpDPm1Fjeer4OWXX948+OCDo53Ev5v8hcR8e7Y1AQIEyhMQeMur2Vq3OAVeT+B1nAapntGbmKs7fruOXq6mFyxX4+6oBAgMU8CUhmHWRau2EEhP4j7ItAVQYXfnUxtSbaML+VvxhXVp5c2Nb2TILf/v//5v5W3SAAIECKxawAjvqivg+J0E4m3u9Nas0NuJbrAr51MbUiPVNkl0ux63jA/9mQfdzdDaBAjUKWCEt866VturT37yk23fzjvvvHbZQrkC6QVM6kE+Opnuc72zQLjlLxTuuusuYXdnNmsQILAmAkZ416TQNXUzBaK4Hg9LNfVznfqSj0yqa7fKX3/99c0PfvCDdiN+LYUFAgQItAK72iULBAoTyEezCmu65o4J5LWM5T179jT5TxGPre7m/wTyb7WIu4RdpwYBAgQmC5jSMNnFvQMWiCd1l3oEJn1AbdIPUtTT4356Em4vvPBCu7P9+/d7x6PVsECAAIHNAgLvZg+3ChCIUS2XegTS6G68kMm/tWFSEK6n1/P1JKySW+wplh966KH5dmprAgQIVCxgDm/Fxa25a2mUd3yUq+Y+19i3VMfoWwpwUdO0vHv3blMbssLHV44dOHCgvSf8zGNvOSwQIEBgSwFDZVvSeKAEgRSMSmirNm4WyEdw8+AbAS7dNrXhuFn+QiDu9ZVjx20sESBAYCcBUxp2EvL4IAVSIBJ4B1meHRsV36ecajdplDKf2pBqveNOK14hDJJXdPPOO+/0lWMV11vXCBDoX8CUhv5N7XEJAvkPUJjWsATwHg9xwQUXNI8++mi7xzzItXe+tDA+ojkpGOfr17jsK8dqrKo+ESCwCgGBdxXqjtmLQD7yt1Vo6uVAdtKrQJe6jYfeaMi6BF9fOdbraWdnBAisuYApDWt+ApTc/SuvvLJtfgQjl+EL5GF3mm/biPm88WIm3y7drrnm0bf8K8fe8IY3+HDa8E9vLSRAYMACRngHXBxN21kgHwEcDwk7b22NZQrktZp1lDbfR2p7TXUfH9WNPnr3IlXaNQECBGYXMCw2u50tByCQfyVTvjyApmlCJrDTh9SyVbddjBrfddddm0Z8474I0Hv37t1226E+GCE32h9/+ahu3BZ2h1o17SJAoDQBgbe0imnvCQKmNpxAMqg74kNq+YuRfHmWhn7sYx8b7e+6667btHn8FHGExDPPPHPT/UO8sVXITW2N7x+e1yntyzUBAgQIvPT5j5dGEP4DgkDpAvlb3TW9xV16XaL9EULTZRH/3Zx77rnN448/ng7RXl999dXNfffd195e9cKk6Qp5m+Lxo0eP5ndZJkCAAIGeBIzw9gRpN6sVyEfD8uXVtsrR87AbgW4Rl7/+9a+jt/5POeWUTbv/9a9/PQrbn/3sZzfdv8wbO43kxuPxIiD+hN1lVsaxCBBYNwEjvOtW8Yr7e9VVVzX333//qIcRtATf1RY7H3VfZj02NjaaY8eOber8Mo8fITafi7upIS/diMeF23EVtwkQILBYAYF3sb72vmSBPGSZ2rBk/Oxw+Q+DLDNsZk044Ycr8seiTZMuEUbjw2+vfvWrm5gbftNNNzUf/OAHJ6266T4hdxOHGwQIEBicgMA7uJJo0LwCeZhZxJzRedtX+/bT/pLashzyF0HLOmYcx0juMrUdiwABAtsLmMO7vY9HCxTIv7UhD78FdqXIJk/zs8HL7FhMbYkXPnEupL9FHT9Crjm5i9K1XwIECMwuYIR3djtbDlhgfFTP9IbFF2v8bf2Y1jA+l3bxrej/CLfffnvzrW99q3n44Yebp59+uomvP8vnh0c/zcnt390eCRAg0KeAwNunpn0NSmA89EbjTHFYTInGrb3AWIyzvRIgQIDAbAKmNMzmZqsCBGIU7nWve92mlsZb2hHGXPoTGA+7l19++bbfUtDfke2JAAECBAhMJ2CEdzonaxUuMB7Kojv79u1rnnvuucJ7ttrmj8+RNoK+2no4OgECBAhMFhB4J7u4t1KB8eAbgS2fj1lpt3vv1vh8XY69E9shAQIECPQo4L3dHjHtavgCEW7jQ0bpkj69n9+XHnM9WSBeNOQ/rBC3vWiYbOVeAgQIEBiGgMA7jDpoxRIF4psDUtBNh43ANv72fHrM9XGB8RFy83WP21giQIAAgeEKmNIw3Npo2RIELr744uaRRx7ZdCRvz2/iaG+MvyAwX7elsUCAAAECAxcQeAdeIM1bjsD4yGUc1Yfa/mtvvu5yzkFHIUCAAIHFCZjSsDhbey5IIKY0jE9zOHjw4GiaQ8zv/eMf/1hQb/prqvm6/VnaEwECBAisTkDgXZ29Iw9QYPxDbdHEuO+SSy4Zhd8IgOsSgMdHvS+77LJNH1YbYPk0iQABAgQITBQwpWEiizsJNKMfqNhpnmrMa42/3//+903MB67hMh50o087OdTQb30gQIAAgXoFjPDWW1s9m1MgTXOIsBfzecc/tBW7j8dKHwH+8Y9/PAr3Kbzn4Tbuy2/PSWpzAgQIECCwEgEjvCthd9DSBU455ZTm0KFDO4bBFCKHNgJ84YUXNo8++ui27R+fv1t6zbSfAAECBNZXQOBd39rreY8CMQJ8+PDhbQNkHG6VAXhjY2M0B3erEdvUtvxHJXoksisCBAgQILAyAYF3ZfQOXLPAtAE4DCJopkuMqp599tnNY489lu6a6zq+UixNzZi0ozh2HDN+jMOFAAECBAjUKiDw1lpZ/RqUQJcAvFXDx4PxOeecM5qWML5+fItEhNytLrGf0047rXnqqae2WsX9BAgQIECgKgEfWquqnDozVIH4Tt800hpTCk4++eR2esO0bY7t0l9MO4hR4Aiv43+Twm6s89GPfnS0fTwu7E6rbj0CBAgQqEHACG8NVdSH6gTe+MY3Nn/4wx82jdRuNfd2q85HyJ0Ufrda3/0ECBAgQKBWAYG31srq11oIXHrppaNfgUvBNkKuD52tRel1kgABAgQ6CAi8HbCsSoAAAQIECBAgUJ6AObzl1UyLCRAgQIAAAQIEOggIvB2wrEqAAAECBAgQIFCegMBbXs20mAABAgQIECBAoIOAwNsBy6oECBAgQIAAAQLlCQi85dVMiwkQIECAAAECBDoICLwdsKxKgAABAgQIECBQnoDAW17NtJgAAQIECBAgQKCDgMDbAcuqBAgQIECAAAEC5QkIvOXVTIsJECBAgAABAgQ6CAi8HbCsSoAAAQIECBAgUJ6AwFtezbSYAAECBAgQIECgg4DA2wHLqgQIECBAgAABAuUJCLzl1UyLCRAgQIAAAQIEOggIvB2wrEqAAAECBAgQIFCegMBbXs20mAABAgQIECBAoIOAwNsBy6oECBAgQIAAAQLlCQi85dVMiwkQIECAAAECBDoICLwdsKxKgAABAgQIECBQnoDAW17NtJgAAQIECBAgQKCDgMDbAcuqBAgQIECAAAEC5QkIvOXVTIsJECBAgAABAgQ6CAi8HbCsSoAAAQIECBAgUJ6AwFtezbSYAAECBAgQIECgg4DA2wHLqgQIECBAgAABAuUJCLzl1UyLCRAgQIAAAQIEOggIvB2wrEqAAAECBAgQIFCegMBbXs20mAABAgQIECBAoIOAwNsBy6oECBAgQIAAAQLlCQi85dVMiwkQIECAAAECBDoICLwdsKxKgAABAgQIECBQnoDAW17NtJgAAQIECBAgQKCDgMDbAcuqBAgQIECAAAEC5QkIvOXVTIsJECBAgAABAgQ6CAi8HbCsSoAAAQIECBAgUJ6AwFtezbSYAAECBAgQIECgg4DA2wHLqgQIECBAgAABAuUJCLzl1UyLCRAgQIAAAQIEOggIvB2wrEqAAAECBAgQIFCegMBbXs20mAABAgQIECBAoIOAwNsBy6oECBAgQIAAAQLlCQi85dVMiwkQIECAAAECBDoICLwdsKxKgAABAgQIECBQnoDAW17NtJgAAQIECBAgQKCDgMDbAcuqBAgQIECAAAEC5QkIvOXVTIsJECBAgAABAgQ6CAi8HbCsSoAAAQIECBAgUJ6AwFtezbSYAAECBAgQIECgg4DA2wHLqgQIECBAgAABAuUJCLzl1UyLCRAgQIAAAQIEOggIvB2wrEqAAAECBAgQIFCegMBbXs20mAABAgQIECBAoIOAwNsBy6oECBAgQIAAAQLlCQi85dVMiwkQIECAAAECBDoICLwdsKxKgAABAgQIECBQnoDAW17NtJgAAQIECBAgQKCDgMDbAcuqBAgQIECAAAEC5QkIvOXVTIsJECBAgAABAgQ6CAi8HbCsSoAAAQIECBAgUJ6AwFtezbSYAAECBAgQIECgg8D/A0U/k5jjrAlGAAAAAElFTkSuQmCC	\N	2025-10-26 02:34:01.62+00	2025-10-26 02:34:01.62+00
1895f023-9b37-4903-a803-a4f779128865	bc107c45-36b5-4af5-ae9a-02ffc46c8699	1dfa75cd-fafd-43cd-a0f7-038c2ad76812	Cristina Maria Bertolo Gouveia	present	\N	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAApbklEQVR4Ae3de8hkZR0H8GPuzb247rqrq4hWS+mWWpqFiH+UKIiIKUJg4T9RlqlU1B9Wf1hRlBAUmalZEBGFYUZQf1iKgZBIZVBuXjBBu3nf1VXX3XW7/Mae2WfmnZl3Zt553zlzns/A65w5tzm/z3PU73nmmTMH/ed/j8qDAAECBAgQIECAQEMFXtfQupRFgAABAgQIECBAoCUg8DoRCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBAgQIAAAQIEGi0g8Da6eRVHgAABAgQIECAg8DoHCBCYKYGjjjqqWrZsWfW6172u/XfQQQdV3X/58l7TBx98cBV/sa/4W758ebVhw4bq9NNPr26//faZMnGwBAgQIDBY4KD//O8xeBVLCRAgsDQCK1asqPbv31+l/yyl56V594W/S4TuCNevvvrqwndmDwQIECAwMQE9vBOjtCMCBPoJfPzjH2/1okaPaupt7e6Rjdf79u2r/v3vf7cC7yhht9e++h3LYs6PY47Anh9P1Bt1exAgQIDA9AQE3unZe2cCjRSIcJcHvpj+5je/2QqCo4bZfD8RHDdt2tQOwxEu01/st/svLRv3+QMf+EAVwyei1zmGPORhPY4lP7aY7veI949jy9dPIfjTn/50v83MJ0CAAIEJChjSMEFMuyJQqkAEwhRmhzVIITEFwQsvvLC69dZbh9281uvFeODo6Y1HBN5hHslh8+bN1RNPPDHMJtYhQIAAgSEFBN4hoaxGgECnwFvf+tbqgQce6BvoUoCLntG9e/d2blzgq/Xr11e7du1qVT5KCI4N4oKCYYEnjZIJEJiYgMA7MUo7IlCGQHwc3y+wRciNnl6P4QTOPvvs6q677moPzRhmK8bDKFmHAAECnQICb6eHVwQI9BCIXtp+QTYC2LZt26rt27f32NKscQTCOy4q+l1YxD4F33FkbUOAQKkCAm+pLa9uAvMIDBqXG2ErenrdfmsexAku7tcegu8Eke2KAIHGCrhLQ2ObVmEERhc48cQTW0E2QlR+P9y0pzScIXp7hd2ksjTP4Z2+GBjtkx7RC5wuQNI8zwQIECDQKaCHt9PDKwJFCqQg26t4PYi9VOoxr1e7aa96tI2jIECgXgJ6eOvVHo6GwJIKRDiKv+6xojHv+OOPb83vN3Z3SQ/Um/UU0OPbk8VMAgQIzBHQwzuHxAwCzReI8aDpPrGp2gi5xuUmjdl81uM7m+3mqAkQWHwBgXfxjb0DgVoJdIeiCLp6cWvVRAs+mO42jh1q5wWz2gEBAjMsYEjDDDeeQycwqkB3EHrXu94l7I6KOAPrG+owA43kEAkQWFIBgXdJub0ZgekIXHbZZR1jdaO3L8bt3nvvvdM5IO+6JAKC75IwexMCBGZAwJCGGWgkh0hgIQLdPxrho+2FaM72tt09/M6F2W5PR0+AwPACeniHt7ImgZkTiICTj8/tDr8zV5ADXpBA6vFNO4le/jhHPAgQINB0AT28TW9h9RUrEL13+aP71mP5MtPlCeS9vXp6y2t/FRMoTcClfWktrt7GCxxxxBGt8bqp0Agzwm7S8JwEorc3XRTp6U0qngkQaKqAHt6mtqy6ihToHrKg567I02CkovX0jsRlZQIEZlRAD++MNpzDJtAtYLxut4jXwwjo6R1GyToECMy6gB7eWW9Bx0/gfwLpo+mEYQhDkvA8rICe3mGlrEeAwCwK6OGdxVZzzAT+L7B8+fKOsGu8rlNjXAE9vePK2Y4AgVkQEHhnoZUcI4EeAtEj9+qrr7aXdA9paC8wMRGBE088sVqxYkXrNl5hHX9xgRHPRx555ETeY9o7EXqn3QLenwCBxRIQeBdL1n4JLKJAhKx82MKaNWuq/fv3L+I7NnfX/YJshNn8b/v27dW+ffta7mGf/OP5qaeeaoffM888c6axhN6Zbj4HT4BAHwFjePvAmE2grgIRwvJHCl75PNO9Bbrteq81mbnxXjfeeGMVP+s8i4/8oipqiSDsQYAAgVkV0MM7qy3nuIsUyANbTAu7w50Ghx56aMdY5/m2Ctv4i9u8HX300dUvfvGLjp7dcM//PvShD83Zfyz/yEc+0u75ne8967a8u6f3sMMOq9shOh4CBAgMLaCHd2gqKxKYrkB32NXjNlx75D2VsUUKs1u2bKluuOGG6oILLhhuR0OudcIJJ1QPP/xw34uReP9Zarv8vHOBNeRJYDUCBGonIPDWrkkcEIG5AnnomLXANLeapZuTu8W73nzzzVX0xi7VI3qWX3zxxb7hN8J43cde5xcM0cu7Y8eOpeLzPgQIEJiYgMA7MUo7IrA4AnngEHaHMz7nnHOqO+64o71yHdziDg/xpbdejzi+lStXVrt37+61eOrz8gsHvbxTbw4HQIDAGAIC7xhoNiGwVALC7ujSuVlsXYew211F909A58vreLy5qV7evLVMEyAwKwK+tDYrLeU4ixPIQ0YdQ1AdGyQ3i+M79thjazleNoYxpC+95b2nccwxP+qo0yMfc7xz5846HZpjIUCAwFAC9fqv6lCHbCUCzRfIg5uwO1x7h1P+cXtMP/bYY8NtPMW1Ikym8JsOI15v3rw5vazFcx7MN2zYUItjchAECBAYVsCQhmGlrEdgiQTysBtvmYe4JTqEmXqb+GLYrl272sc86xcIebCsW9vX+djaJ4AJAgQI9BDQw9sDxSwC0xIQdkeTD6887MYXw/KP30fbWz3Wzn+pLQ+YdTi6/Hj08tahRRwDAQLDCgi8w0pZj8AiC8QXmfIevXx6kd96Jncf4Ss3uummm6o9e/bMZC35Qd99990dY3gj1NflkV9MGMtbl1ZxHAQIDCNgSMMwStYhsMgC3d/az4PcIr/1zO3+7LPPru688872cUfwzYNYe8GMT+S9/XWqMT8u5+mMn2QOn0BBAvXpOigIXakEcoFly5Z1BDYhItfpnI6wVULYjarzEB/nRF2+xPaOd7yjs1G8IkCAwAwI6OGdgUZyiM0VWLVqVcfH8MJu/7bOexZjrbjl2CzchaF/RcMtycfN1uX8SMcUF2v9fkxjuOqsRYAAgaUR0MO7NM7ehcAcgTe96U0dYfeCCy6Ys44ZrwlEwMrDXkyXEHaj+jp/iS3vhXauEiBAoM4Cenjr3DqOrbECP/7xj6v3v//97fr8elWbYs5E3rNbp7Gscw50EWfkY7zrYJB6eOtwLIvIbtcECDRIQOBtUGMqZXYEUmCII/ax8OB2S1alh6s6BX9tMvictZQAgfoJGNJQvzZxRA0XSGEhyoyeO2Mg+zd4hLz0KP3j87z+GNIxzS+xpXM4H2aS2skzAQIE6iigh7eOreKYGiuQ99LF9P79+xtb6yQKS8EqnvPAN4l9z+o+kkkc/7QCZ34eT+sYZrX9HDcBAtMRONB9Mp33964EihHIf1giQouwO7jp9e729qnDl9jy0N37KM0lQIBAvQT08NarPRxNgwXykKBXbP6GTl7xrHe302vaX2KLcefpgs253Nk2XhEgUE8BPbz1bBdH1TCBFN6iLAFh/sbVuzvYKMJmOqecT4OtLCVAgEAICLzOAwKLLJCHt3x6kd92pnefQlwKdTNdzCId/MaNGxdpz3ZLgACB5gkIvM1rUxXVSGD16tXtHt0Ib+lj4BodYu0OJb8oMJShf/Ns3bq1/0JLCBAgQKBDQODt4PCCwGQFdu/e3d6h8NamGDihd3cgT3vhpZde2p42QYAAAQKDBQTewT6WEhhbIO+pjC/5eMwvkJu5QBjsdeWVV7ZX+P73v9+eNkGAAAECcwUE3rkm5hBYsED3Lcj8uMRwpHp3h3PqXuu73/1u9yyvCRAgQCATEHgzDJMEJiWQ907m05PafxP3o3d3/FZ96KGHxt/YlgQIEChAQOAtoJGVuLQC+Z0Frr766qV98xl+N7274zferl27xt/YlgQIEChAwA9PFNDISlw6geilzIOb3t3h7HO35DfclmWvlS6uwm8p7wDihyfKPu9UT2AWBfTwzmKrOeZaCpxyyintsBsHKOwO30wp5KYAN/yW1iRAgAABAvML6OGd38gaBIYSyMNaCnBDbVj4Snp3xz8B0jkXz0t5gaWHd/w2syUBAtMR0MM7HXfv2jCBCG3pkU+neZ77C6SLgxTe+q9pCQECBAgQGE/gwP+lx9veVgSKF4jerjy0LeVYylnHzy8OlrKHctbdHD8BAgQIjCYg8I7mZW0CcwTygCu0zeEZOCO/UBi4ooUECBAgQGABAgLvAvBsSiDvody0aROQEQRyOxcKI8BZlQABAgRGFvCltZHJbEDggEAad7rUXxo6cASzO8Vu4W0XFw2plzw9L3yv8+/Bl9bmN7IGAQL1EtDDW6/2cDQzJLB8+fL20R5yyCHtaRPzC+jdnd/IGgQIECAwOQGBd3KW9lSYQD5296WXXiqs+oWVm3ojUy/vwvZmawIECBAgMFhA4B3sYymBvgJCW1+agQvWrl3bXm7sbpvCBAECBAgsooDAu4i4dt1cAR/Jj9+2L7/88vgb25IAAQIECIwhIPCOgWYTAnp3nQMECBAgQGB2BATe2WkrR1oTAV9Wq0lDOIxqWmOgX3311dZ75590aA4CBAjUWcBtyercOo6tlgLTuhVULTHGOKgU0uLZGN4xALNNnIsZhkkCBAgMENDDOwDHIgK9BAxn6KViHgECBAgQqK+AwFvftnFkNRTIP8LVO7mwBlq5cuXCdmDr9o9OpF5zJAQIECDQW0Dg7e1iLoGeAnp3e7KMNfOEE04YazsbzRXIx5XPXWoOAQIECAi8zgECQwrkocIvqw2J1rXan//85/ac3/zmN+1pE6MLrFmzpr3Rnj172tMmCBAgQGCugC+tzTUxh0BPAV8Q6sky0sxt27ZVDz74YGub1Fs+0g6s3BZwPrYpTBAgQGBeAYF3XiIrEHhNII2TdHeB8c+IFStWVPv27WvtQOAd3zG2dD4uzM/WBAiUJWBIQ1ntrdoxBQ4++OD2lr6s1qYYeSLu3+oxWYEUfCe7V3sjQIBAswQE3ma1p2oWSUBv5CLB2u1YApdcckl7u2984xvtaRMECBAg0FvAkIbeLuYS6BDIe9GE3w6akV4kx3jWUz4SXcfKxu92cHhBgACBeQX08M5LZAUCBwRSYDswxxQBAgQIECBQdwGBt+4t5PhqJSDwTqY5OC7MMX3KwHFhjrYmQKAcAYG3nLZW6QQEjjnmmAnsxS7Wrl0LYQIChx122AT2YhcECBBovoDA2/w2VuECBfIfnHjssccWuDebh8C5554LYkyBZcuWtbd87rnn2tMmCBAgQKC/gMDb38YSAi2B/fv3k5iAwDXXXNPeyy233NKeNjGaQFO/7BcXlps3bx4Nw9oECBAYUkDgHRLKagQILEzgxhtvXNgObN0SaOL43aOOOqqKezQ/88wzVdyB4ktf+pLWJkCAwEQF3JZsopx21kSB9MWgeG5q79pStFt8FJ96y1NoW4r3bdp7pPMxgmHynOUa77jjjuqcc86ZU8KmTZuqp59+es58MwgQIDCOgB7ecdRsQ4DAyAIuFkYmm7PB61//+va8JoTdKOb8889v1RQB/lvf+lb7J5P19rab2gQBAhMQ0MM7AUS7aLZA6lGLnxf207jjt7UfSxjfLm3ZNMOLL764uu2221rlfepTn6q+9rWvtaZjiMMTTzyRyq7irh67du1qvzZBgACBUQUE3lHFrF+UwBlnnFHdc889rZp9DL+wpk8XDoaGjO+YDGMPTTgfU4Bft25d9cILL3TAXH/99dVVV13VrrMJ9XYU6AUBAksqYEjDknJ7s1kTuPfee2ftkB1vAQJ58J3Vcj/3uc+1w+xTTz01p4wrrriiY8z8m9/85jnrmEGAAIFhBQTeYaWsV6RAPk7STf4ncwrE0BCP0QXyUPj2t7999B3UbIudO3e2jijOh1WrVvU9unS+PPLII33XsYAAAQLzCQi88wlZTuD/At0fuYIZT2DLli3jbVj4VrnbfffdN/Majz/+eKuGFStWDKzlrLPOai03pGEgk4UECMwjIPDOA2QxAQKTFfjsZz872R0WsLcjjjii/fF/E4YzRJM9+eSTrZYb1LsbK/zqV79qrRf/MKyhTWGCAIERBQTeEcGsXp5AChh6mMZv+/POO6+98eWXX96eNjGcQH4/2qbc3i39LPKaNWvmRTCsYV4iKxAgMI+AwDsPkMUEUuAlMb7Ab3/72/E3LnzLuJNBeqxcuTJNzvxzus3YMGPjDWuY+eZWAIGpCxz4L+nUD8UBEKingC+uLbxd0heUYk9HH330wndY0B7SJwtx4fXKK680pvKXX365VcvmzZvnrcmwhnmJrECAwDwCAu88QBYTyAV8cS3XGG86/0GB8fZQzlb5pwtNGcqQWm/v3r2tyWEvgAxrSHKeCRAYR0DgHUfNNgQIjCyQwlvqsRx5B4VtkAJelJ3smkSQfrUw/7nkQfWtXr26tdj5M0jJMgIE+gkIvP1kzCeQCaTA4X+2GcqIk8OM1Rxxl41ePe/RzaebUnT6d2nbtm1DlbR79+6h1rMSAQIEegkIvL1UzCPQJZACb9dsL0cQSN/Kj02G/Rh7hN03atX8i2pnnnlmo2pLxaTAe/LJJ6dZA59Tj/AhhxwycD0LCRAg0EtA4O2lYh6BLoH8i2sbNmzoWurlqALG8fYXO+OMMzruuXv33Xf3X3lGl+QXPyeddNJIVZx77rkjrW9lAgQIhIDA6zwgMKLA888/P+IWVk8Cqac89e6l+Z4PCNxzzz3tF00cyhDF/f73v2/XOMzERRdd1F7ttttua0+bIECAwLACAu+wUtYjQGDBAsbxDibMhzLk04O3mr2lDz300EgHffvtt4+0vpUJECDQLSDwdot4TaCPgN7JPjAjzM4/yjaOdy5c3vOdD6OZu+Zsz7nqqquqNBb3wx/+8LzFpC+sLVu2bN51rUCAAIFeAgJvLxXzCPQQyHvc8ltG9VjVrCEEjOPtRMrPrzz4dq7VnFcXX3xxq5if/vSnQxd1/PHHD72uFQkQIJALCLy5hmkCAwTSt8RjlaaOrRxQ/sQW6SmfS7lq1aqOL6rNXaN5c66//vpWUTt27Kh+8pOf9C3wuuuuay+7//7729MmCBAgMIrAQf/rSfjPKBtYl0DJAo8//nh13HHHtQn869OmGHpi48aNVYScePB7jS1dBJRmEndoiBB76qmnVn/4wx9ew+j65xFHHFE9/fTTrbnOly4cLwkQGFpAD+/QVFYkUFXHHntslX/0nE/zGU7AON5Op/wcinBX0uOTn/xkq9w//vGPfct+5plnWsvyi4K+K1tAgACBPgICbx8Yswn0E4gvE6X/+UaP09atW/utav48AqWP442P9VOvZZxTTz755DxizVr8wQ9+sFq3bl3L4LLLLutZXPLZtGlTz+VmEiBAYBgBgXcYJesQ6BLIx/A++uijXUu9nE8gv2CYb90mL7/yyivb5eXnVHtmARPvfe97W1XeeuutA6u95pprBi63kAABAoMEjOEdpGMZgQECcYukdOuoCHClBpYBRH0XGcdbVXGnj3TOxLCGdC71RWvoghdeeKFav359q7pbbrmlet/73teuNDdKPb3thSYIECAwgoAe3hGwrEogF4i7NuQ9le4RmusMnjaOt/NOH6WG3ThLDj300OrEE09snTDXXntt+8R55zvf2b4gWLt2bXu+CQIECIwjIPCOo2YbAv8XSD108bLk0LKQE6LEcbzpQincvve97y2ErxHb9vryWv7zw7t27WpEnYogQGB6AgLv9Oy9c0METjvttHYl+Tfu2zNN9BRIoa+0j6pT3YES50t8cav0R/eX1/IfdvnZz35WOo/6CRCYgIAxvBNAtAsCEVxScItAk/f80uktUOI43jzsOk86z4tLL720+uEPf9gxM4Yy6N3tIPGCAIExBfTwjglnMwK5QB5wI/jeeOON+WLTPQRKG8cr7PY4CbJZ6ZfXslnCbo5hmgCBBQno4V0Qn40JdArkoSb1+Hau4VUukLya3tvpE4C81ftPp/Mh1oihDBdeeGH/lS0hQIDACAJ6eEfAsiqB+QTyMbz59Hzblbo8BZwmXxwIu8Od3XFXhvxR4pcZ8/pNEyAwWQE9vJP1tDcCrS8ipQC3cuXK6pVXXqHSR+Dwww+v0tCGJvbyCrt9Gr7H7HTxky+64YYbqo9+9KP5LNMECBAYS0AP71hsNiLQXyAfz7tnz57+K1pSPfvssx33Mm5Sr7iwO/wJ3n1Xhq985SutjS+//HLj4YdntCYBAgMElg1YZhEBAmMKxLfLX3zxxdbW0XOVenzH3F2jN4sLhNS7F07xAx7xox6z/BB2h2+97h+YyMftfuYzn6ki9MZDT+/wptYkQGCugCENc03MITARgTz0xA7jtR+n6E+bQm+ssXz58mrv3r39V67xku52d7EzuLHydu+2+upXv1pF6I2H4Q2DHS0lQGCwgCENg30sJTC2QN5zGTvpfj32jhu6YR529u3bV61bt27mKhV2R2uy7qEM3VtfffXVleEN3SpeEyAwjoDAO46abQgMKRAh96yzzupYO3q0Ihh5zBXIQ28MCTnyyCPnrlTTORHe8uPPp2t6yFM9rEFDGfIDE3pzDdMECIwrYEjDuHK2IzCiQASiCMD5w10cco0D0/nH3G95y1uq7du3H1hYw6nuthV2BzfS7t27q9WrV7dXGsbL8IY2lwkCBMYQ0M00BppNCIwjEON343/seZiLuzjo7Z2r+cILL7Rn/uUvf6nOP//89uu6TcRFS34hM0x4q1sNS3k8Rx99dEfYjR+YGOahp3cYJesQINBPQODtJ2M+gUUSiHAUX8pKjxSC8/GMaVmpzzF+9+tf/3q7/F/+8pfVF7/4xfbrukxs2LCh48t1wu7glomLu3/961/tlbZu3TrSr6kJvW06EwQIjCgg8I4IZnUCkxCIOxCkoJv2F0E4en8vvvjiNKvo50984hPVRRdd1Da45pprqscff7z9etoTMdRi586d7cP4whe+0J420SkQtxaLczu/IIjpRx55pHPFIV51h964e4MHAQIE5hMwhnc+IcsJLLLAAw88UEV4yh8RDvKPyfNlpU2/7W1vq/70pz+1y85DU3vmEk/EPWFvuumm9ruedtpp1e9+97v2axMHBA455JCOXxuc1Lj1NKb3pJNO6jg/DryzKQIECBwQEHgPWJgiMFWB7i8+xcHEvFn/EYZJoMa4z/yj8GmH3nwc9qZNm6qnn356EmU2bh+5UxR3ySWXVD/60Y8mVuett95avfGNb6xOPfXUie3TjggQaKaAwNvMdlXVDAt038tVb+9rjbl+/foq/zLbtEJvHuJWrVpVxR0HPDoFtm3bVj344IPtmc7hNoUJAgSmJCDwTgne2xIYJLBx48Zqx44dHasIDVUVH4fnv8C2lKG3u03iwsQv53Wcoq0X3Z9U6AGfa2QOAQJLL+BLa0tv7h0JzCvw3HPPzflSW4S7CL1btmyZd/umrhC3ccvvZpH3ti5WzaecckrLPb8AEXbnav/gBz9oOeVjz++//37DPeZSmUOAwBQE9PBOAd1bEhhVoHuYQ2y/Zs2aKn6NrMRH7rFYPd9xG7TPf/7zHXcWCGthd+4Z1z3cZNmyZVX8PLQHAQIE6iKgh7cuLeE4CAwQiF6zCFr546WXXmr1qMX8/J61+TpNnU63cIv6oue722ahdcf+4jZo+ZCJmBevDWPo1I0Ljnxs9emnny7sdhJ5RYBADQT08NagERwCgVEEUvDqtc1i9Xb2eq86zOu2WLt2bbVr166xD617f7Gj0kyHxTvrrLOqu+66q2P1/AKhY4EXBAgQmLKAwDvlBvD2BMYVOPbYY6u///3vHb2Q+b4ivJXQG9krpIZDBNU3vOEN1V//+tecped0r30Iuj2pWjPjlwLz2+WVPLymv5IlBAjUSaDzM9I6HZljIUBgoED86lh8tB+9avkXudJG6WP/CHPR89nUR6qzu75wefTRR1vBN8JrOFx44YUdq8W8WJb3TKbXsV+PAwJXXnlltWLFipZXHnavvfbaYseSH9AxRYBA3QX08Na9hRwfgREFum8LlW8eYe66666rrrjiinx2o6bjl7e2b9/eEWKHKTBshNwDUhFwv/Od7/QdjxsXCyV8gnBAxBQBArMsIPDOcus5dgLzCEQoyXsv89VLCXiHH354657G/RzCJCziY/mFjP/NbWdxer6Am2oKq6OOOqr6xz/+kWZ5JkCAQO0FDGmofRM5QALjC0SPZQS9Y445phXq8j3F/Agv8ddrSES+7ixPP/vss3Nq764nLOIWb8kjLhS2bt3avVqjXkcvfxqiEHVff/31PXtzY9mhhx7aup9uOMU5Jew26lRQDIEiBATeIppZkaUL/O1vfxtqvG+Emwh78Rch+D3vec9M00UNUVP3UIWLLrqodSFw2WWX9bylWQS77vG/sc0sP7oD7re//e2hA+7zzz9fxS+meRAgQGBWBQxpmNWWc9wEJiAwaLxvv91HgIxHPL/73e+u7rzzzn6rTm1+908QpwOJnu4I//0ew47/jR9W+PnPf16dd955/XY19fkRcG+++eaeoTY/uGjHdevWte5mIdTmMqYJEGiSgMDbpNZUC4EFCESvbjyid3Mhj0kE4o997GPVr3/96+qJJ56oXnnllXYP7aBjG7Rs9erVVfxQx6iPjRs3Vjt37hzJJNWf3itex19cXIRxhOVVq1ZVcUwxVGDz5s2tISfbtm2r4kcbxu1VF3CTuGcCBAjMFRB455qYQ4BAJrBhw4bWL2mlQJmes1VqOxkhM7+F1kIONML3cccdV+3du3chu1nybSNs68FdcnZvSIBAzQSM4a1ZgzgcAnUT2LFjR+v2UzEONn0JLkJv+lu/fn2r5zL1ZE7r+NP7x3P0pMbxTSrsRk1btmyp9uzZ0647jf/N3zemp/2IY+j+kpkxuNNuFe9PgMC0BfTwTrsFvD+Bhgscdthhrdt9dfcMp3AYz/HLXbHeySefXH35y1+uTjvttIar9C/vqaeeav1k73333dcaV/vPf/6zeu6551q97Lt3726NyY0gH/fATRcdcUu1hx9+uBXK++/ZEgIECJQrIPCW2/YqJ0CAAAECBAgUIWBIQxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBECAm8RzaxIAgQIECBAgEC5AgJvuW2vcgIECBAgQIBAEQICbxHNrEgCBAgQIECAQLkCAm+5ba9yAgQIECBAgEARAgJvEc2sSAIECBAgQIBAuQICb7ltr3ICBAgQIECAQBEC/wVg1iLqyxDDnwAAAABJRU5ErkJggg==	\N	2025-10-26 16:36:13.005+00	2025-10-26 16:36:13.005+00
775d182f-4aee-4e8a-a0f6-abe63b56a0d1	bc107c45-36b5-4af5-ae9a-02ffc46c8699	6a62625e-1264-4588-b6bf-a7a8ca0771bd	José Manuel Costa Ricardo	present	\N	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAAebUlEQVR4Ae3dS6hbVfsH4O2ttRc/a21tvVSKl9Z2oKgVb1BHRRwodSTiwIHiRMXagR2IiEV0pggOFBF0IA4UixNFnThQKzgQLxTR0hasbZVaQW3txcvnm/9/n2+fnOScpF0nZ2Xl2XBITrKzstbzrjS/rrOzc9I//26VjQABAgQIECBAgEChAicXOi7DIkCAAAECBAgQINASEHhNBAIECBAgQIAAgaIFBN6iy2twBAgQIECAAAECAq85QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4DUHCBAgQIAAAQIEihYQeIsur8ERIECAAAECBAgIvOYAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1xwgQIAAAQIECBAoWkDgLbq8BkeAAAECBAgQICDwmgMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARec4AAAQIECBAgQKBoAYG36PIaHAECBAgQIECAgMBrDhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHjNAQIECBAgQIAAgaIFBN6iy2twBAgQIECAAAECAq85QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4DUHCBAgQIAAAQIEihYQeIsur8ERIECAAAECBAgIvOYAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1xwgQIAAAQIECBAoWkDgLbq8BkeAAAECBAgQICDwmgMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARec4AAAQIECBAgQKBoAYG36PIaHAECBAgQIECAgMBrDhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHjNAQIECBAgQIAAgaIFBN6iy2twBAgQIECAAAECAq85QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4DUHCBAgQIAAAQIEihYQeIsur8ERIECAAAECBAgIvOYAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1xwgQIAAAQIECBAoWkDgLbq8BkeAAAECBAgQICDwmgMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARec4AAAQIECBAgQKBoAYG36PIaHAECBAgQIECAgMBrDhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHjNAQIECBAgQIAAgaIFBN6iy2twBAgQIECAAAECAq85QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4DUHCBAgQIAAAQIEihYQeIsur8ERIECAAAECBAgIvOYAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1xwgQIAAAQIECBAoWkDgLbq8BkeAAAECBAgQICDwmgMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARec4AAAQIECBAgQKBoAYG36PIaHAECBAgQIECAgMBrDhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHjNAQIECBAgQIAAgaIFBN6iy2twBAgQIECAAAECAq85QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4DUHCBAgQIAAAQIEihYQeIsur8ERIECAAAECBAgIvOYAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1xwgQIAAAQIECBAoWkDgLbq8BkeAAAECBAgQICDwmgMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARec4AAAQIECBAgQKBoAYG36PIaHAECBAgQIECAgMBrDhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHjNAQIECBAgQIAAgaIFBN6iy2twBAgQIECAAAECAq85QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4DUHCBAgQIAAAQIEihYQeIsur8ERIECAAAECBAgIvOYAAQIECBAgQIBA0QICb9HlNTgCBAgQIECAAAGB1xwgQIAAAQIECBAoWkDgLbq8BkeAAAECBAgQICDwmgMECBAgQIAAAQJFCwi8RZfX4AgQIECAAAECBARec4AAAQIECBAgQKBoAYG36PIaHAECBAgQIECAgMBrDhAgQIAAAQIECBQtIPAWXV6DI0CAAAECBAgQEHjNAQIECBAgQIAAgaIFBN6iy2twBAgQIECAAAECAq85QIAAAQIECBAgULSAwFt0eQ2OAAECBAgQIEBA4DUHCBAgQIAAAQIEihYQeIsur8ERIECAAAECBAgIvOYAAQIECBAgQIBA0QKnFj06gyNAYGQEfvvtt+rDDz+svvzyy2rHjh3Vnj17qv3791dx+8GDB6vDhw9XR48erY4dO1b99ddf1d9//139888/Yz+TQcV+k20nnXRS6+64PO2006r58+dXy5cvr9atW1c9/fTTkz3UfQQIECAwAIGT/v2HfPJ/yQfQCU9BgECZAr/++mv1wAMPVB9//HH1448/tkJnBM16889PVTXD8imnnFLNnTu3WrJkSbVmzZrqkUceqa644oqay+WQCqxYsaLatWvX2H+yYhjtc7/99yEd6kh2O17DzX/XRhJhCAYt8A5BkXSRwEwK1KH1o48+qn766aeRDK11KO1Wh5kKK81+RViePXt2ddZZZ1WrVq2q7rrrruruu+/u1mW3TyLw+OOPV88888y4ud6pxp1um6RZdxUsYC7kX1yBN/8a6SGBExaI0Hr//fe3VlpzCq3NwFYPMm47+eSTWyufEeJOPfXUqg5zsfp5xhlnVAsWLKgWL15cXXjhhdVll11WXX311a0V0bqNnC63b99ePfXUU9XWrVurffv2VYcOHar+/PPPsRW+mXijDOOFCxe2DvnIyWo6+7J27drW/A/vmTDvZWydXg+9PM4+MyPQnEfN6zPTG886lYDAO5WQ+wlkLnDeeee1glR0cyb+0W2+SUdQPf3001th9Prrr69eeOGF6j//+U/mgnl374knnqjefffdaufOnVX8xyWOQ67rXF+e6AiihlGvOPSkhC2Oo47jtGNLZdTJpTn36/vr2+K1MGfOnCrq9/DDD9d3uyxIIP4zPoh5VhDZjA5F4J1Rfk9OoDeBK6+8svrqq6/GHQPY2yN726t+k469hdbezIZhrzfffLN65ZVXqq+//rr6+eefW3+ijzfoqUJgBMZXX321uvPOO7MeZhxmc9NNN7XGM9WY2gdSz/nmZcz9lStXtl5r7fv7nUAngZgzMYfq4NtpH7flISDw5lEHvSDQChdbtmwZt4LXL0v95i209is3mvuvXr26+uabbyYNwDGncjj8YdasWa1DQaJS/YTb6H/8PProo9XmzZtHs9BGTYBAJfCaBAQGKPDyyy9XGzdubJ0qK562nzfuupt1qJ03b1715JNPVg899FB9l0sCJyQQp1OLU7hNtsX8m+7DH+JPxfVp4ybrS/O++nURx3vHqedsBAgQaAr44ommhusEEgnEh5Tiz8L1n7vizTh+7r333tZxmBF0pwq7sX+0sX79+ta+9WMiCMRPnF9W2E1UMM20BH7//fexuRanRIvw2L7FPPzkk09a8znmaKy8vv766+279fT7okWLWs/R/jqZ6rCLeN54zKWXXjrW3/p1Iez2RG8nAiMnYIV35EpuwKkFli1bVv3www+tZqcKse3PXb9xx5kG4jhLG4FcBXo9/CFOixbHC7dv9apt3N7P66R+jcSZLWwECBA4XgGB93jlPG6kBeJNuNet3vecc84ZO5tCr4+1H4FcBXo5/KGfvtevkzj1XKw02wgQIJBSwCENKTW1NRIC9Rtzp8HGfXEqou+++27Cn1rjHKw2AqUItB/+MNnron3MsW8cklAfphOX9SEJwm67lt8JEEghYIU3haI2Rkag+aYe1+NrXz///PORGb+BEmgKxDG+dWht3t7L9Xj9dDv8oZfH24cAAQL9CFjh7UfLviMtECu39RZv9LEiJezWIi5HQWDDhg3jPogZr4H243EjyDaDcNwfZxRp3+L2AwcOjH34LVZ8b7zxxvbd/E6AAIEkAgJvEkaNjIJA843dB2hGoeLGGALNs40899xzEwJu7BMh9+abb27dFyG4/fXRfvhDr2d/eO2116J5GwECBE5YwCENJ0yogVERiK/MPXLkSGu4zfA7KuM3ztERqP+C0W3EEXDjJ8W3S/V69odrr7222rp1a7cuuZ0AAQKTCljhnZTHnQT+JyDk/s/CtbIELr744gmHKrSPMAJunFosXgexipsi7MZzbNu2rdVetBs/3Q5/+PTTT1shOw59iC++sBEgQKAfAYG3Hy37EiBAoBCBCK8RHiPI7tixo+uhCjt37hwLuYP4Uofm4Q+bNm1q9bFJHqFY+G2KuE6AQC8CDmnoRck+BP4VmD17dnX06NGWRbzp2ggMm0B9KrBu/U55qEK35zje27dv317F4Q/dQnf03WEPx6vrcQTKF7DCW36NjZAAgREViC+HqFdxIxB2+o9a3B5fDxz3pTxUITX5JZdc0voPZ/QzznMdH6ZrbnG7ld+miOsECDQFrPA2NVwnMIlAhIJ6dalTcJjkoe4iMDCB5inBuj1phNwItyVsVn5LqKIxEJh+ASu802/sGQgQIDBtAg8++OC4VdwIsu3/IYuA2wzCpYTdQLXyO21TS8MEihKwwltUOQ1mOgWs8E6nrrb7EWiG126Pi5C7dOnSas+ePd12Kfp2K79Fl9fgCPQtYIW3bzIPIECAwGAFLrjggilXcaNH9YfSYoU3VnFHNeyGhZXfULARIFALWOGtJVwSmELACu8UQO5OKtDrKm6cXqw+e0jSDhTamJXfQgtrWASmEBB4pwByN4FaID4VXn9lavsxkvU+Lgkcr0B8k18E18nmVhymED+pvvThePtayuOE31IqaRwEphZwSMPURvYgQIDAtAjEKm4dYuNrqzuF3bh/0aJF2Z82bFqAprlRhz1MM7DmCWQkYIU3o2LoSt4CVnjzrs8w9C7mUKzOdgq2df/rAGwVtxYZ/GUvK78lneli8MKekcDgBazwDt7cMxIgMEICzS9+iENiOoXdCLm33HKLVdxM5kUvK79Rs6jtBx98kEmvdYMAgckErPBOpuM+Ag0BK7wNDFe7CsSHyDqdC7f5gDos1ceEN+9zPV+BWPlduXJlxy/teOyxx6rNmzfn23k9IzDiAgLviE8Aw+9dQODt3WrU9oxjcaf6E3eE3Kn2GTW3YR7vvHnzqkOHDk0Ywu2331699dZbE253AwECMysg8M6sv2cfIoFYuauPq+z0Z+khGoquJhCYKuRGwI196q+jTvCUmshQYOHChdUvv/wyoWdr1qypPvvsswm3u4EAgZkREHhnxt2zDqGAwDuERUvc5V5CrlXcxOhD0tyyZcuq3bt3T+jt8uXLq507d0643Q0ECAxWwIfWBuvt2QgQGDKBCLmxWtvtkIT2bzcbsuHpbiKB77//vvWhw8svv3xci7t27WrNncWLF4+73S8ECAxWQOAdrLdnI0BgCAT6Cbn1YS5DMCxdHIDAF1980Qq+cdaN5rZ///5W8J0/f37zZtcJEBiQgMA7IGhPQ4BA3gJCbt71GbbevfPOO63gu2HDhnFdP3jwYCv4xjfr2QgQGJyAY3gHZ+2ZhlzAMbxDXsAO3Z/qmNw4XMEKbgc4N/Ut8MYbb1R33HFHKwQ3Hxz/rvhgY1PEdQLTIyDwTo+rVgsUEHjLKKqQW0Ydh3kUneag/1wNc0X1fRgEHNIwDFXSRwIETkjA4QonxOfBiQXirwZxasOYl/UWZ/eID0bGf6xtBAikFxB405tqkQCBDASE3AyKoAuTCtRfNR1falNvEYYF31rDJYF0AgJvOkstESAwgwKrV6+u4s/CvZ5CzLG5M1gsTz1O4OjRo60V3+YH2erg2wzD4x7kFwIE+hJwDG9fXHYeZQHH8OZX/VjFjT8NT/bNd46NzK9uejS5wJw5c6rDhw+P28mH28Zx+IVA3wJWePsm8wACBGZKIN7021dxO4Xd2KcOwlZyZ6panvd4Bf74448JK75x+EP89cKK7/GqetyoCwi8oz4DjJ9AxgJz584dF3AjvHYKuBEEli5dKuRmXEtd619A8O3fzCMIdBMQeLvJuJ0AgYELvP322+MCbv2G396RCLjNwxniE+579+5t383vBIoQqF8HzWN8rfgWUVqDGKCAwDtAbE9FgMBEgQiu9WEK69ev77qC2zxMIQJuvOHbCIySwGTB97777hslCmMl0LeAwNs3mQcQIHAiAnEMYh1wY6U2wmu3wxTia1njvtjHsbgnou6xJQnUwTf+s1hvL730UtVcAa5vd0mAwP8JCLxmAgEC0yZQf8isGXDrc4+2P2n9gZz6w2YRcp999tn23fxOgMD/C8RradOmTWMeR44caX2wzWrvGIkrBMYEnJZsjMIVApMLOC1ZZ59YVTp27NjYB8Y67zXx1gi48WPldqKNWwj0KxAf8IyV33qbPXv2hFOb1fe5JDCKAlZ4R7HqxkygT4Ebbrih9SGxWKltrtZGYI1VpW6HJTSfJvaNxzZXcIXdppDrBI5f4NChQ1Z7j5/PI0dAwArvCBTZENMIjMoKb4yzlwDbSTVCbWxxuXLlymrbtm2ddnMbAQLTKNC+2jtr1qzWf0yn8Sk1TSB7ASu82ZdIBwlMn0D7B8giqHY7122zF/VqbTy+XrGtP1xWf8BM2G2KuU5gcALtq73x1cXxmr3mmmsG1wnPRCAzASu8mRVEd/IVGPYV3gsvvLDavXt3CzjC6VRbvEHGFochOAXYVFruJ5CnwPz586uDBw+OdS5ez1u2bKluu+22sdtcITAKAgLvKFTZGJMIxCmAYvUytl4CY5InPc5Gvv3222rVqlVjq6+9NBMBN8YYH0CzESBQjsCOHTuqFStWjPuAaHzYtPkht3JGayQEOgs4pKGzi1sJTBBofsAqVklmajv33HOrWG2uv7Ah+hI/EVjrnzh+drLjcOtw2344grA7U1X1vASmT+Ciiy5q/ZVm3bp1Y09y+PDh1r8XZ5999thtrhAoWWDm3rVLVjW24gVSr/CuXbu2FWLr8NoeYOsgG5f79u1rrdTUgbYOrd3Q4zHR3nvvvTe24huPdZhCNzG3EyhT4P3332/9G9AMuQcOHGgF3wULFlTXXXddmQM3KgL/CjikwTQg0IdABMfUYbePp5901wi29bZkyZJq79699a8uCRAgMEEgztUbH2hrbi+++GLliyuaIq6XImCFt5RKGsdABCLwDmprrurG88ZhDPfcc8/YKm29sltfxqpt/SPsDqpKnofA8ArEObSvuuqq6vzzzx8bxPPPPz923RUCJQlY4S2pmsYyEIGUoTdCbZwj04dHBlI6T0KAQBeBjRs3VmeeeWZ16623tkJwl93cTGBoBQTeoS2djhMgQIAAAQIECPQiMLi/z/bSG/sQIECAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQCAm9iUM0RIECAAAECBAjkJSDw5lUPvSFAgAABAgQIEEgsIPAmBtUcAQIECBAgQIBAXgICb1710BsCBAgQIECAAIHEAgJvYlDNESBAgAABAgQI5CUg8OZVD70hQIAAAQIECBBILCDwJgbVHAECBAgQIECAQF4CAm9e9dAbAgQIECBAgACBxAICb2JQzREgQIAAAQIECOQlIPDmVQ+9IUCAAAECBAgQSCwg8CYG1RwBAgQIECBAgEBeAgJvXvXQGwIECBAgQIAAgcQC/wXwqf2f3QpjtQAAAABJRU5ErkJggg==	\N	2025-10-26 16:36:13.005+00	2025-10-26 16:36:13.005+00
087e3cfb-a4e6-45bb-873e-138b8443582c	bc107c45-36b5-4af5-ae9a-02ffc46c8699	8b790d78-9d4b-4357-a0ba-9e09ee329415	João Manuel Fernandes Longo	represented	maria Lopez	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAAlF0lEQVR4Ae3dXYycVf0H8CndtltKoRRsRSjGippUMAQV4ltiQoBINCZe4J2JUS6ExCsTvNSYGESvTIwXvtxxZTDGBDBovDLeQGNMUHwrURqjFmlrFdtud/XPGf/n6dnZmd2Z2ZlnznPOZ5JmnnnmeTnn83vE75w988yO/7726HkQIECAAAECBAgQKFTgikL7pVsECBAgQIAAAQIE+gICrwuBAAECBAgQIECgaAGBt+jy6hwBAgQIECBAgIDA6xogQIAAAQIECBAoWkDgLbq8OkeAAAECBAgQICDwugYIECBAgAABAgSKFhB4iy6vzhEgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeosurcwQIECBAgAABAgKva4AAAQIECBAgQKBoAYG36PLqHAECBAgQIECAgMDrGiBAgAABAgQIEChaQOAturw6R4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLLq/OESBAgAABAgQICLyuAQIECBAgQIAAgaIFBN6iy6tzBAgQIECAAAECAq9rgAABAgQIECBAoGgBgbfo8uocAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vDpHgAABAgQIECAg8LoGCBAgQIAAAQIEihYQeIsur84RIECAAAECBAgIvK4BAgQIECBAgACBogUE3qLLq3MECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+jy6hwBAgQIECBAgIDA6xogQIAAAQIECBAoWkDgLbq8OkeAAAECBAgQICDwugYIECBAgAABAgSKFhB4iy6vzhEgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeosurcwQIECBAgAABAgKva4AAAQIECBAgQKBoAYG36PLqHAECBAgQIECAgMDrGiBAgAABAgQIEChaQOAturw6R4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLLq/OESBAgAABAgQICLyuAQIECBAgQIAAgaIFBN6iy6tzBAgQIECAAAECAq9rgAABAgQIECBAoGgBgbfo8uocAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vDpHgAABAgQIECAg8LoGCBAgQIAAAQIEihYQeIsur84RIECAAAECBAgIvK4BAgQIECBAgACBogUE3qLLq3MECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+jy6hwBAgQIECBAgIDA6xogQIAAAQIECBAoWkDgLbq8OkeAAAECBAgQICDwugYIECBAgAABAgSKFhB4iy6vzhEgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeosurcwQIECBAgAABAgKva4AAAQIECBAgQKBoAYG36PLqHAECBAgQIECAgMDrGiBAgAABAgQIEChaQOAturw6R4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLLq/OESBAgAABAgQICLyuAQIECBAgQIAAgaIFBN6iy6tzBAgQIECAAAECAq9rgAABAgQIECBAoGgBgbfo8uocAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vDpHgAABAgQIECAg8LoGCBAgQIAAAQIEihYQeIsur84RIECAAAECBAgIvK4BAgQIECBAgACBogUE3qLLq3MECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+jy6hwBAgQIECBAgIDA6xogQIAAAQIECBAoWkDgLbq8OkeAAAECBAgQICDwugYIECBAgAABAgSKFhB4iy6vzhEgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeosurcwQIECBAgAABAgKva4AAAQIECBAgQKBoAYG36PLqHAECBAgQIECAgMDrGiBAgAABAgQIEChaQOAturw6R4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLLq/OESBAgAABAgQICLyuAQIECBAgQIAAgaIFBN6iy6tzBAgQIECAAAECAq9rgAABAgQIECBAoGgBgbfo8uocAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vDpHgAABAgQIECAg8LoGCBAgQIAAAQIEihYQeIsur84RIECAAAECBAgIvK4BAgQIECBAgACBogUE3qLLq3MECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+jy6hwBAgQIECBAgIDA6xogQIAAAQIECBAoWkDgLbq8OkeAAAECBAgQICDwugYIECBAgAABAgSKFhB4iy6vzhEgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeosurcwQI5Cawc+fO3hVXXNHbsWPHun9h3eC/sG34t7S01FteXu7deuutuXVHewgQINAJgR3/fe3RiZZqJAECBDomEMJq+E/sIv4zGwJ1CMorKysdU9NcAgQIzF7ACO/sTR2RAIEKBYaN3P7nP//ZNOzGUd55cIWQfenSpWYUOY4e33zzzfM4nWMSIEAgawGBN+vyaBwBAjkKTBpuY7C99tprmxHfEEhDII6hOI4Ej/N822239fbs2dOf7hCDbDxHeB72iMc9efLkuhAc+vL1r3992C7WESBAoBgBUxqKKaWOECAwL4GDBw/2zpw5M9bhY+A8cOBA7/Tp02PtM8+NJp1WEYPz2traPJvl2AQIEGhVwAhvq9xORoBA1wTCCOqosBvDYTpyG0dtcwi7wToE13QU+emnn26+NDesFnHkOfYtPAeDMB/YgwABAl0VMMLb1cppNwECcxUIIS+Ev/QRwt8111wzMgCn23Zp+W1ve1vv97//fb/Jg30e1o/g4Atxw2SsI0AgVwGBN9fKaBcBAgsRCFMAwoho+ggBb3Bd+n6Jy+E2aPEOD5uF4BptSqy3PhEoXcCUhtIrrH8ECIwlEObpDoa38Dr+iX+sgxS00YULF/ohP50OET4MBJP0EXzCuvAvvO9BgACBHAUE3hyrok0ECLQqMGyebgjAtY3qboW+urraNwkhd9euXRvCb/AKwTd47t69e6vDeZ8AAQKtCZjS0Bq1ExEgkJvAsHm6YZ07FExWqWHTQOIRQgD2wSFqeCZAYFECAu+i5J2XAIGFCQwLaILZbMox7ENEPLIPE1HCMwECbQuY0tC2uPMRILAwAfN0508f5/xuNeVh/i1xBgIECFwWMMJ72cISAQIFCwwbeQwB+JVXXim413l0bdiIemiZEd886qMVBGoQEHhrqLI+EqhYYFjQFbQWd0EMq8ehQ4d6f/vb3xbXKGcmQKB4AVMaii+xDhKoUyCMKoZ5uek9ZONrX0pb3DURpjw8+OCD6xpw6tSp/mjvupVeECBAYIYCRnhniOlQBAjkIRCCbfrwhbRUI5/lYVMdjL7nUx8tIVCSgBHekqqpLwQIbLg3rPvp5ntRhJH2+MMVsZXxXr6HDx+OqzwTIEBg2wIC77YJHYAAgVwE0pHdOH3Bl9Jyqc7odpjmMNrGOwQIzEbAlIbZODoKAQILFkjDrj+LL7gY2zi9aQ7bwLMrAQIjBYzwjqTxBgECXREQdrtSqa3baZrD1ka2IEBgcgGBd3IzexAgkJGAsJtRMWbYFNMcZojpUAQI9ExpcBEQINBZAWG3s6WbqOGD0xxC3UMg9iBAgMC4AgLvuFK2I0AgKwFhN6tytNKYtOZCbyvkTkKgGAFTGooppY4QqEcgDT6+oFZP3dNbmIXlUHsPAgQIjCPgvxbjKNmGAIFsBITdbEqxkIbE+/SGkwu9CymBkxLopIDA28myaTSBOgWE3TrrPthroXdQxGsCBLYSEHi3EvI+AQJZCAi7WZQhm0YIvdmUQkMIdEJA4O1EmTSSQN0Cwm7d9R/Ve6F3lIz1BAgMCgi8gyJeEyCQlYCwm1U5smuM0JtdSTSIQJYCAm+WZdEoAgSCgLDrOhhHQOgdR8k2BOoWEHjrrr/eE8hWQNjNtjRZNkzozbIsGkUgGwGBN5tSaAgBAlFA2I0SnicREHon0bItgboEBN666q23BLIXEHazL1HWDRR6sy6PxhFYmIDAuzB6JyZAYFBA2B0U8XoagRB648OPU0QJzwTqFhB4666/3hPIRkDYzaYURTQkBN34CMs7d+6MLz0TIFChgMBbYdF1mUBuAldccfk/RWF5bW0ttyZqT0YCf/jDH/oB9qqrrtq0VWnoDaO+u3bt2nR7bxIgUK7A5f+XKbePekaAQMYCIeDGYBJGeYXdjIuVQdOOHTvWe8tb3tILAfbVV1/t37ru3e9+98iWxWsrbLC6utrfd+TG3iBAoFgBgbfY0uoYgfwFrr/++ibshtamcy/zb70WtikQRnWXlpZ6L7zwwobTPvfcc/0R3x/+8Icb3gsrXv/61zfrw3E8CBCoT2DHa59+L090qq//ekyAwAIF0nm7/lO0wEJkfuowqpsG3SuvvLI/uvviiy/23vrWt677q8CePXt6Fy5c2NCjEJbTvx643jYQWUGgaAEjvEWXV+cI5CuQztv1haJ867Tolg2O6j7wwAP9sBvadfTo0f40hXvuuadp5sWLF5vldCFMZ0ivufTDVrqdZQIEyhQwwltmXfWKQNYCIeDG6QsheMTlrButca0LXHfddb3Tp0/3zxtHdTdrRAyxDz30UO8b3/jG0E0H54y79oYyWUmgOAEjvMWVVIcI5C3w8Y9/fF3AFTjyrteiWve5z32uCbs33HBDM6o7Tnsef/zxkZuF6y0G4zCtIR31HbmTNwgQ6LyAEd7Ol1AHCHRLIIaN0GrzKLtVuzZbG0did+/e3Rs1TWGwPfEvB+P81SAePxzDdTgo6TWB8gSM8JZXUz0ikK1AOpqWLmfbYA1biMDhw4ebEHr8+PGx2xDvxjBOgE3/suBaHJvYhgQ6KyDwdrZ0Gk6gWwJh9C0GkTACl35jvls90dp5CoSpDKdOneqf4s477+zdeuutY5/uK1/5SrPtuXPnmuVRC/GvDfG6HLWd9QQIdF/AlIbu11APCHRCIIaL0FgBoxMlW0gj41SDSaYypA2N19nb3/723vPPP5++tWE5nOPSpUv99eFX2FZWVjZsYwUBAmUIGOEto456QSBrgRhCQiPDvVM9CAwTuPvuu5sPQ5NMZRh2rN/+9rfDVq9blwbccNsyDwIEyhUwwltubfWMQBYCccQuNCYsm8qQRVmybET40YgQQsP9dU+cODFVG/fu3dv88MQ4f0lIr89xtp+qUXYiQGDhAkZ4F14CDSBQrkD40YAYIsIor7Bbbq2327NHH320mVLw1FNPTX24cO/eSR7pl9f8AMokcrYl0C0BI7zdqpfWEuiUQDqVIQbfTnVAY1sTiD8yEZ7//ve/T33ea6+9tnf27Nn+/uNec67TqbntSKAzAkZ4O1MqDSXQLYE0RIRv23sQGCXw61//uvmRic9//vOjNhtr/auvvjrWdulGYVqDBwECZQsY4S27vnpHYCEC6bzIEHzTPxsvpEFOmrVAuKNCCL3T3pkh7Vz6QWvcEd6wf9zv2LFjvV/96lfpIS0TIFCAgI+1BRRRFwjkJBBu7xSDhrCbU2XybcsLL7zQb9yHP/zhmTUyzB+f5vGb3/xmmt3sQ4BA5gICb+YF0jwCXRNIb+9kZLdr1Wu/vd/85jebD0hPPPHEzBqwb9++qY4VP6xNtbOdCBDIVkDgzbY0GkagewLpXMj9+/d3rwNa3LrATTfd1D9nmM4wy8eRI0cmOlyc0iDwTsRmYwKdERB4O1MqDSWQv0AMCyE8jPPTrvn3SAvbEoiBc1bn+9CHPjSrQzkOAQIFCAi8BRRRFwjkIJCO7prKkENF6mvDs88+23T6sccea5bHWZh14B7nnLYhQKA9AYG3PWtnIlCswMGDB5t5mIJDsWXOvmNf/vKXp26j63ZqOjsS6ISAwNuJMmkkgbwFzpw50zTQ6G5DYaFlgeeee67lMzodAQJdERB4u1Ip7SSQqUD6c6zptIZMm6tZBQu88sorBfdO1wgQ2I6AwLsdPfsSILDuRyXW1taIEJhI4M1vfnN/+xtvvHGi/YZtfPHixWGrrSNAgEBP4HURECAwtUA6oht+cMKDwLQCy8vL0+7a7Ben06TXZfOmBQIEqhYQeKsuv84T2J5AvA1ZOMrKysr2DmbvqgViWJ0FwjT39A230QtfXBOWZ1EBxyCQn8B0v72YXz+0iACBlgXSYPDZz3625bM7XSkCx44d633ve9/rHT16dGZdCncNmfRx5ZVXrpueM+n+tidAIG+BHa+N0Pw37yZqHQECOQrE2ziF51mOzuXYV23qhkC8Ju+///7ek08+2Y1GayUBAq0ImNLQCrOTEChLIB3dFXbLqm0JvfEXhxKqqA8EZisg8M7W09EIFC/wkY98xI9MFF/l7nXwi1/8YtPo++67r1m2QIAAgSBgSoPrgACBiQTin43DTmZETURn4zkK7N27t3fhwoX+GVyXc4R2aAIdFTDC29HCaTaBRQgsLV3+nms6rWERbXFOAqlADLvpOssECBCIAgJvlPBMgMCWAukPS6TLW+5oAwItCbzjHe9o6UxOQ4BAlwRMaehStbSVwAIFwk8Ixy+oheXV1dUFtsapCVwWMJ3hsoUlAgSGCwi8w12sJUBgQMDc3QEQL7MRiNdmeI4fyrJpnIYQIJCFgCkNWZRBIwjkLZDO173xxhvzbqzWVSXw05/+tOnvvffe2yxbIECAQCpghDfVsEyAwFABI2hDWazMQGDXrl3N9Bp3Z8igIJpAIFMBI7yZFkazCOQikI7u+nNxLlXRjigQ55Kn12l8zzMBAgSigMAbJTwTIDBUwKjZUBYrMxBIf2zi4YcfzqBFmkCAQK4CpjTkWhntIpCJQJzOEEbQ3Iosk6JoRl8gvXOID2YuCgIENhMwwruZjvcIVC6Q/plY2K38Ysiw+3GKTfqDKBk2U5MIEMhAQODNoAiaQCBXAaNmuVZGux544IEG4Tvf+U6zbIEAAQLDBExpGKZiHQECfQHTGVwIuQqEvz7ED2TxOde2ahcBAosXMMK7+BpoAYEsBUxnyLIsGvX/AjHk7t69mwkBAgS2FBB4tySyAYE6BWKgqLP3dff6fe97Xy984Akj/OkHn1xU3vve9zZN+ctf/tIsWyBAgMAoAVMaRslYT6ByAdMZ6rsAYs2H9Ty8F78kNuz9NteZztCmtnMRKEPACG8ZddQLAjMVSEf13J1hprTZHiyt+bBGhhH/XEZ8418f9u3bN6yp1hEgQGCDgMC7gcQKAgRioCBRh8DZs2ebL4CFHp84caL/OlwHMehGiUVfG7fccktsSu9f//pXs2yBAAECmwkIvJvpeI9A5QJbjfpVzlNM9w8ePNj0JQTao0ePNq/DQpjK8MlPfnLdukW9CGHcgwABApMKCLyTitmeQOECacg1naHwYr/Wvdtvv70Z3d1sDu93v/vdBuOuu+5qlhe1kIb0RbXBeQkQ6I6AL611p1ZaSqAVgTT0LPrP1610uPKTTFLvuO2uXbt6KysrrcsdPny4d+rUqf55XZut8zshgU4LGOHtdPk0nsD8BNKR3vmdxZEXKbC8vNycfpIvgK2urjb7tbkQw26b53QuAgTKEBB4y6ijXhCYiUAack1nmAlp1ge5ePFi074ufQHsyJEjTbstECBAYBwBgXccJdsQqETAn4krKfRr3Uw/3Hzwgx8cq+NxSsMirpO0vS+99NJY7bURAQIEooA5vFHCMwEC/fusBoYQLozwln1BxPAansf9QYlwXcSwG5/bUApfrPvlL3/ZP9Wi5g+30U/nIEBgfgIC7/xsHZlApwQWFWY6hVRIY/fv39/cw3aS4LqoaySG88A/SXsLKZduECAwAwFTGmaA6BAEShAQJEqo4nh9OH/+/HgbDmyVBs+Bt+b2MoTs+HjkkUfiomcCBAhMJGCEdyIuGxMoVyCGmRAwTGcot86hZ9OO1E6737Sa9913X++ZZ57p775z587eou4OMW377UeAQD4CAm8+tdASAgsTCGEizuM00ruwMrR24mmDa/xQFBraxnXS9vlaK4ATESDQusDlvxW1fmonJEAgF4E2wksufdWOy2E1DZSTuEy73yTnCB/C4uOjH/1oXPRMgACBqQQE3qnY7ESAAIF6BeYdeD/zmc80f3EI5/rBD35QL7aeEyAwEwFTGmbC6CAEui0w7Z+4u93relsfA2t4jlNZxtGI+9199929n/zkJ+PsMtU28TxhZ399mIrQTgQIDAgY4R0A8ZJAjQIxVKRBo0aH2vqcThvYqu/XX399s8k8w264z258vOtd74qLngkQILAtAYF3W3x2JkCAQHcFrr766rEbf/r06bG3nXbDb3/7282dGMKHr2effXbaQ9mPAAEC6wQE3nUcXhAgQKAegbvuuiurzj744INNeyaZatHsZIEAAQIjBATeETBWE6hRwJSG8qt+/PjxppNPPfVUs7zVwrynvSwvLzdNeNOb3tQsWyBAgMAsBATeWSg6BoFCBPbu3VtIT3RjlMBDDz006q2FrX/ppZd6Fy9e7J8/fOh68cUXF9YWJyZAoEwBgbfMuuoVgakEvv/970+1n526I/C73/1uW43dt2/ftvYftvMb3/jGZrWpDA2FBQIEZigg8M4Q06EIdFHgwIEDTbPvvffeZtlCmQLpXRDG7WE6t/af//znuLuNtd1VV13VbPe6172uWbZAgACBWQq4D+8sNR2LQAcF/KxwB4u2jSYfOnSo9/LLL/ePEOflbnW4ed6nOZ03Pm57tmqv9wkQIDAoYIR3UMRrApUJCBmVFXyK7sZrJA2nUxxmwy7p8eI5NmxkBQECBGYgIPDOANEhCBAgUKpAGN2Nj1nOr73uuuviYXv79+9vli0QIEBgHgKX/0s2j6M7JgECBAh0VuDHP/5x89O+6WjsLDqU/pDFuXPnZnFIxyBAgMBIAXN4R9J4g0AdAjHIhOdZjuDVode9Xk4yh3dec3fnddzuVUOLCRBoS8AIb1vSzkOAAIEOCXzgAx+Yy+juzTff3Bw3/bGJDtFoKgECHRQQeDtYNE0mQIDAvAV+9rOfNaeY1cj/008/3Tt58mRz3PPnzzfLFggQIDBPgaV5HtyxCRDojkCc2tCdFmvpvATSL5SlX1rbzvnC/X9XV1ebQzzxxBPNsgUCBAjMW8AI77yFHZ9ARwT8rHBHCtVCM9MvlK2trW3rjGFUN3yYSsPu4cOHex/72Me2dVw7EyBAYBIBI7yTaNmWQMECP/rRjwruna6NK7B79+5m06Wl7f1fxOCori9GNrQWCBBoWcAIb8vgTkcgJ4H0Z4Xf//7359Q0bZmTQDp15Z3vfOeGs1y6dKlZly43K8dYGDWqO6u5wGM0wSYECBBYJ+C2ZOs4vCBQl0AYwYt/svZLV/XUPg29ad3Tn5m+5ppremfPnp0YxajuxGR2IECgBQEjvC0gOwWBXAVuuOGGXJumXXMUCLcGi4/01mDpCOykYdeobhT1TIBAjgICb45V0SYCLQmkt4j6whe+0NJZnWbRAn/605+aJly8eLG/nN6N4Y477mjeH2chjOref//9zaZhBDmMHP/1r39t1lkgQIDAIgUE3kXqOzeBjAQee+yxjFqjKfMWePzxx5tTpL98FsLq8ePHm/c2WzCqu5mO9wgQyEnAHN6cqqEtBBYgEOdzhtAT5/MuoBlOuQCBNOjG03/rW9/qffrTn44vRz6bqzuSxhsECGQoIPBmWBRNItCmQAy84Tmdw9lmG5xrcQKx/ttpQbivrukL2xG0LwEC8xbY3k0W5906xydAgACBbAV8SMq2NBpGgMCAgDm8AyBeEiBAoBaB9Itqoc8hwI77L/z8sL8I1HKl6CeB7gsY4e1+DfWAwLYEQsAJ36hP78e6rQPauRMChw4dampupLYTJdNIAgS2IWAO7zbw7EqgBIH0i0tCbwkVHa8PIeTGh7pHCc8ECJQqYEpDqZXVLwIECIwQSMPuTTfdNGIrqwkQIFCOgBHecmqpJwSmEkh/TtZI31SEndopHdE3laFTpdNYAgS2IWCEdxt4diVQgkC4n6pHHQLm7dZRZ70kQGCjgMC70cQaAlUJfOpTn6qqvzV39uWXX2667w4LDYUFAgQqEDCloYIi6yKBrQTinM6jR4/2Tpw4sdXm3u+gQKxxaHqYt3vy5MkO9kKTCRAgMJ2AwDudm70IFCUQw1CYz7u6ulpU33Sm1zNv11VAgEDtAqY01H4F6D+BRMCX1hKMQhbDz/7GuvqSWiFF1Q0CBCYWMMI7MZkdCJQnEEd4BaJyaxt6FoNveb3UIwIECGwuYIR3cx/vEiBAoLMC8YNM6ID77Xa2jBpOgMAMBIzwzgDRIQh0XSANRkYBu17N/7XfvN0y6qgXBAjMRsAI72wcHYVApwXSwNvpjmh8X8C8XRcCAQIE1gsY4V3v4RWBKgXS0UAjvN2/BNIPMOrZ/XrqAQEC2xcwwrt9Q0cg0HmBNCB1vjOVdyCt5ZEjRyrX0H0CBAj8T8AIryuBAIHe0tJSb21trS9x9dVX9/7xj39Q6aBAOlIfgq9fU+tgETWZAIG5CBjhnQurgxLolkD6YxPnzp3rVuO1ti9g3q4LgQABAqMFjPCOtvEOgaoEwq+sxRHBMFIYR3yrQuhwZ9OpDObtdriQmk6AwFwEjPDOhdVBCXRPIA24Mfh2rxd1tjgNu+bt1nkN6DUBApsLGOHd3Me7BKoSOHDgQDN/1xzQbpQ+DbtG5rtRM60kQKB9AYG3fXNnJJC1QPrFJ38az7pUPWE37/poHQEC+QiY0pBPLbSEQBYCP//5z5t2hPDrkaeAsJtnXbSKAIE8BYzw5lkXrSKwUAGjvAvl3/Lkwu6WRDYgQIDAOgHDN+s4vCBAIAikX1ozypvXNSHs5lUPrSFAoBsCAm836qSVBFoXiMEqzOO98847Wz+/E24UiDUJ74QPIumdNTZubQ0BAgQIRAFTGqKEZwIENgikAcsX2DbwtLoirYWw2yq9kxEgUICAEd4CiqgLBOYlkE5nCD8/7LEYAWF3Me7OSoBAOQJGeMuppZ4QmItAGraM8s6FeNODpv5Gdjel8iYBAgRGChjhHUnjDQIEgkD4yeH4SJfjOs/zExB252fryAQI1CVghLeueustgakE0uBllHcqwol3Ss2N7E7MZwcCBAisEzDCu47DCwIEhgm85z3vaVan83qblRZmKiDszpTTwQgQINAzwusiIEBgLIEQdOPobnwea0cbTSQg7E7EZWMCBAiMJWCEdywmGxEg4Mco5n8NCLvzN3YGAgTqFBB466y7XhOYSiAGsjDC++STT051DDsNF4i24V1zdocbWUuAAIFpBUxpmFbOfgQqFUiDmakNs7kIUlNhdzamjkKAAIFUwAhvqmGZAIEtBdJwFpbdqmxLsk03SD2F3U2pvEmAAIGpBQTeqensSKBOgTCXNw1p8fUdd9xRJ8iUvd6zZ886R2F3Ski7ESBAYAwBgXcMJJsQILBeIITcRx99dN3KX/ziF/25p+tWerFBIIyIhw8MKysrzXvCbkNhgQABAnMRMId3LqwOSqAegRDg0js4hJ4LcBvrH0yGzXlmtdHKGgIECMxawAjvrEUdj0BlAmtra/0gZ5rD8MKHQBtsBsPu3r17++uCnwcBAgQIzFdA4J2vr6MTqEbANIfLpX7kkUf6o9yDQTe8vueee/pB99///vflHSwRIECAwFwFTGmYK6+DE6hToNZpDgcPHuydOXNmQ9FD0B2c9rFhIysIECBAYG4CRnjnRuvABOoVqG2aQ/wi2mDYjSO8wm69/1vQcwIE8hAQePOog1YQKFJg1DSHEARDSOz6I87PHQy08Qtqg+u73l/tJ0CAQFcFTGnoauW0m0DHBIZNc4hdCAE4/OvKF7hioI3tj89LS0u9S5cuxZeeCRAgQCATASO8mRRCMwiULjBsmkPsc7iDQRgNjcE3BMpwF4PcHnFEd/COC294wxv6X0QTdnOrmPYQIEDgfwICryuBAIFWBUKwDYEx/FteXu6H3MEGhPcuXLiwLgDfcsstg5u18vq2224beceFZ555pt+PP//5z620xUkIECBAYDoBgXc6N3sRIDADgfPnz/dHdmMAjiOog4cO7584cWJdAP7a1742uNnI11/96ld7t99+e+/AgQO93bt39+cPhykW4XzD/sWR5vD8/PPP90NtPHhYF9oTgnu4xZgHAQIECOQvYA5v/jXSQgLVCoRQGsPwohFC0PUltEVXwfkJECAwnYAR3unc7EWAQAsCYd5vnALxpS99aej0h3k0Ix3hDSPAcUR3HudyTAIECBCYv4AR3vkbOwMBAnMQOHr0aO+Pf/zjuiOHoBoeYWR4//79vTDv9+GHH+594hOfWLedFwQIECBQl4DAW1e99ZYAAQIECBAgUJ2AKQ3VlVyHCRAgQIAAAQJ1CQi8ddVbbwkQIECAAAEC1QkIvNWVXIcJECBAgAABAnUJCLx11VtvCRAgQIAAAQLVCQi81ZVchwkQIECAAAECdQkIvHXVW28JECBAgAABAtUJCLzVlVyHCRAgQIAAAQJ1CQi8ddVbbwkQIECAAAEC1QkIvNWVXIcJECBAgAABAnUJCLx11VtvCRAgQIAAAQLVCQi81ZVchwkQIECAAAECdQkIvHXVW28JECBAgAABAtUJCLzVlVyHCRAgQIAAAQJ1CQi8ddVbbwkQIECAAAEC1QkIvNWVXIcJECBAgAABAnUJCLx11VtvCRAgQIAAAQLVCQi81ZVchwkQIECAAAECdQn8H3PkxiIF+arlAAAAAElFTkSuQmCC	\N	2025-10-26 16:36:13.005+00	2025-10-26 16:36:13.005+00
d119e8af-9c48-4ec0-8df0-c0252f800686	bc107c45-36b5-4af5-ae9a-02ffc46c8699	d3ad84ae-c456-4ba7-9300-a78884804e9d	Vítor Manuel Sebastian Rodrigues	present	\N	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAEsCAYAAAAhNGCdAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAACvKADAAQAAAABAAABLAAAAACfOw0QAAAjDklEQVR4Ae3dT4gkZ/kH8EqyMzvZzRqT+IdEEoMxguCKuCIogn9QPAheFP9EEe+KQjwoehFFvSgeVfTgSQRPevAgi6IiBD0ZMEiMIJIFBTWixsSdmeS3z+T31r4zNT3T3VXVVfXWZ2Dt2uruqvf5PBX322+/3XPDs9d+Kj8ECBAgQIAAAQIEChW4sdC6lEWAAAECBAgQIEDgQEDgdSEQIECAAAECBAgULSDwFt1exREgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeoturOAIECBAgQIAAAYHXNUCAAAECBAgQIFC0gMBbdHsVR4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLbq/iCBAgQIAAAQIEBF7XAAECBAgQIECAQNECAm/R7VUcAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vYojQIAAAQIECBAQeF0DBAgQIECAAAECRQsIvEW3V3EECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+j2Ko4AAQIECBAgQEDgdQ0QIECAAAECBAgULSDwFt1exREgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeoturOAIECBAgQIAAAYHXNUCAAAECBAgQIFC0gMBbdHsVR4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLbq/iCBAgQIAAAQIEBF7XAAECBAgQIECAQNECAm/R7VUcAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vYojQIAAAQIECBAQeF0DBAgQIECAAAECRQsIvEW3V3EECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+j2Ko4AAQIECBAgQEDgdQ0QIECAAAECBAgULSDwFt1exREgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeoturOAIECBAgQIAAAYHXNUCAAAECBAgQIFC0gMBbdHsVR4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLbq/iCBAgQIAAAQIEBF7XAAECBAgQIECAQNECAm/R7VUcAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vYojQIAAAQIECBAQeF0DBAgQIECAAAECRQsIvEW3V3EECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+j2Ko4AAQIECBAgQEDgdQ0QIECAAAECBAgULSDwFt1exREgQIAAAQIECAi8rgECBAgQIECAAIGiBQTeoturOAIECBAgQIAAAYHXNUCAAAECBAgQIFC0gMBbdHsVR4AAAQIECBAgIPC6BggQIECAAAECBIoWEHiLbq/iCBAgQIAAAQIEBF7XAAECBAgQIECAQNECAm/R7VUcAQIECBAgQICAwOsaIECAAAECBAgQKFpA4C26vYojQIAAAQIECBAQeF0DBAgQIECAAAECRQsIvEW3V3EECBAgQIAAAQICr2uAAAECBAgQIECgaAGBt+j2Ko4AAQIECBAgQEDgdQ0QIECAAAECBAgULSDwFt1exREgQIAAAQIECAi8rgECBAgQIECAAIGiBc4UXZ3iCBAgMCOBm266qXrmmWc6qfiGG27o7FidDMhBCBAg0ELADG8LPE8lQIDA0AK//e1vqxtvvLHqOqA+++yz1c7OztDlOT8BAgQ6Ebjh2v+pPdvJkRyEAAECBDYmsLW1Ve3t7R17vgi/bX7yfxby7TbH9FwCBAgMKWCGd0h95yZAgMCKAhF0I9AeDbux713velcVATWWNbT5kwfm2D5zxuq3Fdvk4QQIjEzADO/IGmI4BAgQOE5g0YxuLGfY398/7imt9sVxj87uRvjtao1wq8F5MgECBFYUMMO7IpiHEyBAYJMC3//+94+d0U2BtI+wG/VFsM1nemNfBOA4rx8CBAhMTcD/c02tY8ZLgMBsBOJbFz74wQ8eqrfvoJufLEJvhNyPfexj9W6ht6awQYDAhAQsaZhQswyVAIH5CKRgmyqOv/c1m5vOcdptPibLG07Tcj8BAmMSMMM7pm4YCwECsxeID4hFmMzXz8b20GE3GpOv340xxbpiPwQIEJiCgBneKXTJGAkQmIVAPoMaBY91FjVf25sH81k0SZEECExSwAzvJNtm0AQIlCZwdFY3Zk/zGdUx1Xv27Nl6OHn4rXfaIECAwMgEBN6RNcRwCBCYl8C5c+cOfRtCCr5Xr14dLcTTTz996NsaYmbaDwECBMYs4P+lxtwdYyNAoGiB+BaGp556qq4xguNYZ3XrQf7/RqwpTrO7sazhIx/5yNGH+DsBAgRGI2AN72haYSAECMxJ4Oh63fiw2u7u7uQIUuiN26mE9ckhGzABAq0F/L7I1oQOQIAAgdUEjobdKX/wKy3BmHINq3XPowkQmKKAJQ1T7JoxEyAwWYEUEFMBUw+K+ayutbypq24JEBibgMA7to4YDwECxQqkt/+jwKPBd8pFp7qmHt6n3ANjJ0DgZAGB92Qf9xIgQKC1wMWLF+sPeMXBIiDmM6OtTzDwAWL9cfrJt9M+twQIEBhawIfWhu6A8xMgULRAfJ/u3t5eXWO87T+G35pWD6ijjTTLG4cz09sRqsMQINCZgBnezigdiAABAocF4mvH8rAbfy8x7EbV1u8e7r2/ESAwLgGBd1z9MBoCBAoRiACYL1u48847D4XfQsqsy8iDvPBbs9ggQGAkAtcXXo1kQIZBgACBqQtE4Mvf1s+3p17bSeNPH8SbS70nWbiPAIFxCZjhHVc/jIYAgYkLzDXsRttiyUb6ufnmm9OmWwIECAwu4ENrg7fAAAgQKEUg/+BWad/EsGyPksFc61/WyeMIENisgBnezXo7GwEChQqkoBflzTnsJQfLGgq90JVFYKICAu9EG2fYBAiMRyCFvBjRnMNu1H/ffffFzcGP7+RNEm4JEBhawJKGoTvg/AQITFpA2G22L5nMPfw3ZewhQGAoATO8Q8k7LwECkxdIwS4KOfo1ZJMvrkUBycWyhhaInkqAQKcCAm+nnA5GgMBcBFKoi3oj7ObfQzsXg0V15t8/nH9zw6LH20+AAIG+BQTevoUdnwCB4gSE3eVbmoff5Z/lkQQIEOhWQODt1tPRCBAoXEDYXa7BMevthwABAmMR8P9IY+mEcRAgMHoBYXf5FuVLPCxrWN7NIwkQ6EdA4O3H1VEJEChMQNhdv6E+vLa+nWcSINCNgMDbjaOjECBQsICwu15zk5vAu56fZxEg0J2AwNudpSMRIFCgQAptUZpvY1itwbfcckv9hJ2dnXrbBgECBDYt4BdPbFrc+QgQmIxABNw0OxnB1zcOrN669IKB3+p2nkGAQHcCZni7s3QkAgQKEogPWgm77RuaAm+ybH9ERyBAgMDqAgLv6maeQYBA4QK33377odlcM7vrNzwF3vWP4JkECBBoL2BJQ3tDRyBAoDCBPKSZmWzf3ORpDXR7S0cgQGA9ATO867l5FgEChQqkcBblnTlzptAqhynLi4dh3J2VAIFrHzqGQIAAAQLPCeS/HSyC7+7uLpoOBNKLCIG3A0yHIEBgLQGBdy02TyJAoDQBH1Lrr6MXLlyoD+7ryWoKGwQIbFDAGt4NYjsVAQLjFIgPqT3xxBP14MxE1hSdbaRZ3rj1IcDOWB2IAIElBQTeJaE8jACBcgVSGIsKhd1++px/pzHjfowdlQCBxQKWNCy2cQ8BAjMQyMNuLGvw049A7tzPGRyVAAECiwXM8C62cQ8BAoUL5CHMV2b13+zkHbeWNfTv7QwECFwXMMN73cIWAQIzEkjhK0oWdjfT+GRuScNmvJ2FAIHrAgLvdQtbBAjMRCAFryhX2N1c08M6/bz4xS9Om24JECDQu4AlDb0TOwEBAmMSEHaH7Ubyj1vLGobthbMTmJPA9Zfbc6parQQIzFIgha0o3szuMJdA6oFlDcP4OyuBuQoIvHPtvLoJzEwgBa0oW9gdrvnb29v1ybe2tuptGwQIEOhTwJKGPnUdmwCBUQgIu6NoQz2I1I+4tayhZrFBgECPAmZ4e8R1aAIEhhdI4SpGYmZ3+H7ECFJPLGsYRz+MgsAcBATeOXRZjQRmKpB/K4CwO56LIJ/V9cs+xtMXIyFQsoDAW3J31UZgxgIRcNMMYswo7u/vz1hjvKXn4Xe8ozQyAgSmLiDwTr2Dxk+AQEPgZS97WR12406hqkE0+I60rGHwgRgAAQKzEPChtVm0WZEE5iWQh6k0yzsvgWlUm/pkuck0+mWUBKYsYIZ3yt0zdgIEGgL5ul3rQxs8o9xhBn6UbTEoAkUJCLxFtVMxBOYtEAE3zejG7OHe3t68QUZeff7iZORDNTwCBCYuYEnDxBto+AQIXBdIb5HHnhR8r99ra4wCqWeWNYyxO8ZEoBwBM7zl9FIlBGYtkIJTIPz4xz+etcUUi/cCZYpdM2YC0xEwwzudXhkpAQILBGJ2MAUmM4ULkEa6O+9d6uFIh2pYBAhMWMAM74SbZ+gECFTV1tZWHXZjltf37U7rqojA64cAAQJ9C5jh7VvY8QkQ6FUgX8pghrBX6t4Onnpodr43YgcmMHsBL61nfwkAIDBdgXx28Ny5c9MtxMgPBLxgcSEQINCXgMDbl6zjEiDQq8D9999/aCnDk08+2ev5HLw/gTTDK/D2Z+zIBOYuIPDO/QpQP4GJCjz22GP1yP3igppikhuxDjv9vPnNb06bbgkQINCZgDW8nVE6EAECmxKIXzCRQq51n5tS7/c8aZY3blNv+z2joxMgMCcBgXdO3VYrgUIEUjiKcrwNXkZT9bSMPqqCwFgFLGkYa2eMiwCBYwXyD6rdeuutxz7GzukJ5IF3eqM3YgIExi4g8I69Q8ZHgMAhgTSjGwHpn//856H7/GW6ApcuXaoHf/bs2XrbBgECBLoQsKShC0XHIEBgIwIxu5sCb7rdyImdZCMCaZY3bq3j3Qi5kxCYjYAZ3tm0WqEEpi1w9DeqTbsaoz9OIAVeL2aO07GPAIE2AgJvGz3PJUBgYwJ7e3v1ucz+1RRFbaTAW1RRiiFAYBQCAu8o2mAQBAicJJB/UC2+ksxPmQL7+/t1YWfOnKm3bRAgQKCtgMDbVtDzCRDoXSB/izuf6e39xE4wmIBZ/MHonZhAkQICb5FtVRSBcgTy2d08+JZToUpygbSsQa9zFdsECLQVEHjbCno+AQK9CcTb2in4pCDU28kceBQC+jyKNhgEgeIEfC1ZcS1VEIFyBPLwk4JvOdWpZJFA6nvM7ufrehc93n4CBAicJmCG9zQh9xMgMIhAvpTBB5gGacHgJ7WOd/AWGACBYgQE3mJaqRAC5Qi89KUvPbSUYXd3t5ziVHKqQP5i59QHewABAgSWELCkYQkkDyFAYLMC6S3tOKulDJu1H8vZ0jVgWcNYOmIcBKYtYIZ32v0zegLFCeSze/l2cYUqaCkByxqWYvIgAgROERB4TwFyNwECmxVIM7oxw+cDS5u1H9PZ0gzvmMZkLAQITFdA4J1u74ycQHECecgxs1dce1cqKO+/Dy2uROfBBAgcIyDwHoNiFwECmxfIf2VwHnw3PxJnHJtAHn7HNjbjIUBgGgIC7zT6ZJQEihfIQ02+XXzhClwokF74pGUuCx/oDgIECJwiIPCeAuRuAgT6F8g/nPae97yn/xM6wyQEbrvttnqc29vb9bYNAgQIrCrga8lWFfN4AgQ6F0gzeXFrdrdz3kkf0LUx6fYZPIHRCJjhHU0rDITAPAXy2V1hd57XwElVp8BrWcNJSu4jQOA0AYH3NCH3EyDQq0AKMinY9HoyB5+cQP4NDefPn5/c+A2YAIFxCFjSMI4+GAWBWQrE7G4KvOl2lhCKPlEgvRiKW+8CnEjlTgIEFgiY4V0AYzcBAv0LpJCbAk3/Z3SGKQqk6yNdL1OswZgJEBhWQOAd1t/ZCcxWwNrd2bZ+5cLza2XlJ3sCAQIErgkIvC4DAgQGEUizdWn2bpBBOOkkBPb29upxCr81hQ0CBFYQEHhXwPJQAgS6EchDizWZ3ZiWfpT0wii9UCq9XvURINCtgMDbraejESCwhEAKLSnELPEUD5m5gGtl5heA8gm0FBB4WwJ6OgECqwmY3V3Ny6OfE9jf368p8muo3mmDAAECJwgIvCfguIsAge4FzO52bzqXI6ZZ3nQNzaVudRIg0F5A4G1v6AgECCwpkM/MWbu7JJqH1QJnz56tt/NfSFHvtEGAAIEFAn7xxAIYuwkQ6F4gzdDFrcDbve8cjpiuoajVTO8cOq5GAt0ImOHtxtFRCBA4RWBra6t+RD5TV++0QWAJgTzwLvFwDyFAgMCBgBleFwIBAhsRiOUMaUYu3W7kxE5SnEAKvd4pKK61CiLQm4AZ3t5oHZgAgVwghdwUVvL7bBNYRSBdQ+maWuW5HkuAwDwFBN559l3VBDYq4MNqG+Uu/mQ33XRTXeP29na9bYMAAQKLBCxpWCRjPwECnQmkGTlvQXdGOvsDuaZmfwkAILCSgBnelbg8mACBVQV8WG1VMY9fRiAFXssaltHyGAIEzPC6BggQ6FXAh9V65Z31wVPo9c7BrC8DxRNYSsAM71JMHkSAwLoCaQYuhZN1j+N5BBYJpGts0f32EyBAQOB1DRAg0JuAD6v1RuvA1wTyD69duHCBCQECBBYKWNKwkMYdBAi0EYi1u3t7eweH8JZzG0nPPUkgvXPgGjtJyX0ECAi8rgECBHoRSEEkDu4t516IHfSagDXiLgMCBJYRsKRhGSWPIUBgJYF8KUP+tvNKB/FgAksIXL58uX6Ua62msEGAwBEBgfcIiL8SINBOIAJImtGNWd60rKHdUT2bwPECb3vb2+o7nnnmmXrbBgECBHIBSxpyDdsECLQWsJShNaEDrCgQM7sp7KYXWysewsMJEChcwAxv4Q1WHoFNCuRvKefLGjY5Buean8D+/n5dtOuuprBBgEAmIPBmGDYJEGgnkGbZ4ih5CGl3VM8mcLpAemfBDO/pVh5BYI4CAu8cu65mAj0I5DNrn/nMZ3o4g0MSWCxw5syZ+s7t7e1628a8Bf785z9Xn/jEJ6pvf/vb84ZQfWUNr4uAAIHWAr5ztzWhA3QgkGZ54zZ/t6GDQzvEEYH3ve991S9+8YvqiSeeqHZ3dw/u3dTset7nOHH8PV5wx5KqeLGzs7NT3XrrrdVf//rX6l//+tfB2C5evFg9/PDDB9v+Z54CAu88+65qAp0KpH+A4qCb+kev0wIcrAiBCD3p+ku3RRQ2UBFveMMbql//+teTf/HwwAMPVA8++GB16dKlgSSddgwC198DGsNojIEAgckJ5EsZ8g+tTa4QA568QMzqphdfcS1aR75aS1/wghdU//jHP+oXDas9+7mZ1nhO6sFJz8//fyM97rh9afY2PSb6Gn9iCUu8sxQ/aVb3/Pnz1S233FLdfvvt1R133HEw6/uWt7yl+tCHPpSe7nbGAgLvjJuvdAJtBX7605/W/zjGP0y+c7etqOd3JWBJw8mS3/rWtw7WtsZyhGVmwyOMPu95z6te/epXV1//+ter1772tSefwL0ERiZgScPIGmI4BKYkkM/kLPOP5pRqM9ZpCsTsXwq7rsnrPbz77rurK1euLBVu47/rF73oRdVf/vKX6wewRWDiAr6lYeINNHwCQwlEsEg/x70Vme5zS2CTAvkyhrlel29605sO3vaP4Jr+PP744wvDbji99a1vPbg/XiTECwZhd5NXrXNtQkDg3YSycxAoUCDNokVpecgosFQlTUwgvfMwhxnez372swdrWCO0pnD7q1/9qp7lPtq6eEysff3BD35QB9z47zeWJ/khULKANbwld1dtBHoSyGfOPve5z/V0FoclsJ5AfKApfVVWfKDp6tWr6x1oZM/697//Xb3kJS+p/vOf/yycrT065Ai4r3/966uHHnro6F3+TmBWAtbwzqrdiiXQjUCaQYvbfKa3m6M7CoH2AiVco6961auqRx55ZKVwe+eddx6s1W0v6AgEyhIww1tWP1VDoHeBfHZX2O2d2wnWFIjAG0saprSs4cKFC9WTTz651JijvnPnzlWPPvpoddddd62p5GkE5iNgDe98eq1SAp0IpACRZtA6OaiDEOhYIH8xln/AsuPTrH24r371qwffJZuvvV20VCH+W4tlGp/61KfqEB/1xeOF3bVb4IkzEzDDO7OGK5dAGwGzu230PHcogTz8DjWGVZYnRMCNX40bv7bXDwEC3QgIvN04OgqBWQiY3Z1Fm4spMl6gDRV2V12eEL/29je/+U0x9gohMDYBSxrG1hHjITBSAbO7I22MYS0UyL8uL79+Fz5hzTu+9rWvrbw84bvf/e6h5QnC7pr4nkZgSQEzvEtCeRiBOQvEGkizu3O+AqZfe7p+21YSv5Dhvvvuq5566qn6v4mTjml5wkk67iOwOQEzvJuzdiYCkxXI3xbOtydbkIHPRqDNzO4XvvCFxi91iK/9+u9//7sw7EbAjeUJEbDjT/z3Yi3ubC43hY5YwAzviJtjaATGIJAHhviVpX4ITEkgljVECI2fuJYXvWB75zvfWV2+fLkOqsvUGMeNY37nO9+pPvrRjy7zFI8hQGAgAb94YiB4pyUwBYFYypACQvzjnranMHZjJJAEUuCNv8es6yte8YrqscceO7h72aUOcYz4arBPf/rT1Re/+MV0aLcECExEwAzvRBplmASGEMgDbr49xFick8A6Ai984QsPPS0Pv4fuyP4Sj9nZ2al+//vfV/fcc092j00CBKYqYA3vVDtn3AR6FrCUoWdgh+9U4Mtf/nK1tbV1sMQgAmv687e//e3E88Tj7rjjjnopQ1p3G+t0hd0T6dxJYFICljRMql0GS2BzAhEE0s+yb/umx7sl0KfA3XffXV25cuXgFOtcm+s8p896HJsAgf4FzPD2b+wMBCYtkM/0TroQg5+cQMzabm9vN2ZtH3/88XpG9rii4sVaXLdvf/vb68e5jo+Tso/AfATM8M6n1yolsLRAhIM0C5Zul36yBxJYQ2DdWdsIt7He9pFHHqnuvffeE8+c3rWIW2vST6RyJ4HiBMzwFtdSBRFoLyDktjd0hOMFvvKVr6w9axtB9TWveU09axvXaQTXWG97WtiN0aTA6/o+vjf2EihZwLc0lNxdtRFoKeBt4JaAM39621nbhx9+uHr5y1/emWL8hrT0dWTxlXv5rx7u7CQORIDAKAXM8I6yLQZFYDiBNAsWIxAIhuvDVM788Y9/vLr55psP1szGC6S4ftKfZdbaxmMXzdp2GXbD8w9/+EPNaklDTWGDwCwEzPDOos2KJLCcQHyxfv4TayOffvrpfJftGQq88pWvPAiLERLXXQ4QwTaup65nbVdtR4RyYXdVNY8nMH0BM7zT76EKCPQm8L///e9gti5CwoMPPtjbeRx4WIEf/ehH1fOf//xjZ2kjqMYvYIjZ/mXCbprd3dSs7apy+bsWluysqufxBKYr4Fsapts7IyfQi0AKAYvCTax93Nvb6+XcDtqfwDve8Y7q5z//ed27Rf1dZgQp1N577VsR/vjHPy7zlFE9Jq7xVH+6HdUADYYAgc4FzPB2TuqABKYtEG/3preuf/jDH9afbE9VxQxZBJ4UjNN+t8ML3HXXXQtnaS9fvlzt7u7W33Bw0mhToI3vwP3whz9cPyfCYfyJ6yOugymG3aj7/vvvr8uPF3B+CBAoX8AMb/k9ViGBTgQiGCxa+xgBKf3Er3d94xvfWP3sZz9Lu9yuIfCBD3yg+uUvf1n9/e9/r4Nqfpi2M5OpZ/FrdR999NHqtttuyw9f/HaqPwpta1k8lgIJFCAg8BbQRCUQ2KTAxYsXq9/97ndrhYQUMuLDce9973ur733ve5sc+sbO9c1vfrP6xje+Uf3pT386+I7YfN1oDGITAStZx0z86173uuqhhx7aWP1TOFH+Am4T/ZiCiTESKFlA4C25u2oj0LNAWtYgMPQMfczhU6CNu86dO1d96Utfqj75yU8e80i7Fgkkw7iOj74oWfQc+wkQmKbA4e8gmmYNRk2AwEACi5Y4xHDe/e53Vz/5yU+qq1ev1qMTjJ+jSEErwcTfY9Y7vinh0qVLVcwQ33PPPelutz0LuC57BnZ4AiMQMMM7giYYAoG5CkSou3Llykbe4u/TOAJr/PKF+M1i73//+6vPf/7zfZ7OsTsSiJndFHbTbUeHdhgCBEYmIPCOrCGGQ4AAAQKbETh//vzBGus429mzZ/2Slc2wOwuBQQQE3kHYnZQAAQIExiCQlpfE7UlLdMYwVmMgQGB9Ad/Du76dZxIgQIDAxAVS4LWkYeKNNHwCpwgIvKcAuZsAAQIEyhVIgTcq3NnZKbdQlRGYuYAlDTO/AJRPgACBuQvkoddM79yvBvWXKmCGt9TOqosAAQIElhLIA69Z3qXIPIjA5ATM8E6uZQZMgAABAl0L5KHXLG/Xuo5HYHgBM7zD98AICBAgQGBggTzwxnb8Sb9JcOChOT0BAh0ICLwdIDoEAQIECExb4Lhwa6Z32j01egK5gF8tnGvYJkCAAIFZCuzt7TVmdPNZ31miKJpAQQLW8BbUTKUQIECAAAECBAg0BSxpaJrYQ4AAAQIECBAgUJCAwFtQM5VCgAABAgQIECDQFBB4myb2ECBAgAABAgQIFCQg8BbUTKUQIECAAAECBAg0BQTepok9BAgQIECAAAECBQkIvAU1UykECBAgQIAAAQJNAYG3aWIPAQIECBAgQIBAQQICb0HNVAoBAgQIECBAgEBTQOBtmthDgAABAgQIECBQkIDAW1AzlUKAAAECBAgQINAUEHibJvYQIECAAAECBAgUJCDwFtRMpRAgQIAAAQIECDQFBN6miT0ECBAgQIAAAQIFCQi8BTVTKQQIECBAgAABAk0BgbdpYg8BAgQIECBAgEBBAgJvQc1UCgECBAgQIECAQFNA4G2a2EOAAAECBAgQIFCQgMBbUDOVQoAAAQIECBAg0BQQeJsm9hAgQIAAAQIECBQkIPAW1EylECBAgAABAgQINAUE3qaJPQQIECBAgAABAgUJCLwFNVMpBAgQIECAAAECTQGBt2liDwECBAgQIECAQEECAm9BzVQKAQIECBAgQIBAU0DgbZrYQ4AAAQIECBAgUJCAwFtQM5VCgAABAgQIECDQFBB4myb2ECBAgAABAgQIFCQg8BbUTKUQIECAAAECBAg0BQTepok9BAgQIECAAAECBQkIvAU1UykECBAgQIAAAQJNAYG3aWIPAQIECBAgQIBAQQICb0HNVAoBAgQIECBAgEBTQOBtmthDgAABAgQIECBQkIDAW1AzlUKAAAECBAgQINAUEHibJvYQIECAAAECBAgUJCDwFtRMpRAgQIAAAQIECDQFBN6miT0ECBAgQIAAAQIFCQi8BTVTKQQIECBAgAABAk0BgbdpYg8BAgQIECBAgEBBAgJvQc1UCgECBAgQIECAQFNA4G2a2EOAAAECBAgQIFCQgMBbUDOVQoAAAQIECBAg0BQQeJsm9hAgQIAAAQIECBQkIPAW1EylECBAgAABAgQINAUE3qaJPQQIECBAgAABAgUJCLwFNVMpBAgQIECAAAECTQGBt2liDwECBAgQIECAQEECAm9BzVQKAQIECBAgQIBAU0DgbZrYQ4AAAQIECBAgUJCAwFtQM5VCgAABAgQIECDQFBB4myb2ECBAgAABAgQIFCQg8BbUTKUQIECAAAECBAg0BQTepok9BAgQIECAAAECBQkIvAU1UykECBAgQIAAAQJNAYG3aWIPAQIECBAgQIBAQQICb0HNVAoBAgQIECBAgEBTQOBtmthDgAABAgQIECBQkIDAW1AzlUKAAAECBAgQINAUEHibJvYQIECAAAECBAgUJCDwFtRMpRAgQIAAAQIECDQFBN6miT0ECBAgQIAAAQIFCQi8BTVTKQQIECBAgAABAk0BgbdpYg8BAgQIECBAgEBBAgJvQc1UCgECBAgQIECAQFNA4G2a2EOAAAECBAgQIFCQgMBbUDOVQoAAAQIECBAg0BQQeJsm9hAgQIAAAQIECBQk8H//BA4SYIEPBAAAAABJRU5ErkJggg==	\N	2025-10-26 16:36:13.005+00	2025-10-26 16:36:13.005+00
\.


--
-- Data for Name: buildings; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.buildings (id, name, address, postal_code, city, number_of_units, administrator, admin_contact, admin_email, iban, bank, account_number, swift, phone, email, president_name, president_email, secretary_name, secretary_email, administrator_name, administrator_email, notes, registration_number, construction_year, total_units, legal_framework, statutes, internal_rules, created_at, updated_at) FROM stdin;
fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Condomino Buraca 1	Estrada da Circunvalação, nº 1	2610-000	Amadora	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-02 00:49:09.914393+00	2025-07-02 00:49:09.914393+00
\.


--
-- Data for Name: communication_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.communication_logs (id, member_id, building_id, communication_type, communication_subtype, channel, status, subject, body_preview, full_content, pdf_url, pdf_filename, related_convocatoria_id, related_minute_id, related_transaction_id, draft_created_at, sent_at, opened_at, confirmed_at, failed_at, error_message, retry_count, metadata, created_at, updated_at) FROM stdin;
f7e173ce-e103-4d0d-9fb7-09dbabffd290	3aeab2cd-65ad-4f4f-8c15-725f6fa4e745	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	sent	Test Communication System	Testing the communication logging system	\N	\N	\N	\N	\N	\N	2025-10-19 12:16:22.495689+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 12:16:22.495689+00	2025-10-19 12:16:22.495689+00
63afbf65-5846-454d-8be1-1059cd80523d	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n\n📅 *Data:* 15 de novembro de 2025\n🕐 *1ª Convocatória:* \n🕐 *2ª Convocatória:* meia hora depois\n📍 *Local:* Salão de reuniões do prédio, Rés-do-chão\n\nℹ️ A convocatória oficial completa com a ordem do dia foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração.\n\nPor favor, confirme a sua presença ou representação.\n\nA Administração	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 12:28:29.226928+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 12:28:29.226928+00	2025-10-19 12:28:29.226928+00
f374ab7e-2fbd-4ee9-8c1d-236904a6e619	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n\n📅 *Data:* 15 de novembro de 2025\n🕐 *1ª Convocatória:* \n🕐 *2ª Convocatória:* meia hora depois\n📍 *Local:* Salão de reuniões do prédio, Rés-do-chão\n\nℹ️ A convocatória oficial completa com a ordem do dia foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração.\n\nPor favor, confirme a sua presença ou representação.\n\nA Administração	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 12:29:42.510406+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 12:29:42.510406+00	2025-10-19 12:29:42.510406+00
c1b250d9-e32b-4f0d-9451-ab3b9a17213b	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n\n📅 *Data:* 15 de novembro de 2025\n🕐 *1ª Convocatória:* \n🕐 *2ª Convocatória:* meia hora depois\n📍 *Local:* Salão de reuniões do prédio, Rés-do-chão\n\nℹ️ A convocatória oficial completa com a ordem do dia foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração.\n\nPor favor, confirme a sua presença ou representação.\n\nA Administração	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 12:30:55.496987+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 12:30:55.496987+00	2025-10-19 12:30:55.496987+00
9727f850-d71a-4f9d-b8a2-0909f413bf09	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n\n📅 *Data:* 15 de novembro de 2025\n🕐 *1ª Convocatória:* \n🕐 *2ª Convocatória:* meia hora depois\n📍 *Local:* Salão de reuniões do prédio, Rés-do-chão\n\nℹ️ A convocatória oficial completa com a ordem do dia foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração.\n\nPor favor, confirme a sua presença ou representação.\n\nA Administração	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 12:31:35.112908+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 12:31:35.112908+00	2025-10-19 12:31:35.112908+00
42a4d1a5-19ea-454e-a5fb-aacfa4907b64	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	draft_created	Convocatória - Assembleia Extraordinária de Condóminos - Condomino Buraca 1	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinár	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinária de Condóminos do edifício "Condomino Buraca 1", sito em Estrada da Circunvalação, nº 1, que terá lugar no dia 15 de novembro de 2025, com a seguinte ordem de trabalhos:\n\n─────────────────────────────────────────────────────────────\n\nORDEM DO DIA\n\n(Consultar documento anexo em PDF)\n\n─────────────────────────────────────────────────────────────\n\nLOCAL E HORÁRIO\n\n📍 Local: Salão de reuniões do prédio, Rés-do-chão\n\n🕐 Primeira convocatória: \n   (É necessário quórum de mais de 50% dos coeficientes)\n\n🕐 Segunda convocatória: meia hora depois\n   (É necessário quórum de mais de 25% dos coeficientes)\n\n─────────────────────────────────────────────────────────────\n\nINFORMAÇÕES IMPORTANTES\n\n• Caso não possa comparecer, poderá fazer-se representar por qualquer pessoa, mediante procuração escrita (Art. 1433.º do Código Civil).\n\n• A procuração deve ser apresentada no início da assembleia.\n\n• Para mais detalhes, consulte o documento anexo em PDF.\n\n• A sua presença ou representação é muito importante para a boa gestão do condomínio.\n\n─────────────────────────────────────────────────────────────\n\nCom os melhores cumprimentos,\n\nA Administração\nAdministrador do Condomínio\n\n\n\n\n─────────────────────────────────────────────────────────────\n\nEste email constitui convocatória oficial nos termos da Lei n.º 8/2022.\nPor favor, confirme a receção e a sua presença/representação respondendo a este email.	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 12:31:55.942025+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 12:31:55.942025+00	2025-10-19 12:31:55.942025+00
4ccfcee1-1d93-4377-b012-f50bf5e8e54e	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	draft_created	Convocatória - Assembleia Extraordinária de Condóminos - Condomino Buraca 1	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinár	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinária de Condóminos do edifício "Condomino Buraca 1", sito em Estrada da Circunvalação, nº 1, que terá lugar no dia 15 de novembro de 2025, com a seguinte ordem de trabalhos:\n\n─────────────────────────────────────────────────────────────\n\nORDEM DO DIA\n\n(Consultar documento anexo em PDF)\n\n─────────────────────────────────────────────────────────────\n\nLOCAL E HORÁRIO\n\n📍 Local: Salão de reuniões do prédio, Rés-do-chão\n\n🕐 Primeira convocatória: 19:00\n   (É necessário quórum de mais de 50% dos coeficientes)\n\n🕐 Segunda convocatória: meia hora depois\n   (É necessário quórum de mais de 25% dos coeficientes)\n\n─────────────────────────────────────────────────────────────\n\nINFORMAÇÕES IMPORTANTES\n\n• Caso não possa comparecer, poderá fazer-se representar por qualquer pessoa, mediante procuração escrita (Art. 1433.º do Código Civil).\n\n• A procuração deve ser apresentada no início da assembleia.\n\n• Para mais detalhes, consulte o documento anexo em PDF.\n\n• A sua presença ou representação é muito importante para a boa gestão do condomínio.\n\n─────────────────────────────────────────────────────────────\n\nCom os melhores cumprimentos,\n\nA Administração\nAdministrador do Condomínio\n\n\n\n\n─────────────────────────────────────────────────────────────\n\nEste email constitui convocatória oficial nos termos da Lei n.º 8/2022.\nPor favor, confirme a receção e a sua presença/representação respondendo a este email.	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 17:37:00.812396+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 17:37:00.812396+00	2025-10-19 17:37:00.812396+00
dea335ab-0840-477a-a882-034fc369543b	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n\n📅 *Data:* 15 de novembro de 2025\n🕐 *1ª Convocatória:* 19:00\n🕐 *2ª Convocatória:* meia hora depois\n📍 *Local:* Salão de reuniões do prédio, Rés-do-chão\n\nℹ️ A convocatória oficial completa com a ordem do dia foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração.\n\nPor favor, confirme a sua presença ou representação.\n\nA Administração	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 17:38:30.978562+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 17:38:30.978562+00	2025-10-19 17:38:30.978562+00
d654d1c3-d93b-4806-8a05-f17ac4520be1	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n	*Condomino Buraca 1*\n📢 Convocatória - Assembleia Extraordinária\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues* (Fração RC/DTO)\n\nFica convocado(a) para a Assembleia Extraordinária de Condóminos:\n\n📅 *Data:* 15 de novembro de 2025\n🕐 *1ª Convocatória:* 19:00\n🕐 *2ª Convocatória:* meia hora depois\n📍 *Local:* Salão de reuniões do prédio, Rés-do-chão\n\nℹ️ A convocatória oficial completa com a ordem do dia foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração.\n\nPor favor, confirme a sua presença ou representação.\n\nA Administração	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 17:45:15.000443+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 17:45:15.000443+00	2025-10-19 17:45:15.000443+00
cb5c4894-72dd-4d94-a212-356bfa9d442b	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	draft_created	Convocatória - Assembleia Extraordinária de Condóminos - Condomino Buraca 1	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinár	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinária de Condóminos do edifício "Condomino Buraca 1", sito em Estrada da Circunvalação, nº 1, que terá lugar no dia 15 de novembro de 2025, com a seguinte ordem de trabalhos:\n\n─────────────────────────────────────────────────────────────\n\nORDEM DO DIA\n\n(Consultar documento anexo em PDF)\n\n─────────────────────────────────────────────────────────────\n\nLOCAL E HORÁRIO\n\n📍 Local: Salão de reuniões do prédio, Rés-do-chão\n\n🕐 Primeira convocatória: 19:00\n   (É necessário quórum de mais de 50% dos coeficientes)\n\n🕐 Segunda convocatória: meia hora depois\n   (É necessário quórum de mais de 25% dos coeficientes)\n\n─────────────────────────────────────────────────────────────\n\nINFORMAÇÕES IMPORTANTES\n\n• Caso não possa comparecer, poderá fazer-se representar por qualquer pessoa, mediante procuração escrita (Art. 1433.º do Código Civil).\n\n• A procuração deve ser apresentada no início da assembleia.\n\n• Para mais detalhes, consulte o documento anexo em PDF.\n\n• A sua presença ou representação é muito importante para a boa gestão do condomínio.\n\n─────────────────────────────────────────────────────────────\n\nCom os melhores cumprimentos,\n\nA Administração\nAdministrador do Condomínio\n\n\n\n\n─────────────────────────────────────────────────────────────\n\nEste email constitui convocatória oficial nos termos da Lei n.º 8/2022.\nPor favor, confirme a receção e a sua presença/representação respondendo a este email.	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 17:46:13.936289+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 17:46:13.936289+00	2025-10-19 17:46:13.936289+00
aa687d47-4bbe-4a1d-84cf-b149db5cc844	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	draft_created	Convocatória - Assembleia Extraordinária de Condóminos - Condomino Buraca 1	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinár	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinária de Condóminos do edifício "Condomino Buraca 1", sito em Estrada da Circunvalação, nº 1, que terá lugar no dia 29 de maio de 2025, com a seguinte ordem de trabalhos:\n\n─────────────────────────────────────────────────────────────\n\nORDEM DO DIA\n\n(Consultar documento anexo em PDF)\n\n─────────────────────────────────────────────────────────────\n\nLOCAL E HORÁRIO\n\n📍 Local: Hall do Prédio\n\n🕐 Primeira convocatória: 18:30\n   (É necessário quórum de mais de 50% dos coeficientes)\n\n🕐 Segunda convocatória: meia hora depois\n   (É necessário quórum de mais de 25% dos coeficientes)\n\n─────────────────────────────────────────────────────────────\n\nINFORMAÇÕES IMPORTANTES\n\n• Caso não possa comparecer, poderá fazer-se representar por qualquer pessoa, mediante procuração escrita (Art. 1433.º do Código Civil).\n\n• A procuração deve ser apresentada no início da assembleia.\n\n• Para mais detalhes, consulte o documento anexo em PDF.\n\n• A sua presença ou representação é muito importante para a boa gestão do condomínio.\n\n─────────────────────────────────────────────────────────────\n\nCom os melhores cumprimentos,\n\nA Administração\nAdministrador do Condomínio\n\n\n\n\n─────────────────────────────────────────────────────────────\n\nEste email constitui convocatória oficial nos termos da Lei n.º 8/2022.\nPor favor, confirme a receção e a sua presença/representação respondendo a este email.	\N	\N	38290ab1-3b3a-4020-9280-0c9003deeac6	\N	\N	2025-10-19 17:53:10.697426+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 17:53:10.697426+00	2025-10-19 17:53:10.697426+00
18b94f97-3c17-4bba-9e55-f1aa7b55e94b	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	draft_created	Convocatória - Assembleia Extraordinária de Condóminos - Condomino Buraca 1	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinár	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues, Fração RC/DTO\n\nNos termos e para os efeitos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinária de Condóminos do edifício "Condomino Buraca 1", sito em Estrada da Circunvalação, nº 1, que terá lugar no dia 15 de novembro de 2025, com a seguinte ordem de trabalhos:\n\n─────────────────────────────────────────────────────────────\n\nORDEM DO DIA\n\n1. Aprovação de obras na fachada\n   Deliberação sobre a reparação urgente de infiltrações na fachada oeste do edifício\n\n2. Instalação de sistema de videovigilância\n   Votação para aprovação da instalação de câmaras de segurança nas áreas comuns\n\n3. Assuntos gerais\n   Ponto aberto para questões diversas dos condóminos\n\n─────────────────────────────────────────────────────────────\n\nLOCAL E HORÁRIO\n\n📍 Local: Salão de reuniões do prédio, Rés-do-chão\n\n🕐 Primeira convocatória: 19:00\n   (É necessário quórum de mais de 50% dos coeficientes)\n\n🕐 Segunda convocatória: meia hora depois\n   (É necessário quórum de mais de 25% dos coeficientes)\n\n─────────────────────────────────────────────────────────────\n\nINFORMAÇÕES IMPORTANTES\n\n• Caso não possa comparecer, poderá fazer-se representar por qualquer pessoa, mediante procuração escrita (Art. 1433.º do Código Civil).\n\n• A procuração deve ser apresentada no início da assembleia.\n\n• Para mais detalhes, consulte o documento anexo em PDF.\n\n• A sua presença ou representação é muito importante para a boa gestão do condomínio.\n\n─────────────────────────────────────────────────────────────\n\nCom os melhores cumprimentos,\n\nA Administração\nAdministrador do Condomínio\n\n\n\n\n─────────────────────────────────────────────────────────────\n\nEste email constitui convocatória oficial nos termos da Lei n.º 8/2022.\nPor favor, confirme a receção e a sua presença/representação respondendo a este email.	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 18:09:02.361108+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 18:09:02.361108+00	2025-10-19 18:09:02.361108+00
2939ab95-10a9-47a6-a51a-8bbfc6b0b363	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	draft_created	Convocatória - Assembleia Extraordinária de Condóminos - Condomino Buraca 1	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues - Fração RC/DTO\n\nNos termos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinária de Condóminos 	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues - Fração RC/DTO\n\nNos termos do disposto nos artigos 1432.º e seguintes do Código Civil, convoco V. Exa. para a Assembleia Extraordinária de Condóminos do edifício "Condomino Buraca 1", sito em Estrada da Circunvalação, nº 1, que terá lugar no dia 15 de novembro de 2025.\n\n\n════════════════════════════════════════════════════════════\n\nORDEM DO DIA\n\n   1. Aprovação de obras na fachada\n      Deliberação sobre a reparação urgente de infiltrações na fachada oeste do edifício\n      [Votação - Maioria Simples]\n\n   2. Instalação de sistema de videovigilância\n      Votação para aprovação da instalação de câmaras de segurança nas áreas comuns\n      [Votação - Maioria Qualificada]\n\n   3. Assuntos gerais\n      Ponto aberto para questões diversas dos condóminos\n      [Ponto Informativo]\n\n════════════════════════════════════════════════════════════\n\nDATA E HORA\n\n📅 Data: 15 de novembro de 2025\n🕐 Primeira Convocatória: 19:00\n    (Quórum necessário: mais de 50% dos coeficientes)\n\n🕐 Segunda Convocatória: meia hora depois\n    (Quórum necessário: mais de 25% dos coeficientes)\n\n📍 Local: Salão de reuniões do prédio, Rés-do-chão\n\n════════════════════════════════════════════════════════════\n\nINFORMAÇÕES IMPORTANTES\n\n⚠️  Caso não possa comparecer, poderá fazer-se representar por qualquer\n    pessoa mediante procuração escrita (Art. 1433.º do Código Civil).\n\n⚠️  A procuração deve ser apresentada no início da assembleia.\n\n📎  Consulte o documento anexo em PDF para mais detalhes.\n\n✅  A sua presença ou representação é muito importante para a boa\n    gestão do condomínio.\n\n════════════════════════════════════════════════════════════\n\nCom os melhores cumprimentos,\n\nA Administração\nAdministrador do Condomínio\n\n\n\n════════════════════════════════════════════════════════════\n\nEste email constitui convocatória oficial nos termos da Lei n.º 8/2022.\nPor favor, confirme a receção e a sua presença/representação.	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 18:14:24.846136+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 18:14:24.846136+00	2025-10-19 18:14:24.846136+00
83b8f8af-2f73-43b1-ba69-858c0d823d70	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	email	draft_created	Convocatória - Assembleia Extraordinária de Condóminos - Condomino Buraca 1	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues\nFração RC/DTO\nCondomino Buraca 1\nEstrada da Circunvalação, nº 1\n\n\nAssunto: Convocatória - Assembleia Extraordinária de Condóminos\n\n\nExmo(a). Senhor(a),	Exmo(a). Sr(a). Vítor Manuel Sebastian Rodrigues\nFração RC/DTO\nCondomino Buraca 1\nEstrada da Circunvalação, nº 1\n\n\nAssunto: Convocatória - Assembleia Extraordinária de Condóminos\n\n\nExmo(a). Senhor(a),\n\nNos termos do disposto nos artigos 1432.º e seguintes do Código Civil, tenho a honra de convocar V. Exa. para a Assembleia Extraordinária de Condóminos do edifício em referência, que terá lugar no dia 15 de novembro de 2025, com a seguinte ordem de trabalhos:\n\n\nORDEM DO DIA\n\n1. Aprovação de obras na fachada (Votação - Maioria Simples)\n   Deliberação sobre a reparação urgente de infiltrações na fachada oeste do edifício\n\n2. Instalação de sistema de videovigilância (Votação - Maioria Qualificada)\n   Votação para aprovação da instalação de câmaras de segurança nas áreas comuns\n\n3. Assuntos gerais\n   Ponto aberto para questões diversas dos condóminos\n\n\nDATA E HORÁRIO\n\nData: 15 de novembro de 2025\n\nPrimeira convocatória: 19:00\n(Quórum necessário: mais de 50% dos coeficientes de permilagem)\n\nSegunda convocatória: meia hora depois\n(Quórum necessário: mais de 25% dos coeficientes de permilagem)\n\nLocal: Salão de reuniões do prédio, Rés-do-chão\n\n\nREPRESENTAÇÃO\n\nNos termos do artigo 1433.º do Código Civil, caso não possa comparecer, poderá fazer-se representar por qualquer pessoa mediante procuração escrita, que deverá ser apresentada no início da assembleia.\n\nEstá disponível um modelo de procuração que pode descarregar e imprimir para este efeito.\n\n\nDOCUMENTAÇÃO\n\nA documentação relativa aos assuntos a tratar encontra-se disponível para consulta prévia, podendo ser solicitada à administração.\n\n\nAgradecemos confirmação da sua presença ou representação.\n\nCom os melhores cumprimentos,\n\nA Administração\nAdministrador do Condomínio\n\n\n\n\n---\nEste email constitui convocatória oficial nos termos da Lei n.º 8/2022.\nConvocatória n.º 31	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-19 18:24:17.545535+00	\N	\N	\N	\N	\N	0	{}	2025-10-19 18:24:17.545535+00	2025-10-19 18:24:17.545535+00
17b67568-a2e2-4e40-b405-051dd09cfaad	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📢 CONVOCATÓRIA\nAssembleia Extraordinária de Condóminos\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues*\nFração RC/DTO\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n	*Condomino Buraca 1*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📢 CONVOCATÓRIA\nAssembleia Extraordinária de Condóminos\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues*\nFração RC/DTO\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n📅 *DATA:* 15 de novembro de 2025\n\n⏰ *HORÁRIO:*\n• 1ª Convocatória: 19:00\n  (Quórum: > 50%)\n• 2ª Convocatória: meia hora depois\n  (Quórum: > 25%)\n\n📍 *LOCAL:*\nSalão de reuniões do prédio, Rés-do-chão\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n📋 *ORDEM DO DIA:*\nConsultar email\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nℹ️ A convocatória oficial completa com todos os detalhes foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração escrita.\n\n✅ Por favor, confirme a sua presença ou representação.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nA Administração\nAdministrador do Condomínio	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-25 21:03:58.408186+00	\N	\N	\N	\N	\N	0	{}	2025-10-25 21:03:58.408186+00	2025-10-25 21:03:58.408186+00
cd8b7327-e78c-493b-87aa-97b66e621457	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📢 CONVOCATÓRIA\nAssembleia Extraordinária de Condóminos\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues*\nFração RC/DTO\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n	*Condomino Buraca 1*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📢 CONVOCATÓRIA\nAssembleia Extraordinária de Condóminos\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues*\nFração RC/DTO\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n📅 *DATA:* 15 de novembro de 2025\n\n⏰ *HORÁRIO:*\n• 1ª Convocatória: 19:00\n  (Quórum: > 50%)\n• 2ª Convocatória: meia hora depois\n  (Quórum: > 25%)\n\n📍 *LOCAL:*\nSalão de reuniões do prédio, Rés-do-chão\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n📋 *ORDEM DO DIA:*\nConsultar email\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nℹ️ A convocatória oficial completa com todos os detalhes foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração escrita.\n\n✅ Por favor, confirme a sua presença ou representação.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nA Administração\nAdministrador do Condomínio	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-25 21:27:56.463242+00	\N	\N	\N	\N	\N	0	{}	2025-10-25 21:27:56.463242+00	2025-10-25 21:27:56.463242+00
79e9cb62-e264-4594-a72e-fc30ab6db90a	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	*Condomino Buraca 1*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📢 CONVOCATÓRIA\nAssembleia Extraordinária de Condóminos\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues*\nFração RC/DTO\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n	*Condomino Buraca 1*\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n📢 CONVOCATÓRIA\nAssembleia Extraordinária de Condóminos\n\nExmo(a). Sr(a). *Vítor Manuel Sebastian Rodrigues*\nFração RC/DTO\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n📅 *DATA:* 15 de novembro de 2025\n\n⏰ *HORÁRIO:*\n• 1ª Convocatória: 19:00\n  (Quórum: > 50%)\n• 2ª Convocatória: meia hora depois\n  (Quórum: > 25%)\n\n📍 *LOCAL:*\nSalão de reuniões do prédio, Rés-do-chão\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n📋 *ORDEM DO DIA:*\n1. Aprovação de obras na fachada\n2. Instalação de sistema de videovigilância\n3. Assuntos gerais\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nℹ️ A convocatória oficial completa com todos os detalhes foi enviada por email.\n\n⚠️ Caso não possa comparecer, pode fazer-se representar mediante procuração escrita.\n\n✅ Por favor, confirme a sua presença ou representação.\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\nA Administração\nAdministrador do Condomínio	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-25 21:37:35.40732+00	\N	\N	\N	\N	\N	0	{}	2025-10-25 21:37:35.40732+00	2025-10-25 21:37:35.40732+00
34391f87-8628-4c23-9e5f-66c21c2abfbb	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	Olá *Vítor Manuel Sebastian Rodrigues*,\n\n📅 *Lembrete: Assembleia Extraordinária*\n\n🗓️ Data: 15 de novembro de 2025\n⏰ Hora: 19:00\n📍 Local: Salão de reuniões do prédio, Rés-do-chão\n\n━━━━━━━━━━━━━━━━━━	Olá *Vítor Manuel Sebastian Rodrigues*,\n\n📅 *Lembrete: Assembleia Extraordinária*\n\n🗓️ Data: 15 de novembro de 2025\n⏰ Hora: 19:00\n📍 Local: Salão de reuniões do prédio, Rés-do-chão\n\n━━━━━━━━━━━━━━━━━━━━━\n\n✉️ A convocatória oficial com toda a informação foi enviada por *email/correio registado* conforme a lei.\n\nEste WhatsApp é apenas um lembrete informal, sem valor jurídico.\n\n━━━━━━━━━━━━━━━━━━━━━\n\n✅ Por favor confirme a sua presença.\n\nA Administração\nCondomino Buraca 1	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-25 22:09:55.903388+00	\N	\N	\N	\N	\N	0	{}	2025-10-25 22:09:55.903388+00	2025-10-25 22:09:55.903388+00
ef313ca1-a7a9-4fc5-a6fb-796d48cb4de2	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	Olá *Vítor Manuel Sebastian Rodrigues*,\n\n*Lembrete: Assembleia Extraordinária*\n\nData: 15 de novembro de 2025\nHora: 19:00\nLocal: Salão de reuniões do prédio, Rés-do-chão\n\n-------------------------\n\nA c	Olá *Vítor Manuel Sebastian Rodrigues*,\n\n*Lembrete: Assembleia Extraordinária*\n\nData: 15 de novembro de 2025\nHora: 19:00\nLocal: Salão de reuniões do prédio, Rés-do-chão\n\n-------------------------\n\nA convocatória oficial foi enviada por email/correio registado conforme a lei.\n\nEste WhatsApp é apenas um lembrete informal, sem valor jurídico.\n\n-------------------------\n\nPor favor confirme a sua presença.\n\nA Administração\nCondomino Buraca 1	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-25 22:14:15.258736+00	\N	\N	\N	\N	\N	0	{}	2025-10-25 22:14:15.258736+00	2025-10-25 22:14:15.258736+00
9867e5ec-7ef8-450e-b8ca-db4129f5c05d	d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	convocatoria	\N	whatsapp	draft_created	WhatsApp - convocatoria	Olá *Vítor Manuel Sebastian Rodrigues*,\n\n*Lembrete: Assembleia Extraordinária*\n\nData: 15 de novembro de 2025\nHora: 19:00\nLocal: Salão de reuniões do prédio, Rés-do-chão\n\n-------------------------\n\nA c	Olá *Vítor Manuel Sebastian Rodrigues*,\n\n*Lembrete: Assembleia Extraordinária*\n\nData: 15 de novembro de 2025\nHora: 19:00\nLocal: Salão de reuniões do prédio, Rés-do-chão\n\n-------------------------\n\nA convocatória oficial foi enviada por email/correio registado conforme a lei.\n\nEste WhatsApp é apenas um lembrete informal, sem valor jurídico.\n\n-------------------------\n\nPor favor confirme a sua presença.\n\nA Administração\nCondomino Buraca 1	\N	\N	e5eeefdf-35ab-4db4-ba1f-55a7c103123d	\N	\N	2025-10-26 01:46:33.744368+00	\N	\N	\N	\N	\N	0	{}	2025-10-26 01:46:33.744368+00	2025-10-26 01:46:33.744368+00
\.


--
-- Data for Name: convocatorias; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.convocatorias (id, building_id, building_name, building_address, postal_code, city, assembly_number, assembly_type, meeting_type, title, date, meeting_date, "time", location, meeting_location, second_call_enabled, second_call_time, second_call_date, administrator, secretary, legal_reference, minutes_created, agenda_items, convocation_date, legal_notice_period, delivery_method, attached_documents, legal_validation, quorum_requirements, status, meeting_subject, president_name, president_email, secretary_name, secretary_email, administrator_name, administrator_email, notification_sent_at, published_at, published_by_user_id, notes, created_at, updated_at) FROM stdin;
e5eeefdf-35ab-4db4-ba1f-55a7c103123d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Condomino Buraca 1	Estrada da Circunvalação, nº 1	\N	\N	31	extraordinary	\N	\N	2025-11-15	2025-11-15	19:00	Salão de reuniões do prédio, Rés-do-chão	\N	t	\N	\N	A Administração	\N	\N	f	[{"type": "votacion", "title": "Aprovação de obras na fachada", "description": "Deliberação sobre a reparação urgente de infiltrações na fachada oeste do edifício", "item_number": 1, "requiredMajority": "simple"}, {"type": "votacion", "title": "Instalação de sistema de videovigilância", "description": "Votação para aprovação da instalação de câmaras de segurança nas áreas comuns", "item_number": 2, "requiredMajority": "cualificada"}, {"type": "informativo", "title": "Assuntos gerais", "description": "Ponto aberto para questões diversas dos condóminos", "item_number": 3}]	\N	\N	\N	\N	\N	\N	draft	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-10-19 12:26:02.409741+00	2025-10-19 12:26:02.409741+00
38290ab1-3b3a-4020-9280-0c9003deeac6	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Condomino Buraca 1	Estrada da Circunvalação, nº 1	2610-041	Amadora	30	extraordinary	\N	Assembleia Extraordinária Nº 30	2025-05-29	\N	18:30	Hall do Prédio	\N	t	\N	\N	Vitor Manuel Sebastian Rodrigues	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	sent	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-02 01:18:21.014189+00	2025-10-25 16:06:24.182012+00
bedf6d4d-40c9-430b-97af-c7f1af2b1aee	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Condomino Buraca 1	Estrada da Circunvalação, nº 1	2610-041	Amadora	28	ordinary	\N	Assembleia Ordinária Nº 28	2025-02-10	\N	17:30	Hall do Prédio	\N	t	\N	\N	João Manuel Fernandes Longo	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	sent	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-02 00:59:16.947675+00	2025-10-25 16:06:24.182012+00
651707f1-3658-49f4-b625-2c33f657a749	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Condomino Buraca 1	Estrada da Circunvalação, nº 1	2610-041	Amadora	29	extraordinary	\N	Assembleia Extraordinária Nº 29	2025-03-17	\N	18:00	Hall do Prédio	\N	t	\N	\N	Vítor Manuel Sebastian Rodrigues	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	sent	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-02 00:59:16.947675+00	2025-10-25 16:06:24.182012+00
\.


--
-- Data for Name: document_categories; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.document_categories (id, building_id, name, description, color, icon, parent_category_id, sort_order, created_at) FROM stdin;
1	\N	legal	Documentos legales y normativos	#2563eb	scale	\N	0	2025-07-21 20:34:07.63228
2	\N	meeting	Actas de reuniones y asambleas	#16a34a	users	\N	0	2025-07-21 20:34:07.63228
3	\N	financial	Documentos financieros y presupuestos	#eab308	calculator	\N	0	2025-07-21 20:34:07.63228
4	\N	contract	Contratos y acuerdos	#dc2626	file-text	\N	0	2025-07-21 20:34:07.63228
5	\N	technical	Documentación técnica	#8b5cf6	wrench	\N	0	2025-07-21 20:34:07.63228
6	\N	legal	Documentos legales y normativos	#2563eb	scale	\N	0	2025-07-21 20:38:15.927275
7	\N	meeting	Actas de reuniones y asambleas	#16a34a	users	\N	0	2025-07-21 20:38:15.927275
8	\N	financial	Documentos financieros y presupuestos	#eab308	calculator	\N	0	2025-07-21 20:38:15.927275
9	\N	contract	Contratos y acuerdos	#dc2626	file-text	\N	0	2025-07-21 20:38:15.927275
10	\N	technical	Documentación técnica	#8b5cf6	wrench	\N	0	2025-07-21 20:38:15.927275
11	\N	general	Documentos generales	#6b7280	file	\N	0	2025-07-21 20:38:15.927275
\.


--
-- Data for Name: document_shares; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.document_shares (id, document_id, member_id, permission, shared_by, shared_at, expires_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.documents (id, building_id, member_id, name, original_name, file_path, file_size, mime_type, file_extension, category, subcategory, tags, description, version, parent_document_id, is_current_version, visibility, is_confidential, access_level, uploaded_by, uploaded_at, last_accessed_at, download_count, search_vector, created_at, updated_at) FROM stdin;
10	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	Apolize Seguro 2024	PDFApolice205375434.pdf	/uploads/file-1750041080619-643214668.pdf	222939	application/pdf	pdf	insurance	\N	{}	\N	1	\N	t	public	f	member	Utilizador Atual	2025-06-16 02:31:21.004147	\N	0	'2024':3A 'apoliz':1A 'segur':2A	2025-06-16 02:31:21.004147	2025-06-16 12:59:46.362788
11	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	d3ad84ae-c456-4ba7-9300-a78884804e9d	foto Pedio	IMG_1176.jpeg	/uploads/file-1750042788399-52016518_compressed.jpg	385900	image/jpeg	jpeg	general	\N	{}	\N	1	\N	t	public	f	member	Utilizador Atual	2025-06-16 02:59:51.833545	\N	0	'fot':1A 'pedi':2A	2025-06-16 02:59:51.833545	2025-06-16 11:14:01.200697
13	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	Apolize Seguro Predio	PDFApolice205375434.pdf	/uploads/doc-1750075771396-300889794.pdf	222939	application/pdf	.pdf	insurance	\N	\N	\N	1	\N	t	members_only	f	read	Utilizador Atual	2025-06-16 12:09:31.850367	\N	0	'apoliz':1A 'predi':3A 'segur':2A	2025-06-16 12:09:31.850367	2025-06-16 12:09:31.850367
\.


--
-- Data for Name: financial_periods; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.financial_periods (id, building_id, year, start_date, end_date, approved_budget, budget_approval_date, budget_approval_minute_id, reserve_fund_minimum, reserve_fund_actual, legal_compliance_check, is_closed, closed_at, total_income, total_expenses, balance, notes, closed_by_user_id, initial_balance, created_at, updated_at) FROM stdin;
d6654826-2b4b-44b9-ac85-32422e709a6d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2024	2024-01-01	2024-12-31	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	2025-07-21 22:42:08.881845+00	2025-07-21 22:42:08.881845+00
3e37d275-1b3b-4988-9bf7-b2c20ba41aab	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2025	2025-01-01	2025-12-31	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	2025-07-21 22:42:08.881845+00	2025-07-21 22:42:08.881845+00
\.


--
-- Data for Name: fractions; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.fractions (id, building_id, member_id, unit_number, ownership_percentage, surface_area, fraction_type, is_active, deed_reference, acquisition_date, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	20250626155116_create_users_table.cjs	1	2025-06-26 16:11:15.911+00
2	20250626155143_create_refresh_tokens_table.cjs	1	2025-06-26 16:11:15.926+00
3	20250626155204_create_user_sessions_table.cjs	1	2025-06-26 16:11:15.933+00
\.


--
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: letter_templates; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.letter_templates (id, building_id, name, type, subject, content, variables, is_active, legal_basis, required_fields, validation_rules, title, created_at, updated_at) FROM stdin;
405b999f-235f-4adf-8be5-c7a794a2c11f	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Convocatoria Estándar	convocatoria	Convocatoria Asamblea General	Estimado propietario...	\N	t	\N	\N	\N	\N	2025-07-21 22:43:21.735595+00	2025-07-21 22:43:21.735595+00
97617929-1338-4896-b32e-d80b227d6895	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Aviso de Pago	payment_notice	Aviso de Pago de Cuotas	Le informamos que...	\N	t	\N	\N	\N	\N	2025-07-21 22:43:21.735595+00	2025-07-21 22:43:21.735595+00
\.


--
-- Data for Name: meeting_members; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.meeting_members (id, building_id, minutes_id, member_id, member_name, apartment, votes, attendance_type, is_president, is_secretary, representative_name, signature, arrival_time, departure_time, voting_power, percentage_represented, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_annual_fees; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.member_annual_fees (id, member_id, building_id, financial_period_id, year, fee_amount, paid_amount, is_paid, due_date, paid_date, payment_method, transaction_id, notes, late_fee, installments, installment_amount, fraction_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: member_votes; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.member_votes (id, minute_agenda_item_id, member_id, building_id, member_name, apartment, vote, voting_power, representative_name, comments, vote_timestamp, is_proxy_vote, proxy_document_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.members (id, building_id, name, apartment, fraction, votes, email, phone, profile_image, notes, old_annual_fee, old_monthly_fee, new_annual_fee, new_monthly_fee, permilage, is_active, nif, nif_nie, address, ownership_percentage, deed_date, legal_representative_id, role, monthly_fee, annual_fee, avatar_url, secondary_address, secondary_postal_code, secondary_city, secondary_country, user_id, created_at, updated_at, email_consent, email_consent_date, whatsapp_number, whatsapp_consent, whatsapp_consent_date, preferred_communication) FROM stdin;
b6c37c55-303d-4e66-8f5d-bedff8f735ee	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Maria Albina Correia Sequeira	Fração C	C	1	\N	\N	\N	\N	0.00	0.00	0.00	0.00	166.7000	t	\N	\N	\N	16.67	\N	\N	owner	\N	\N	\N	\N	\N	\N	Portugal	\N	2025-07-02 00:59:16.947675+00	2025-10-19 12:27:02.564741+00	t	\N	\N	f	\N	email
497dc00b-2cf8-4368-9353-bdc462acb156	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	António Manuel Caroça Beirão	Fração E	E	1	\N	\N	\N	\N	0.00	0.00	0.00	0.00	166.7000	t	\N	\N	\N	16.67	\N	\N	owner	\N	\N	\N	\N	\N	\N	Portugal	\N	2025-07-02 00:59:16.947675+00	2025-10-19 12:27:02.564741+00	t	\N	\N	f	\N	email
8b790d78-9d4b-4357-a0ba-9e09ee329415	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	João Manuel Fernandes Longo	Fração F	F	1	\N	\N	\N	\N	0.00	0.00	0.00	0.00	166.7000	t	\N	\N	\N	16.67	\N	\N	owner	\N	\N	\N	\N	\N	\N	Portugal	\N	2025-07-02 00:59:16.947675+00	2025-10-19 12:27:02.564741+00	t	\N	\N	f	\N	email
3aeab2cd-65ad-4f4f-8c15-725f6fa4e745	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Prueba Test	Fração G	G	1	test@example.com	123456789	\N	\N	0.00	0.00	600.00	50.00	166.7000	t	123456789	\N	\N	\N	\N	\N	owner	\N	\N	\N	\N	\N	\N	Portugal	\N	2025-10-19 06:23:51.093317+00	2025-10-19 12:27:02.564741+00	t	\N	\N	f	\N	email
1dfa75cd-fafd-43cd-a0f7-038c2ad76812	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Cristina Maria Bertolo Gouveia	1º ESQ	D	1	cristina@example.com		\N		0.00	0.00	0.00	0.00	150.0000	t	\N	\N	\N	16.67	\N	\N	owner	\N	\N	\N	\N	\N	\N	Portugal	\N	2025-07-02 00:59:16.947675+00	2025-10-19 12:27:02.564741+00	t	\N	\N	f	\N	email
d3ad84ae-c456-4ba7-9300-a78884804e9d	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Vítor Manuel Sebastian Rodrigues	RC/DTO	B	1	vmsebaspt@gmail.com	916849786	\N		0.00	0.00	0.00	0.00	150.0000	t	\N	\N	\N	16.67	\N	\N	owner	\N	\N	\N	\N	\N	\N	Portugal	\N	2025-07-02 00:59:16.947675+00	2025-10-25 21:09:22.528631+00	t	\N	+351912345678	t	\N	email
6a62625e-1264-4588-b6bf-a7a8ca0771bd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	José Manuel Costa Ricardo	Fração B	B	1			\N		0.00	0.00	0.00	0.00	150.0000	t	\N	\N	\N	16.67	\N	\N	owner	\N	\N	\N	\N	\N	\N	Portugal	\N	2025-07-02 00:59:16.947675+00	2025-10-25 21:09:52.942977+00	t	\N	\N	f	\N	email
\.


--
-- Data for Name: minute_agenda_items; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.minute_agenda_items (id, minutes_id, building_id, item_number, title, description, discussion, decision, vote_type, votes_in_favor, votes_against, abstentions, is_approved, legal_requirement, created_at, updated_at, convocatoria_id) FROM stdin;
10f23e3d-8105-4b2b-b232-97164d009623	2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	1	Aprovaçao de contas. 	O administrador cessante apresentou o relatório de contas referente aos exercícios de 2021 a 2024, detalhando as principais rubricas e esclarecendo dúvidas dos presentes.		APROVADO POR UNANIMIDADE	\N	0	0	0	f	\N	2025-06-13 12:31:36.007548+00	2025-06-13 12:31:36.007548+00	\N
96338b7c-599f-4bff-bf9d-2e1f34f26eb8	776956d1-d3de-49a7-8fcc-67c255e88e35	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	1	Leitura e análise dos orçamentos recebidos para as obras a realizar.           - Discussão sobre os valores apresentados. - Organização das fases dos trabalhos. - Escolha do prestador de serviços (se aplicável).	Después de leer los presupuestos entregados, se decidió lo siguiente crear un una previsión para los próximos tres años de gastos del condominio y gastos. En las obras las obras a realizar en primer lugar empezaríamos por la parte lateral izquierda, que es la parte que afecta a las humedades que tiene la fracción de joao el siguiente fase sería el agua y la luz solicitando lo antes posible la petición al ingeniero para que fuese preparando el proyecto y una tercera fase sería esto lo intentaríamos hacer este año y la tercera fase si es posible este año si no a principios del próximo, lo que es la intervención en las escaleras de arreglar y reparar y arreglar y pintar el interior de las escaleras también se decidió siempre hay que dejar como mínimo un 20 % en de reserva en el banco. A fecha de hoy hay 14.000 € faltando por pagar algunos de los condominios algunas cuotas de este año que serán comunicados lo que falta vía carta o e-mail		DISCUTIDO_SEM_VOTACAO	\N	0	0	0	f	\N	2025-06-13 12:56:51.196167+00	2025-06-13 12:56:51.196167+00	\N
bb225805-03c4-489d-8b7a-e4d526b8961d	9f20eca5-96de-4b52-9267-c94a93aed2bb	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	1	 Apresentação do caderno de encargos para a reabilitação do prédio	Após discussão entre os presentes, decidiu-se proceder à revisão do caderno de encargos inicialmente apresentado, com o objetivo de adequá-lo às necessidades identificadas durante a assembleia. O caderno de encargos atualizado será enviado por e-mail a todos os condóminos, permitindo-lhes, com base neste documento, solicitar orçamentos às empresas que entenderem adequadas		DISCUTIDO SEM VOTAÇÃO	\N	0	0	0	f	\N	2025-06-13 12:54:58.593192+00	2025-06-13 12:54:58.593192+00	\N
57c9cc52-f86d-4df0-b11d-b18aa3193069	2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2	Debate e apresentação de orçamentos para reabilitação do prédio “saída de emergência  pintura do prédio e coluna eletricidade “ 	Foi discutida a necessidade de reabilitação geral do edifício, incluindo a "saída de emergência", pintura do prédio e coluna de eletricidade. O condómino da fração "F", Sr. José Manuel Costa Ricardo, comprometeu-se a elaborar, para apresentação na próxima assembleia extraordinária, um caderno de encargos com memória descritiva e orçamento para as referidas obras.		APROVADO POR UNANIMIDADE	\N	0	0	0	f	\N	2025-06-13 12:31:36.007548+00	2025-06-13 12:31:36.007548+00	\N
ccc295d8-2a6b-44ca-9849-141a46eecc64	9f20eca5-96de-4b52-9267-c94a93aed2bb	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2	Discussão e deliberação sobre outros assuntos de interesse geral referentes ao condomínio	Ficou decidido que os orçamentos, elaborados com base no caderno de encargos revisto, deverão ser entregues em envelope fechado até ao dia 29 de maio de 2025. Nesse mesmo dia, realizar-se-á uma nova assembleia destinada à abertura e análise das propostas recebidas, às 18h30 em primeira convocatória e às 19h00 em segunda convocatória. Convidam-se todos os condóminos a participar nesta reunião, assegurando assim um processo de seleção transparente e rigoroso.		DISCUTIDO SEM VOTAÇÃO	\N	0	0	0	f	\N	2025-06-13 12:54:58.593192+00	2025-06-13 12:54:58.593192+00	\N
a9cd93e3-56c1-4b2b-bdc8-0bd5095a241a	2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	3	Eleição do nova administração do condomínio. 	Procedeu-se à eleição para a nova administração. Foi proposto e eleito o Sr. Vítor Manuel Sebastian Rodrigues (fração "A") como Administrador. Para apoiá-lo, foi nomeado o Sr. João Manuel Fernandes Longo (fração "E") como Secretário.		APROVADO POR UNANIMIDADE	\N	0	0	0	f	\N	2025-06-13 12:31:36.007548+00	2025-06-13 12:31:36.007548+00	\N
a54fa569-d5d6-49e7-8ecd-3fdfc90797f0	2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	4	Apresentação e aprovação do orçamento em exercício para 2025. 	Apresentou-se um orçamento de 2.375 € para o exercício de 2025, acrescido de 10% (237,50 €) para reforço do fundo comum de reserva, totalizando 2.612,50 €.		APROVADO POR UNANIMIDADE	\N	0	0	0	f	\N	2025-06-13 12:31:36.007548+00	2025-06-13 12:31:36.007548+00	\N
5e05d4c7-0bf5-4275-86bf-49d0a754b727	2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	5	Outros assuntos de interesse geral referente ao condomínio. 	Foi discutida a atualização do serviço de limpeza das escadas. Anteriormente, o serviço era prestado ao custo de 50 € mensais durante 13 meses. A proposta atual é ajustar para 65 € mensais durante 12 meses.		APROVADO POR UNANIMIDADE	\N	0	0	0	f	\N	2025-06-13 12:31:36.007548+00	2025-06-13 12:31:36.007548+00	\N
1dedb8ff-1188-46bc-ba07-237a70fbab37	2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	6	Solução para as caixas de correio fixadas na porta. 	Foram analisadas possíveis soluções para a instalação de caixas de correio na porta de entrada. Decidiu-se solicitar orçamentos para avaliar a viabilidade da implementação futura desta melhoria.		ADIADO	\N	0	0	0	f	\N	2025-06-13 12:31:36.007548+00	2025-06-13 12:31:36.007548+00	\N
c10c7c62-6bd8-4300-9c57-9906b19e7ac0	2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	7	Autorização conjunta para movimentações bancárias. 	Foi discutido e aprovado que todas as operações bancárias, incluindo levantamentos, transferências, pagamentos e a abertura de novas contas em nome do condomínio, deverão ser autorizadas conjuntamente pelo novo administrador, Sr. Vítor Manuel Sebastian Rodrigues (fração "A"), e pelo secretário, Sr. João Manuel Fernandes Longo (fração "E"). A abertura de novas contas exigirá a aprovação prévia da assembleia de condóminos, salvo em casos de urgência, que deverão ser ratificados na assembleia seguinte.		APROVADO POR UNANIMIDADE	\N	0	0	0	f	\N	2025-06-13 12:31:36.007548+00	2025-06-13 12:31:36.007548+00	\N
f0c0c9a2-fe59-429f-a570-7db419c3e238	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	1	Leitura e análise dos orçamentos recebidos para as obras a realizar.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      +\n  - Discussão sobre os valores apresentados.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       +\n  - Organização das fases dos trabalhos.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           +\n  - Escolha do prestador de serviços (se aplicável).	\N	\N	\N	\N	0	0	0	f	\N	2025-05-19 13:37:41.83+00	2025-06-13 10:47:27.409661+00	38290ab1-3b3a-4020-9280-0c9003deeac6
016a0f5b-0ae4-4aa1-937f-ed436a3a053c	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	1	Aprovaçao de contas. 	\N	\N	\N	\N	0	0	0	f	\N	2025-03-18 12:48:06.101+00	2025-06-13 10:47:27.409661+00	bedf6d4d-40c9-430b-97af-c7f1af2b1aee
ec061529-d13f-4dff-88ba-de68d2629b28	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	1	 Apresentação do caderno de encargos para a reabilitação do prédio	\N	\N	\N	\N	0	0	0	f	\N	2025-03-17 08:36:27.393+00	2025-06-13 10:47:27.409661+00	651707f1-3658-49f4-b625-2c33f657a749
3ae3e6ad-d5a4-4e38-bd55-6f12e26dbea7	776956d1-d3de-49a7-8fcc-67c255e88e35	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2	Outros assuntos de interesse geral.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               +\n  - Espaço para os condóminos apresentarem dúvidas, sugestões ou reclamações	Se volvió abrir el debate sobre las escaleras del tercero, ya que hay una Ata anterior, la cual dice que que ya se había aprobado en el acta número X con el siguiente texto, lo cual el condominio discutió este tema y decidió a follar con la escaleras al tejado con 1/3 del presupuesto como máximo 4100 € que en teoría es lo que cuesta las escaleras, ya que quien usó o quien tiene acceso a tener acceso y va la parte inferior del tejado que no sé cómo se llama en portugués, serán los que tienen que hacer el resto de las obras para por ese motivo también usas sufrían de algo que es de todos			\N	0	0	0	f	\N	2025-06-13 12:56:51.196167+00	2025-06-13 12:56:51.196167+00	\N
241e87a5-8624-44bd-8b04-0f255668dde9	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2	Discussão e deliberação sobre outros assuntos de interesse geral referentes ao condomínio	\N	\N	\N	\N	0	0	0	f	\N	2025-03-17 08:36:27.393+00	2025-06-13 10:47:27.409661+00	651707f1-3658-49f4-b625-2c33f657a749
ba9a2f74-33a9-4de3-8cbe-cf76e8c61a21	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2	Debate e apresentação de orçamentos para reabilitação do prédio “saída de emergência  pintura do prédio e coluna eletricidade “ 	\N	\N	\N	\N	0	0	0	f	\N	2025-03-18 12:48:06.101+00	2025-06-13 10:47:27.409661+00	bedf6d4d-40c9-430b-97af-c7f1af2b1aee
b9664f88-ee48-4fe7-b912-93890388716e	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	2	Outros assuntos de interesse geral.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       +\n  - Espaço para os condóminos apresentarem dúvidas, sugestões ou reclamações	\N	\N	\N	\N	0	0	0	f	\N	2025-05-19 13:37:41.83+00	2025-06-13 10:47:27.409661+00	38290ab1-3b3a-4020-9280-0c9003deeac6
3b80fc62-c10b-4dc2-880e-f9eaa150775f	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	3	Eleição do nova administração do condomínio. 	\N	\N	\N	\N	0	0	0	f	\N	2025-03-18 12:48:06.101+00	2025-06-13 10:47:27.409661+00	bedf6d4d-40c9-430b-97af-c7f1af2b1aee
a755bf8a-f3e3-4b0e-83fa-62dd696907d5	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	4	Apresentação e aprovação do orçamento em exercício para 2025. 	\N	\N	\N	\N	0	0	0	f	\N	2025-03-18 12:48:06.101+00	2025-06-13 10:47:27.409661+00	bedf6d4d-40c9-430b-97af-c7f1af2b1aee
6b83cbe7-068a-4203-81a9-7a44d29c42e4	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	5	Outros assuntos de interesse geral referente ao condomínio. 	\N	\N	\N	\N	0	0	0	f	\N	2025-03-18 12:48:06.101+00	2025-06-13 10:47:27.409661+00	bedf6d4d-40c9-430b-97af-c7f1af2b1aee
04287284-a620-4372-9532-d75f9c3a9298	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	6	Solução para as caixas de correio fixadas na porta. 	\N	\N	\N	\N	0	0	0	f	\N	2025-03-18 12:48:06.101+00	2025-06-13 10:47:27.409661+00	bedf6d4d-40c9-430b-97af-c7f1af2b1aee
d394aeaf-9ae5-4549-ba75-097fc37dfed0	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	7	Autorização para a gestão de contas bancárias. 	\N	\N	\N	\N	0	0	0	f	\N	2025-03-18 12:48:06.101+00	2025-06-13 10:47:27.409661+00	bedf6d4d-40c9-430b-97af-c7f1af2b1aee
\.


--
-- Data for Name: minute_signatures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.minute_signatures (id, minute_id, member_id, signer_type, signer_name, signature, rubric, cmd_signature, cmd_timestamp, cmd_certificate, signed_at, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: minutes; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.minutes (id, building_id, convocatoria_id, minute_number, meeting_date, meeting_time, end_time, start_time, location, meeting_location, assembly_type, building_address, building_name, postal_code, president_name, administrator_custom, secretary_name, secretary_custom, conclusions, attendees, total_units_represented, total_percentage_represented, quorum_achieved, agenda_development, votes_record, agreements_reached, legal_validity, signed_date, president_signature, secretary_signature, final_document_url, attendees_count, quorum_percentage, quorum_met, agenda_items, decisions, voting_results, next_meeting_date, attachments, is_approved, approved_at, approved_by_user_id, notes, status, created_at, updated_at) FROM stdin;
2e656e48-8b5b-457f-a83b-661b77d177cd	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	bedf6d4d-40c9-430b-97af-c7f1af2b1aee	28	2025-02-10	17:30	\N	\N	Hall do Prédio	\N	ordinary	Estrada da Circunvalação, nº 1	Condomino Buraca 1	2610-041	João Manuel Fernandes Longo	\N	Cristina Maria Bertolo Gouveia	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	signed	2025-03-17 09:09:19.069683+00	2025-10-19 04:57:38.347101+00
9f20eca5-96de-4b52-9267-c94a93aed2bb	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	651707f1-3658-49f4-b625-2c33f657a749	29	2025-03-17	18:00	\N	\N	Hall do Prédio	\N	extraordinary	Estrada da Circunvalação, nº 1	Condomino Buraca 1	2610-041	Vítor Manuel Sebastian Rodrigues	\N	João Manuel Fernandes Longo	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	signed	2025-03-17 18:12:24.66613+00	2025-10-19 04:57:38.347101+00
776956d1-d3de-49a7-8fcc-67c255e88e35	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	38290ab1-3b3a-4020-9280-0c9003deeac6	30	2025-05-27	19:00	\N	\N	Hall do Prédio	\N	extraordinary	Estrada da Circunvalação, nº 1	Condomino Buraca 1	2610-041	Vítor Manuel Sebastian Rodrigues	\N	João Manuel Fernandes Longo	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	signed	2025-05-19 12:37:43.108+00	2025-10-19 04:57:38.347101+00
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.refresh_tokens (id, token, user_id, device_id, device_name, ip_address, user_agent, expires_at, is_revoked, revoked_at, created_at, updated_at) FROM stdin;
244bd2a3-dcc3-4728-a426-826a6b5db10a	1ba9fe28847bbe1c8f6b5b73f11b688e65dd8a3421cf5ab6b6e00a48e14ddbed	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	curl/8.7.1	2025-07-08 23:27:25.563+00	f	\N	2025-07-01 23:27:25.563849+00	2025-07-01 23:27:25.563849+00
b6302d7e-fb9a-4577-a065-978ab5b7281f	518cd4c8e91bdcbe00b5b565e8e259d4eb595b1200bd05967f7b188781f488cb	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	curl/8.7.1	2025-07-08 23:30:06.061+00	f	\N	2025-07-01 23:30:06.061996+00	2025-07-01 23:30:06.061996+00
71496a04-84ca-42b3-945d-0e9abd79381c	beda43eae5e4be0119146bf577d4357e7381af24667d1c5628405fc86873152f	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	curl/8.7.1	2025-07-08 23:32:11.567+00	f	\N	2025-07-01 23:32:11.567757+00	2025-07-01 23:32:11.567757+00
8f2e8d2e-0385-41f4-9710-ddebd34e7e02	a4ffa4bf8060c33391a78a40248a79f648ff32412e46e5d2977c0bf9f9b9bf7d	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	curl/8.7.1	2025-07-08 23:56:04.972+00	f	\N	2025-07-01 23:56:04.972518+00	2025-07-01 23:56:04.972518+00
7e9b0ee1-0779-49d2-ac87-6305a6848afb	cce475fd93928b31ff50b24a9ff191a73745d69da693228d6b599bed20ae7fcf	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	curl/8.7.1	2025-07-09 00:05:16.005+00	f	\N	2025-07-02 00:05:16.005723+00	2025-07-02 00:05:16.005723+00
f460e7fd-0c76-4b38-bd07-2b4ff5d91c58	f4a83079cc130560c5c338bf24d4ce763c77c20abab1bc4a61611546b60711b4	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 00:15:46.852+00	f	\N	2025-07-02 00:15:46.852414+00	2025-07-02 00:15:46.852414+00
d4b78f37-fad9-4407-898a-f22f061dfa56	90cc49478b796296071c108398a6e5f37da3548ff403e35ea55032ec52fa8f9c	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::ffff:127.0.0.1	curl/8.7.1	2025-07-09 00:24:41.656+00	f	\N	2025-07-02 00:24:41.656824+00	2025-07-02 00:24:41.656824+00
e94dbd1d-e84c-4f18-83e4-c5913bc251c7	351191418b55d84c2cb9e7dbcb540a86d064590e9404021efea61ac65522bd67	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15	2025-07-09 00:28:47.396+00	f	\N	2025-07-02 00:28:47.396632+00	2025-07-02 00:28:47.396632+00
c1a829f1-b99b-421b-aa6b-855866ba4220	00a2033f1ad85fe027a604c0c46e6f0dcbf5484aa4e1e91d7d54199522133269	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 00:29:04.56+00	f	\N	2025-07-02 00:29:04.560362+00	2025-07-02 00:29:04.560362+00
3c1f8087-481d-430f-9d19-d03e08388da9	83aec35584ab0d935dd97f578e28ea7803a4bde37d28942345dd4f50b5d4d140	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 00:50:45.293+00	f	\N	2025-07-02 00:50:45.293954+00	2025-07-02 00:50:45.293954+00
7111a2ca-aafd-4eb6-a782-fe93fa3441d1	c2775af9ed67d43a5cf36893b02d73776ecbb524aaa294fccabae9cd8cf2c31a	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 00:51:02.585+00	f	\N	2025-07-02 00:51:02.585583+00	2025-07-02 00:51:02.585583+00
5ab188bb-ee46-4238-ba14-70ff1b873a60	1b96ab549a170e6229e84a576ecf0986fdb5379c0b3e89a1a5c644ed4b14a1bd	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 00:51:22.137+00	f	\N	2025-07-02 00:51:22.13783+00	2025-07-02 00:51:22.13783+00
c80b2531-8557-4593-8a4a-6049f9c39928	1cf8e0d8ecc05c36291d09f30c7234a39b07d9a436e1a2acafc48081bafff4d2	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 00:51:31.803+00	f	\N	2025-07-02 00:51:31.803662+00	2025-07-02 00:51:31.803662+00
ded55f17-f143-422f-9e92-49173614aa7a	d45ab642b01e0628c0c1d9671388a4625d53f5186745e20e9070180e4d664d67	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 01:25:45.379+00	f	\N	2025-07-02 01:25:45.379765+00	2025-07-02 01:25:45.379765+00
2bec9996-3e9a-4b9e-a690-fde698d7af45	f7ab6e765fc08be7736c9ebf0ead1db530d6241b35e3e63df123cd1b85b6929b	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 01:26:16.39+00	f	\N	2025-07-02 01:26:16.390265+00	2025-07-02 01:26:16.390265+00
09af9c23-1a52-4974-8530-fc904dae7f7f	b477a396e8cd0e9effffdd78de3f0a83e129c9f40558ea367d9c3f9b12a3c996	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 01:27:36.508+00	f	\N	2025-07-02 01:27:36.508401+00	2025-07-02 01:27:36.508401+00
243deef2-aee6-44a1-bba8-e112d2981ce4	039774496bf486e574865eb766a1b86f24649be8ada5afb6d94cb38c1b149721	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 01:34:44.044+00	f	\N	2025-07-02 01:34:44.044323+00	2025-07-02 01:34:44.044323+00
83cf3582-374e-4d02-a6d0-a01fb960076a	f820d819658c4c948f75ee9b1b27bf387031d304d0d6bb7cceb01d176bca40a2	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	curl/8.7.1	2025-07-09 01:51:47.404+00	f	\N	2025-07-02 01:51:47.404807+00	2025-07-02 01:51:47.404807+00
ee65417f-08bd-43e1-848c-4ab55be6d8e8	fc6c71953d71cf4ece2d87e7f61a1df6e17d9ee9001d93a3cb243292cc269e92	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15	2025-07-09 01:52:45.744+00	f	\N	2025-07-02 01:52:45.744942+00	2025-07-02 01:52:45.744942+00
0e5eb263-0373-4e5c-b926-3cb9121abc45	9f53ce44d6e3aa0e58f009c4f47061706c1de191d20d77031da721bce5d63ab2	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	axios/1.10.0	2025-07-09 10:57:06.283+00	f	\N	2025-07-02 10:57:06.284283+00	2025-07-02 10:57:06.284283+00
3fadd9d8-bcf5-4e56-978d-db4cc0406663	2aabaa544503bb7338fb14e867d95c7ab3fbc875dc4b745a44404a6534f67f73	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15	2025-07-09 11:16:26.551+00	t	2025-07-02 11:32:46.23+00	2025-07-02 11:16:26.551557+00	2025-07-02 11:16:26.551557+00
90bc3f80-83f4-4842-96fe-2b7517951313	954dfd133fa116f238aa4bb4e0380e6b24d4eb7e05d9baf045ef304da731cdd4	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15	2025-07-09 11:33:11.851+00	f	\N	2025-07-02 11:33:11.851562+00	2025-07-02 11:33:11.851562+00
5b2eabea-d29a-4a65-8664-b2ac03016e1f	95e6fe77a0556b7355898224811360d3cc24b5a5d846b7ff7a0d59e70d054960	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15	2025-07-15 23:13:46.884+00	f	\N	2025-07-08 23:13:46.885291+00	2025-07-08 23:13:46.885291+00
9a13b988-2848-4891-97f4-b2d3ee90bcc5	f895d601aa3d55e8c447ceb94a0ab4f43115f2878e9b137d17f742189f620dee	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15	2025-07-28 20:12:09.466+00	f	\N	2025-07-21 20:12:09.468521+00	2025-07-21 20:12:09.468521+00
cf7d66f0-3eee-49c7-9085-76b1743ffbc0	b1699b10911f5b28d1bc2dbe239f869ead4f01998fc5ceda7a1cba803ce0978a	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:172.67.4.173	node	2025-07-28 20:48:34.235+00	f	\N	2025-07-21 20:48:34.236007+00	2025-07-21 20:48:34.236007+00
2c762d05-9bd1-44b0-a7e3-58433f2e4049	17467e752890f70ee452dbae6f95792429b9cec5bd8c8499fbb0135d21103a34	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:172.67.4.173	node	2025-07-28 20:51:45.113+00	f	\N	2025-07-21 20:51:45.114338+00	2025-07-21 20:51:45.114338+00
d407da38-eaf9-467f-bdac-a3a79aeeaf8b	c2a659cac6004c3fc72c11abd6d6b393094d5305e19b0465e8b194fa1dae230e	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:172.67.4.173	node	2025-07-28 20:55:00.635+00	f	\N	2025-07-21 20:55:00.636186+00	2025-07-21 20:55:00.636186+00
8c99c0df-131b-4a17-a84b-6347a6c4ba41	76468e08ab8f79d5bf08aecf353f174a325a648370aa12794b2a58768e4f7f37	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:172.67.4.173	node	2025-07-28 20:57:25.628+00	f	\N	2025-07-21 20:57:25.629668+00	2025-07-21 20:57:25.629668+00
3052748c-cc81-431c-9a24-1bdea6885fa4	7b1e0e21be97474c80572e4dee91395968dd9965959779521d152d224943484e	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:172.67.4.173	node	2025-07-28 21:01:26.94+00	f	\N	2025-07-21 21:01:26.941467+00	2025-07-21 21:01:26.941467+00
682f8f2d-7080-45fe-8941-817f5fbb4a6d	3e4449a56091c6c5963c9fb6687d744cb249e06fab6bde583f6a0c4d71961207	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:172.67.4.173	node	2025-07-28 21:02:47.639+00	f	\N	2025-07-21 21:02:47.640209+00	2025-07-21 21:02:47.640209+00
4e727cbe-5266-47ff-8f82-74f2fd7a0542	ba2cd0d17defff1a85dde5c64cfdda99c73cf713b921cc561e735a53ae48b8c2	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:172.67.4.173	node	2025-07-28 22:46:48.753+00	f	\N	2025-07-21 22:46:48.755252+00	2025-07-21 22:46:48.755252+00
3092ebd5-fff1-4462-b8f4-7ab4646843f2	979b425ce43037c8965e445afbe77829dc31ce14864ea95147426987fa4a3f65	fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.6 Safari/605.1.15	2025-10-26 06:03:12.4+00	f	\N	2025-10-19 06:03:12.400074+00	2025-10-19 06:03:12.400074+00
d5d65820-81e0-4ad7-9c5c-fd0cd9ba8a3a	264fe9fc1b8580cd0aac63c5e2c5ebf36943ca4ead5f4a26b90d387bc814236e	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15	2025-11-01 14:56:08.104+00	f	\N	2025-10-25 14:56:08.1048+00	2025-10-25 14:56:08.1048+00
87f8b455-2195-4d11-85a7-a2c13bcb5d2d	37af0d3b9f4713d6a81ddac0cbee8ad71f8529f71345a1f060e07392c90ca9ae	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:185.199.109.133	curl/8.7.1	2025-11-01 16:23:40.752+00	f	\N	2025-10-25 16:23:40.753246+00	2025-10-25 16:23:40.753246+00
938b9d0c-e0ea-4984-936d-98fe8aed461a	35b0021b082c1b3bbd402c6d8924c228455723e187087cd7303ce551a3b558b6	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:185.199.109.133	curl/8.7.1	2025-11-01 16:24:05.452+00	f	\N	2025-10-25 16:24:05.453007+00	2025-10-25 16:24:05.453007+00
32b5f748-ba12-4901-a1e9-e7ce7453cf29	6977a1addb4d4706b41224899a3a1f9973bede3f12dfcdcaf8ae15751f56c39a	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:185.199.109.133	curl/8.7.1	2025-11-01 16:53:33.712+00	f	\N	2025-10-25 16:53:33.712948+00	2025-10-25 16:53:33.712948+00
b14a6ce1-19ac-4e50-a430-805d737c8aec	b8bc86546b4165305b3897a911c56f213a1fe3e993f2c726758c4d6bea189bc6	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:185.199.109.133	curl/8.7.1	2025-11-01 17:06:30.901+00	f	\N	2025-10-25 17:06:30.902378+00	2025-10-25 17:06:30.902378+00
aa561a0e-1bca-4abd-838c-0730ba65ef75	d258eca50cd43154ad77dd4f90448be2f4e55007c442b17a346807c5937b8192	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 17:19:52.909+00	f	\N	2025-10-25 17:19:52.909938+00	2025-10-25 17:19:52.909938+00
e824d00c-29fc-4968-a096-1d2b64e2b627	5a0a22218f9d3d4df938b7e7844df717fe3aff38c278c5b1bb11179d2d67a02e	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 17:24:12.853+00	f	\N	2025-10-25 17:24:12.854127+00	2025-10-25 17:24:12.854127+00
db4f6857-befc-412a-9802-3928334a0a58	b38063d3b8d74255cd3b7b55ccdf4713a0db906dcbee8a052ebe7231a898aafd	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 19:36:31.283+00	f	\N	2025-10-25 19:36:31.284045+00	2025-10-25 19:36:31.284045+00
4934e1ea-0232-48e9-89ce-06274f794cc7	cec64559b94094a582373096474db7b18b77669b0d77067d4d476769206dfb49	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 19:40:03.217+00	f	\N	2025-10-25 19:40:03.217646+00	2025-10-25 19:40:03.217646+00
1452d19d-b7a3-423b-a529-1c7b359c53de	d9c7879ea3464768df381002c73fd15bab61bd50a6b1f70cec1ef942512d529a	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 19:53:51.945+00	f	\N	2025-10-25 19:53:51.946068+00	2025-10-25 19:53:51.946068+00
eaa45be0-a200-47ae-a699-1fa96355d088	8c4f1ba8a894eab1760ca2f481f07e9d612ef458f0b7a72523d2f2de901493ca	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 20:23:41.029+00	f	\N	2025-10-25 20:23:41.030582+00	2025-10-25 20:23:41.030582+00
17ebf92f-6fb9-4c2c-a4ba-72c596504596	9b53ce80368b8bf023aa285214d7adf3e0124387f39e37ea4c4f18776431b02b	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 20:55:09.088+00	f	\N	2025-10-25 20:55:09.08922+00	2025-10-25 20:55:09.08922+00
989257a0-1648-4842-a89b-3542790dc45e	62b4b07705c43abe079eb7222e5989a036dbd4d92148482c70712e60c836c7d6	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::ffff:192.168.65.1	curl/8.7.1	2025-11-01 21:07:46.368+00	f	\N	2025-10-25 21:07:46.369638+00	2025-10-25 21:07:46.369638+00
a7794d44-f353-4244-ba27-675350e82b27	35aca2d8caeccd2e7369315ec898b2c463f37ef2df04de638c4a445957ba9ad1	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15	2025-11-01 21:32:53.179+00	f	\N	2025-10-25 21:32:53.180281+00	2025-10-25 21:32:53.180281+00
bb191802-7800-4ff3-9dca-bad5ebf83444	e3c5aa590d02e7a66ab101b8078aa4663531dc0ac71f434efd008f87204304a1	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15	2025-11-02 01:51:03.359+00	f	\N	2025-10-26 01:51:03.360004+00	2025-10-26 01:51:03.360004+00
2f9934ee-a5e0-4f9c-9cfd-7166179a628b	29f916ba4e81d70eb1484cd8273c9d7b906bb293517db3fd172fffb73fbf8f89	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15	2025-11-02 02:03:07.732+00	f	\N	2025-10-26 02:03:07.732744+00	2025-10-26 02:03:07.732744+00
c371baa6-4d4a-42de-ad67-ca9ade84abfa	fb3337d597a0da927694418f648448397b2fb19e48028cacae47bfff4dbf5e15	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15	2025-11-02 16:39:53.257+00	f	\N	2025-10-26 16:39:53.257933+00	2025-10-26 16:39:53.257933+00
f4b50c7d-6358-4ca3-b078-e4fe3f355f27	975c869a5d0c1eedc8505f5b65601e3e33e5e96b3e6db3ea6181902afbc97e1b	4171cd13-d28b-4237-a86f-f6683a9ad9fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0.1 Safari/605.1.15	2025-11-02 16:58:29.463+00	f	\N	2025-10-26 16:58:29.463636+00	2025-10-26 16:58:29.463636+00
\.


--
-- Data for Name: sent_letters; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.sent_letters (id, building_id, template_id, member_id, recipient_name, recipient_email, subject, content, send_method, sent_date, delivery_confirmation, tracking_number, legal_validity, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.tasks (id, building_id, minute_id, title, description, assignee_id, assignee_name, due_date, status, priority, category, created_by, created_at, updated_at, completed_at, completed_by, notes) FROM stdin;
4	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	Revisión sistema de incendios	Inspección anual obligatoria	1dfa75cd-fafd-43cd-a0f7-038c2ad76812	Carlos Mendes	2025-09-15	pending	high	safety	1dfa75cd-fafd-43cd-a0f7-038c2ad76812	2025-07-21 20:38:15.894941+00	2025-07-21 20:38:15.894941+00	\N	\N	\N
5	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	Pintura de fachada	Pintar fachada principal del edificio	1dfa75cd-fafd-43cd-a0f7-038c2ad76812	Carlos Mendes	2025-10-01	pending	medium	maintenance	1dfa75cd-fafd-43cd-a0f7-038c2ad76812	2025-07-21 20:38:15.894941+00	2025-07-21 20:38:15.894941+00	\N	\N	\N
\.


--
-- Data for Name: transaction_categories; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.transaction_categories (id, building_id, name, description, type, transaction_type, is_active, color, budget_amount, parent_category_id, sort_order, created_at, updated_at) FROM stdin;
a1c5c5c5-5e5e-4e4e-8e8e-8e8e8e8e8e01	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Quotas Mensais	\N	income	\N	t	\N	\N	\N	0	2025-07-02 00:49:09.914393+00	2025-07-02 00:49:09.914393+00
a1c5c5c5-5e5e-4e4e-8e8e-8e8e8e8e8e02	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Manutenção	\N	expense	\N	t	\N	\N	\N	0	2025-07-02 00:49:09.914393+00	2025-07-02 00:49:09.914393+00
a1c5c5c5-5e5e-4e4e-8e8e-8e8e8e8e8e03	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Limpeza	\N	expense	\N	t	\N	\N	\N	0	2025-07-02 00:49:09.914393+00	2025-07-02 00:49:09.914393+00
a1c5c5c5-5e5e-4e4e-8e8e-8e8e8e8e8e04	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Electricidade	\N	expense	\N	t	\N	\N	\N	0	2025-07-02 00:49:09.914393+00	2025-07-02 00:49:09.914393+00
a1c5c5c5-5e5e-4e4e-8e8e-8e8e8e8e8e05	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	Água	\N	expense	\N	t	\N	\N	\N	0	2025-07-02 00:49:09.914393+00	2025-07-02 00:49:09.914393+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.transactions (id, building_id, financial_period_id, period_id, category_id, transaction_date, date, transaction_type, type, description, amount, fraction_id, member_id, payment_method, reference_number, notes, admin_notes, receipt_url, is_recurring, recurring_frequency, recurring_months, year, is_fee_payment, is_confirmed, last_modified_by, tags, created_by_user_id, approved_by_user_id, approved_at, created_at, updated_at) FROM stdin;
cbc30811-8181-4e2f-8d6a-89c5187f9bca	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	\N	\N	2025-01-13	\N	income	\N	TRF CR INTRAB 492 DE VITOR MANUEL SEBASTIAN	26.13	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025	f	t	\N	\N	\N	\N	\N	2025-07-02 01:20:22.01452+00	2025-07-02 01:20:22.01452+00
45af40e5-22f8-4bbe-b1aa-551820f5b369	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	\N	\N	2025-01-08	\N	expense	\N	MANUTENCAO DE CONTA VALOR NEGOCIOS 2024	7.99	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025	f	t	\N	\N	\N	\N	\N	2025-07-02 01:20:22.01452+00	2025-07-02 01:20:22.01452+00
87d15110-e0bc-422a-b1b6-4f119199180a	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	\N	\N	2025-01-08	\N	expense	\N	IMPOSTO DE SELO DEZ 2024	0.32	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	2025	f	t	\N	\N	\N	\N	\N	2025-07-02 01:20:22.01452+00	2025-07-02 01:20:22.01452+00
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.user_sessions (id, user_id, session_token, activity_log, last_activity_at, ip_address, user_agent, device_type, browser, os, country, city, is_active, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.users (id, email, password_hash, name, phone, role, permissions, is_active, email_verified, email_verified_at, reset_password_token, reset_password_expires, failed_login_attempts, locked_until, building_id, member_id, created_at, updated_at, last_login_at, deleted_at) FROM stdin;
fe2c6b79-8fd0-4ab0-a965-a687e3cf2d0e	admin@migestpro.com	$2b$10$C/1VIawyjuI9TsZ1OwwwdO2E.ccHknYR5gVmScVw86ymWuBuVbWc2	Administrador	\N	admin	{}	t	f	\N	\N	\N	0	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	2025-07-02 00:15:41.890527+00	2025-10-19 06:03:12.39722+00	2025-10-19 06:03:12.388+00	\N
4171cd13-d28b-4237-a86f-f6683a9ad9fb	admin@example.com	$2b$10$5JytB8TVHs3l828WPONDFOmWRzDDbaj3COWhpi0HeSZJvCxdEkCb.	Administrador	\N	super_admin	{}	t	t	\N	\N	\N	0	\N	fb0d83d3-fe04-47cb-ba48-f95538a2a7fc	\N	2025-07-01 22:51:30.465493+00	2025-10-26 16:58:29.459496+00	2025-10-26 16:58:29.458+00	\N
\.


--
-- Data for Name: voting_results; Type: TABLE DATA; Schema: public; Owner: mini-server
--

COPY public.voting_results (id, minute_agenda_item_id, total_votes, votes_in_favor, votes_against, abstentions, quorum_percentage, is_approved, created_at, updated_at) FROM stdin;
\.


--
-- Name: document_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mini-server
--

SELECT pg_catalog.setval('public.document_categories_id_seq', 11, true);


--
-- Name: document_shares_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mini-server
--

SELECT pg_catalog.setval('public.document_shares_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mini-server
--

SELECT pg_catalog.setval('public.documents_id_seq', 5, true);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mini-server
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 3, true);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: mini-server
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mini-server
--

SELECT pg_catalog.setval('public.tasks_id_seq', 5, true);


--
-- Name: arrears arrears_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.arrears
    ADD CONSTRAINT arrears_pkey PRIMARY KEY (id);


--
-- Name: attendance_sheets attendance_sheets_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.attendance_sheets
    ADD CONSTRAINT attendance_sheets_pkey PRIMARY KEY (id);


--
-- Name: attendees attendees_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_pkey PRIMARY KEY (id);


--
-- Name: buildings buildings_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.buildings
    ADD CONSTRAINT buildings_pkey PRIMARY KEY (id);


--
-- Name: communication_logs communication_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_pkey PRIMARY KEY (id);


--
-- Name: convocatorias convocatorias_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.convocatorias
    ADD CONSTRAINT convocatorias_pkey PRIMARY KEY (id);


--
-- Name: document_categories document_categories_building_id_name_key; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_building_id_name_key UNIQUE (building_id, name);


--
-- Name: document_categories document_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_pkey PRIMARY KEY (id);


--
-- Name: document_shares document_shares_document_id_member_id_key; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_document_id_member_id_key UNIQUE (document_id, member_id);


--
-- Name: document_shares document_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: financial_periods financial_periods_building_id_year_key; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_building_id_year_key UNIQUE (building_id, year);


--
-- Name: financial_periods financial_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_pkey PRIMARY KEY (id);


--
-- Name: fractions fractions_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.fractions
    ADD CONSTRAINT fractions_pkey PRIMARY KEY (id);


--
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: letter_templates letter_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.letter_templates
    ADD CONSTRAINT letter_templates_pkey PRIMARY KEY (id);


--
-- Name: meeting_members meeting_members_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.meeting_members
    ADD CONSTRAINT meeting_members_pkey PRIMARY KEY (id);


--
-- Name: member_annual_fees member_annual_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_annual_fees
    ADD CONSTRAINT member_annual_fees_pkey PRIMARY KEY (id);


--
-- Name: member_votes member_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_votes
    ADD CONSTRAINT member_votes_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: minute_agenda_items minute_agenda_items_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minute_agenda_items
    ADD CONSTRAINT minute_agenda_items_pkey PRIMARY KEY (id);


--
-- Name: minute_signatures minute_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.minute_signatures
    ADD CONSTRAINT minute_signatures_pkey PRIMARY KEY (id);


--
-- Name: minutes minutes_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minutes
    ADD CONSTRAINT minutes_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- Name: sent_letters sent_letters_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.sent_letters
    ADD CONSTRAINT sent_letters_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: transaction_categories transaction_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transaction_categories
    ADD CONSTRAINT transaction_categories_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_unique; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_unique UNIQUE (session_token);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: voting_results voting_results_pkey; Type: CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.voting_results
    ADD CONSTRAINT voting_results_pkey PRIMARY KEY (id);


--
-- Name: idx_communication_logs_building_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_building_id ON public.communication_logs USING btree (building_id);


--
-- Name: idx_communication_logs_channel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_channel ON public.communication_logs USING btree (channel);


--
-- Name: idx_communication_logs_convocatoria; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_convocatoria ON public.communication_logs USING btree (related_convocatoria_id);


--
-- Name: idx_communication_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_created_at ON public.communication_logs USING btree (created_at DESC);


--
-- Name: idx_communication_logs_member_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_member_id ON public.communication_logs USING btree (member_id);


--
-- Name: idx_communication_logs_minute; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_minute ON public.communication_logs USING btree (related_minute_id);


--
-- Name: idx_communication_logs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_status ON public.communication_logs USING btree (status);


--
-- Name: idx_communication_logs_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_communication_logs_type ON public.communication_logs USING btree (communication_type);


--
-- Name: idx_convocatorias_building_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_convocatorias_building_id ON public.convocatorias USING btree (building_id);


--
-- Name: idx_documents_building_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_documents_building_id ON public.documents USING btree (building_id);


--
-- Name: idx_documents_category; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_documents_category ON public.documents USING btree (category);


--
-- Name: idx_documents_current_version; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_documents_current_version ON public.documents USING btree (is_current_version) WHERE (is_current_version = true);


--
-- Name: idx_documents_member_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_documents_member_id ON public.documents USING btree (member_id);


--
-- Name: idx_documents_search; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_documents_search ON public.documents USING gin (search_vector);


--
-- Name: idx_documents_tags; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_documents_tags ON public.documents USING gin (tags);


--
-- Name: idx_members_building_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_members_building_id ON public.members USING btree (building_id);


--
-- Name: idx_minute_signatures_minute_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_minute_signatures_minute_id ON public.minute_signatures USING btree (minute_id);


--
-- Name: idx_minute_signatures_signer_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_minute_signatures_signer_type ON public.minute_signatures USING btree (signer_type);


--
-- Name: idx_minutes_building_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_minutes_building_id ON public.minutes USING btree (building_id);


--
-- Name: idx_minutes_convocatoria_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_minutes_convocatoria_id ON public.minutes USING btree (convocatoria_id);


--
-- Name: idx_tasks_assignee_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_tasks_assignee_id ON public.tasks USING btree (assignee_id);


--
-- Name: idx_tasks_building_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_tasks_building_id ON public.tasks USING btree (building_id);


--
-- Name: idx_tasks_due_date; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_tasks_due_date ON public.tasks USING btree (due_date);


--
-- Name: idx_tasks_minute_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_tasks_minute_id ON public.tasks USING btree (minute_id);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- Name: idx_transactions_building_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_transactions_building_id ON public.transactions USING btree (building_id);


--
-- Name: idx_transactions_date; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_transactions_date ON public.transactions USING btree (transaction_date);


--
-- Name: idx_transactions_member_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_transactions_member_id ON public.transactions USING btree (member_id);


--
-- Name: idx_users_building_id; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_users_building_id ON public.users USING btree (building_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: refresh_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX refresh_tokens_expires_at_index ON public.refresh_tokens USING btree (expires_at);


--
-- Name: refresh_tokens_is_revoked_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX refresh_tokens_is_revoked_index ON public.refresh_tokens USING btree (is_revoked);


--
-- Name: refresh_tokens_token_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX refresh_tokens_token_index ON public.refresh_tokens USING btree (token);


--
-- Name: refresh_tokens_user_id_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX refresh_tokens_user_id_index ON public.refresh_tokens USING btree (user_id);


--
-- Name: user_sessions_expires_at_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX user_sessions_expires_at_index ON public.user_sessions USING btree (expires_at);


--
-- Name: user_sessions_is_active_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX user_sessions_is_active_index ON public.user_sessions USING btree (is_active);


--
-- Name: user_sessions_session_token_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX user_sessions_session_token_index ON public.user_sessions USING btree (session_token);


--
-- Name: user_sessions_user_id_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX user_sessions_user_id_index ON public.user_sessions USING btree (user_id);


--
-- Name: users_building_id_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX users_building_id_index ON public.users USING btree (building_id);


--
-- Name: users_email_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX users_email_index ON public.users USING btree (email);


--
-- Name: users_is_active_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX users_is_active_index ON public.users USING btree (is_active);


--
-- Name: users_role_index; Type: INDEX; Schema: public; Owner: mini-server
--

CREATE INDEX users_role_index ON public.users USING btree (role);


--
-- Name: communication_logs trigger_communication_logs_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_communication_logs_updated_at BEFORE UPDATE ON public.communication_logs FOR EACH ROW EXECUTE FUNCTION public.update_communication_logs_updated_at();


--
-- Name: buildings update_buildings_updated_at; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_buildings_updated_at BEFORE UPDATE ON public.buildings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: convocatorias update_convocatorias_updated_at; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_convocatorias_updated_at BEFORE UPDATE ON public.convocatorias FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: documents update_document_search_trigger; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_document_search_trigger BEFORE INSERT OR UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.update_document_search_vector();


--
-- Name: financial_periods update_financial_periods_updated_at; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_financial_periods_updated_at BEFORE UPDATE ON public.financial_periods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: members update_members_updated_at; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_members_updated_at BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: minutes update_minutes_updated_at; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_minutes_updated_at BEFORE UPDATE ON public.minutes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tasks update_tasks_completed_at_trigger; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_tasks_completed_at_trigger BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.update_tasks_completed_at();


--
-- Name: tasks update_tasks_updated_at_trigger; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_tasks_updated_at_trigger BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.update_tasks_updated_at();


--
-- Name: transactions update_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_transactions_updated_at BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: mini-server
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: arrears arrears_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.arrears
    ADD CONSTRAINT arrears_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: arrears arrears_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.arrears
    ADD CONSTRAINT arrears_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: arrears arrears_settlement_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.arrears
    ADD CONSTRAINT arrears_settlement_transaction_id_fkey FOREIGN KEY (settlement_transaction_id) REFERENCES public.transactions(id);


--
-- Name: attendance_sheets attendance_sheets_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.attendance_sheets
    ADD CONSTRAINT attendance_sheets_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: attendance_sheets attendance_sheets_convocatoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.attendance_sheets
    ADD CONSTRAINT attendance_sheets_convocatoria_id_fkey FOREIGN KEY (convocatoria_id) REFERENCES public.convocatorias(id);


--
-- Name: attendance_sheets attendance_sheets_minute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.attendance_sheets
    ADD CONSTRAINT attendance_sheets_minute_id_fkey FOREIGN KEY (minute_id) REFERENCES public.minutes(id);


--
-- Name: attendees attendees_attendance_sheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_attendance_sheet_id_fkey FOREIGN KEY (attendance_sheet_id) REFERENCES public.attendance_sheets(id) ON DELETE CASCADE;


--
-- Name: attendees attendees_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.attendees
    ADD CONSTRAINT attendees_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: communication_logs communication_logs_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: communication_logs communication_logs_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: communication_logs communication_logs_related_convocatoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_related_convocatoria_id_fkey FOREIGN KEY (related_convocatoria_id) REFERENCES public.convocatorias(id) ON DELETE SET NULL;


--
-- Name: communication_logs communication_logs_related_minute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_related_minute_id_fkey FOREIGN KEY (related_minute_id) REFERENCES public.minutes(id) ON DELETE SET NULL;


--
-- Name: communication_logs communication_logs_related_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.communication_logs
    ADD CONSTRAINT communication_logs_related_transaction_id_fkey FOREIGN KEY (related_transaction_id) REFERENCES public.transactions(id) ON DELETE SET NULL;


--
-- Name: convocatorias convocatorias_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.convocatorias
    ADD CONSTRAINT convocatorias_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: convocatorias convocatorias_published_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.convocatorias
    ADD CONSTRAINT convocatorias_published_by_user_id_fkey FOREIGN KEY (published_by_user_id) REFERENCES public.users(id);


--
-- Name: document_categories document_categories_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: document_categories document_categories_parent_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_categories
    ADD CONSTRAINT document_categories_parent_category_id_fkey FOREIGN KEY (parent_category_id) REFERENCES public.document_categories(id) ON DELETE SET NULL;


--
-- Name: document_shares document_shares_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_shares document_shares_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.document_shares
    ADD CONSTRAINT document_shares_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: documents documents_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: documents documents_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: documents documents_parent_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_parent_document_id_fkey FOREIGN KEY (parent_document_id) REFERENCES public.documents(id) ON DELETE SET NULL;


--
-- Name: financial_periods financial_periods_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: financial_periods financial_periods_closed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.financial_periods
    ADD CONSTRAINT financial_periods_closed_by_user_id_fkey FOREIGN KEY (closed_by_user_id) REFERENCES public.users(id);


--
-- Name: fractions fractions_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.fractions
    ADD CONSTRAINT fractions_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: fractions fractions_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.fractions
    ADD CONSTRAINT fractions_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: letter_templates letter_templates_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.letter_templates
    ADD CONSTRAINT letter_templates_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: meeting_members meeting_members_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.meeting_members
    ADD CONSTRAINT meeting_members_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: meeting_members meeting_members_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.meeting_members
    ADD CONSTRAINT meeting_members_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: meeting_members meeting_members_minutes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.meeting_members
    ADD CONSTRAINT meeting_members_minutes_id_fkey FOREIGN KEY (minutes_id) REFERENCES public.minutes(id) ON DELETE CASCADE;


--
-- Name: member_annual_fees member_annual_fees_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_annual_fees
    ADD CONSTRAINT member_annual_fees_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: member_annual_fees member_annual_fees_financial_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_annual_fees
    ADD CONSTRAINT member_annual_fees_financial_period_id_fkey FOREIGN KEY (financial_period_id) REFERENCES public.financial_periods(id);


--
-- Name: member_annual_fees member_annual_fees_fraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_annual_fees
    ADD CONSTRAINT member_annual_fees_fraction_id_fkey FOREIGN KEY (fraction_id) REFERENCES public.fractions(id);


--
-- Name: member_annual_fees member_annual_fees_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_annual_fees
    ADD CONSTRAINT member_annual_fees_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: member_annual_fees member_annual_fees_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_annual_fees
    ADD CONSTRAINT member_annual_fees_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.transactions(id);


--
-- Name: member_votes member_votes_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_votes
    ADD CONSTRAINT member_votes_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: member_votes member_votes_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_votes
    ADD CONSTRAINT member_votes_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: member_votes member_votes_minute_agenda_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.member_votes
    ADD CONSTRAINT member_votes_minute_agenda_item_id_fkey FOREIGN KEY (minute_agenda_item_id) REFERENCES public.minute_agenda_items(id) ON DELETE CASCADE;


--
-- Name: members members_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: members members_legal_representative_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_legal_representative_id_fkey FOREIGN KEY (legal_representative_id) REFERENCES public.members(id);


--
-- Name: minute_agenda_items minute_agenda_items_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minute_agenda_items
    ADD CONSTRAINT minute_agenda_items_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: minute_agenda_items minute_agenda_items_convocatoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minute_agenda_items
    ADD CONSTRAINT minute_agenda_items_convocatoria_id_fkey FOREIGN KEY (convocatoria_id) REFERENCES public.convocatorias(id);


--
-- Name: minute_agenda_items minute_agenda_items_minutes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minute_agenda_items
    ADD CONSTRAINT minute_agenda_items_minutes_id_fkey FOREIGN KEY (minutes_id) REFERENCES public.minutes(id) ON DELETE CASCADE;


--
-- Name: minute_signatures minute_signatures_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.minute_signatures
    ADD CONSTRAINT minute_signatures_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: minute_signatures minute_signatures_minute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.minute_signatures
    ADD CONSTRAINT minute_signatures_minute_id_fkey FOREIGN KEY (minute_id) REFERENCES public.minutes(id) ON DELETE CASCADE;


--
-- Name: minutes minutes_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minutes
    ADD CONSTRAINT minutes_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.users(id);


--
-- Name: minutes minutes_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minutes
    ADD CONSTRAINT minutes_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: minutes minutes_convocatoria_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.minutes
    ADD CONSTRAINT minutes_convocatoria_id_fkey FOREIGN KEY (convocatoria_id) REFERENCES public.convocatorias(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sent_letters sent_letters_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.sent_letters
    ADD CONSTRAINT sent_letters_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: sent_letters sent_letters_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.sent_letters
    ADD CONSTRAINT sent_letters_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: sent_letters sent_letters_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.sent_letters
    ADD CONSTRAINT sent_letters_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id);


--
-- Name: sent_letters sent_letters_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.sent_letters
    ADD CONSTRAINT sent_letters_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.letter_templates(id);


--
-- Name: tasks tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.members(id);


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.members(id);


--
-- Name: tasks tasks_minute_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_minute_id_fkey FOREIGN KEY (minute_id) REFERENCES public.minutes(id) ON DELETE SET NULL;


--
-- Name: transaction_categories transaction_categories_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transaction_categories
    ADD CONSTRAINT transaction_categories_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: transaction_categories transaction_categories_parent_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transaction_categories
    ADD CONSTRAINT transaction_categories_parent_category_id_fkey FOREIGN KEY (parent_category_id) REFERENCES public.transaction_categories(id);


--
-- Name: transactions transactions_approved_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_approved_by_user_id_fkey FOREIGN KEY (approved_by_user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_building_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_building_id_fkey FOREIGN KEY (building_id) REFERENCES public.buildings(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.transaction_categories(id);


--
-- Name: transactions transactions_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_financial_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_financial_period_id_fkey FOREIGN KEY (financial_period_id) REFERENCES public.financial_periods(id);


--
-- Name: transactions transactions_fraction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_fraction_id_fkey FOREIGN KEY (fraction_id) REFERENCES public.fractions(id);


--
-- Name: transactions transactions_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE SET NULL;


--
-- Name: transactions transactions_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.financial_periods(id);


--
-- Name: user_sessions user_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: voting_results voting_results_minute_agenda_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mini-server
--

ALTER TABLE ONLY public.voting_results
    ADD CONSTRAINT voting_results_minute_agenda_item_id_fkey FOREIGN KEY (minute_agenda_item_id) REFERENCES public.minute_agenda_items(id) ON DELETE CASCADE;


--
-- Name: TABLE arrears; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.arrears TO devuser;


--
-- Name: TABLE attendance_sheets; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.attendance_sheets TO devuser;


--
-- Name: TABLE attendees; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.attendees TO devuser;


--
-- Name: TABLE buildings; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.buildings TO devuser;


--
-- Name: TABLE convocatorias; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.convocatorias TO devuser;


--
-- Name: TABLE document_categories; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.document_categories TO devuser;


--
-- Name: SEQUENCE document_categories_id_seq; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON SEQUENCE public.document_categories_id_seq TO devuser;


--
-- Name: TABLE document_shares; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.document_shares TO devuser;


--
-- Name: SEQUENCE document_shares_id_seq; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON SEQUENCE public.document_shares_id_seq TO devuser;


--
-- Name: TABLE documents; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.documents TO devuser;


--
-- Name: SEQUENCE documents_id_seq; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON SEQUENCE public.documents_id_seq TO devuser;


--
-- Name: TABLE financial_periods; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.financial_periods TO devuser;


--
-- Name: TABLE fractions; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.fractions TO devuser;


--
-- Name: TABLE knex_migrations; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.knex_migrations TO devuser;


--
-- Name: SEQUENCE knex_migrations_id_seq; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON SEQUENCE public.knex_migrations_id_seq TO devuser;


--
-- Name: TABLE knex_migrations_lock; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.knex_migrations_lock TO devuser;


--
-- Name: SEQUENCE knex_migrations_lock_index_seq; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON SEQUENCE public.knex_migrations_lock_index_seq TO devuser;


--
-- Name: TABLE letter_templates; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.letter_templates TO devuser;


--
-- Name: TABLE meeting_members; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.meeting_members TO devuser;


--
-- Name: TABLE member_annual_fees; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.member_annual_fees TO devuser;


--
-- Name: TABLE member_votes; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.member_votes TO devuser;


--
-- Name: TABLE members; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.members TO devuser;


--
-- Name: TABLE minute_agenda_items; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.minute_agenda_items TO devuser;


--
-- Name: TABLE minutes; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.minutes TO devuser;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.refresh_tokens TO devuser;


--
-- Name: TABLE sent_letters; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.sent_letters TO devuser;


--
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.tasks TO devuser;


--
-- Name: SEQUENCE tasks_id_seq; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON SEQUENCE public.tasks_id_seq TO devuser;


--
-- Name: TABLE transaction_categories; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.transaction_categories TO devuser;


--
-- Name: TABLE transactions; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.transactions TO devuser;


--
-- Name: TABLE user_sessions; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.user_sessions TO devuser;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.users TO devuser;


--
-- Name: TABLE voting_results; Type: ACL; Schema: public; Owner: mini-server
--

GRANT ALL ON TABLE public.voting_results TO devuser;


--
-- PostgreSQL database dump complete
--

